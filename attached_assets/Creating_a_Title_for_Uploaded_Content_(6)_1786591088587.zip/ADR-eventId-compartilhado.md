---
title: "Usar eventId compartilhado entre polling e webhook"
date: 2026-08-12
status: accepted
tags: [idempotencia, dedup, webhook]
systems: [PADCOM]
validado_em: [Protocolo-Manager, concierge-penalidade.ts]
---

## O que decidimos

Polling e webhook usam o mesmo formato de eventId: `shared:{pedidoId}:{cobrancaId}:{desfechoCanonico}`. A dedup por PRIMARY KEY resolve qualquer ordem de chegada.

## Por quê

**Armadilha que gerou o bug:** polling usava `poll:{id}:{chargeId}:{status}` e webhook usava `event.id` do payload Asaas. IDs diferentes para o mesmo fato → dois observadores registravam a mesma cobrança vencida duas vezes → paciente recebia 2 penalidades por 1 abandono.

| Opção | Prós | Por que descartamos |
|---|---|---|
| Polling verificar webhook antes | Parece óbvio | Só funciona se webhook chegar primeiro |
| Webhook verificar polling antes | Parece óbvio | Só funciona se polling chegar primeiro |
| **eventId compartilhado + PK** | Resolve qualquer ordem | ✓ Escolhida |

## O que vigora

Todo evento de penalidade usa `construirEventId(pedidoId, cobrancaId, desfechoCanonico)`. O desfecho é canônico (expirado, cancelado, chargeback, pago) — não o código bruto do Asaas.

## O que vai apodrecer

Se o sistema mudar de provedor de pagamento (não usar Asaas), o campo `cobrancaId` precisa ser remapeado para o identificador equivalente do novo provedor.
