---
title: "Remover guard de idempotência fora do CTE"
date: 2026-08-12
status: accepted
tags: [idempotencia, race-condition, penalidade]
systems: [PADCOM]
validado_em: [Protocolo-Manager, concierge-penalidade.ts]
---

## O que decidimos

Qualquer verificação de idempotência que rode fora do CTE deve ser removida. A PRIMARY KEY sobre o `event_id` compartilhado garante atomicidade sem corrida.

## Por quê

| Opção | Prós aparentes | Por que descartamos |
|---|---|---|
| Alterar guard para incluir desfecho | Parece defense-in-depth | Ainda roda fora do CTE; não elimina a corrida |
| Manter guard como está | Parece proteger | Corta eventos legítimos distintos |
| **Remover guard inteiro** | Simples, atômico | ✓ Escolhida |

**Armadilha que gerou o bug:** o guard verificava "este sreq já tem algum evento?" antes de registrar. Dois eventos legítimos do mesmo pedido (cobrança expirada → depois chargeback) têm eventIds distintos — a PK não conflita, ambos DEVEM ser registrados. O guard cortava o segundo silenciosamente, sem erro, sem log.

## O que vigora

Check de idempotência fora do CTE é candidato a corrida. Se precisar checar antes de escrever: mover o check para dentro do CTE, ou confiar na PRIMARY KEY.

## O que vai apodrecer

Se o formato do `event_id` mudar e deixar de ser discriminante por fato (pedido + cobrança + desfecho), a PK deixa de garantir dedup correta e o guard pode voltar a fazer sentido. Revisar se houver mudança no formato.
