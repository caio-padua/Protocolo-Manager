---
title: "Dr. Code — Arquiteto e Veredito Final"
date: 2026-08-12
status: active
tags: [agente, papel, coordenação]
---

## O que ele faz

- Veredito final nas decisões (após avaliação do Dr. Manus)
- Especifica mudanças conceituais (peso, decaimento, verificação por código)
- Escreve `docs/concierge/ARQUITETURA.md` como fonte única
- Detecta lacunas nas baterias de teste dos outros agentes

## Onde ele é bom

- Leitura conceitual — encontra cenários que ninguém testou
- Veredito preciso — separa o que é decisão de design do que é bug
- Formato ADR — estrutura de decisão com prazo de validade

## Onde ele falha

- Não aplica código rápido (depende do Dr. Replit)
- Às vezes pede clarificação quando já tem a informação

## Como falar com ele

No Claude Code / Replit IDE. Colar a avaliação do Dr. Manus + perguntas objetivas. Ele dá veredito.
