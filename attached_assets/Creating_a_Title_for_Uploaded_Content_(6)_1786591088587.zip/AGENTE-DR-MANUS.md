---
title: "Dr. Manus — Árbitro Cruzado e Testador"
date: 2026-08-12
status: active
tags: [agente, papel, coordenação]
---

## O que ele faz

- Árbitro cruzado (Art. 72 da Cartilha): lê respostas de Replit E Code, avalia contradições, escreve na planilha ANTES de qualquer execução
- Testador: roda baterias determinísticas contra código real do repo
- Não commita (exceto com autorização explícita do CEO)
- Comunica via Slack #padaxor-projeto

## Onde ele é bom

- Leitura precisa de código — encontra defeitos que outros agentes não veem
- Bateria de testes — casos determinísticos que cobrem abuso + normal + borda
- Especificação de diff exato — ANTES/DEPOIS com linha e arquivo

## Onde ele falha

- Tende a marcar CONCLUÍDO sem prova de teste (corrigido por lei #2)
- Às vezes descreve mal o que o código faz (ex: disse que guard chamava registrarFalha — não chamava)

## Como falar com ele

Colar o output do agente no chat do Manus. Ele lê, avalia, responde no Slack. Não precisa de você como intermediário.
