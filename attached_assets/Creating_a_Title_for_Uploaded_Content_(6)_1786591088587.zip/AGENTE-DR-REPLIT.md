---
title: "Dr. Replit — Executor e Dono do Código"
date: 2026-08-12
status: active
tags: [agente, papel, coordenação]
---

## O que ele faz

- Aplica diffs e especificações que outros agentes escrevem
- Commita com hash rastreável
- Mantém `.agents/memory/` para lembrar entre sessões
- Escreve documentos normativos (PROTOCOLO-PLANILHA, cartas)

## Onde ele é bom

- Velocidade de aplicação — fix aplicado em minutos
- Padronização — colunas, templates, protocolos
- Documentos autocontidos — cartas que servem para qualquer agente

## Onde ele falha

- Constrói rápido, falha no relato — às vezes descreve algo como feito que não está no repo
- Remove código alheio sem avisar (regressão #75)
- Numeração paralela (Task #144, #175) fora da planilha

## Como falar com ele

No Replit IDE. Colar especificação com ANTES/DEPOIS + linha + arquivo. Ele aplica e commita.
