# Arsenal Tecnológico: Cockpit Unificado PAXTER (Julho 2026)

**De:** Manus AI (Dr. Replit Paxter)
**Para:** CEO Dr. Caio Padua (Padcon Conect / PAXTER)
**Data:** 23/07/2026
**Assunto:** Pesquisa de Estado da Arte e Plano de Refatoração do Cockpit Unificado

Prezado Dr. Caio,

Conforme sua solicitação, realizei uma pesquisa profunda no estado da arte do ecossistema React em julho de 2026 para identificar as ferramentas mais sofisticadas, modernas e adequadas ao redesenho do Cockpit Unificado. O objetivo é garantir que a implementação não apenas respeite a **Skill Layout Paxter**, mas também utilize a infraestrutura de mais alta performance disponível.

Abaixo, apresento a consolidação das melhores tecnologias e, em seguida, o plano de execução para a refatoração do código.

---

## 1. O Arsenal Tecnológico (O Melhor de 2026)

Para construir uma interface de alta densidade operacional como o Cockpit (10 abas, sticky headers, scroll horizontal, animações), não podemos usar uma biblioteca "faz tudo". A arquitetura de 2026 é modular.

### 1.1. Gerenciamento de Estado (State Management)
O `cockpit-cliente/index.tsx` atual sofre de "bloat" (excesso de variáveis). Em 2026, a comunidade abandonou Redux para UI state.

- **Zustand** (A escolha padrão da indústria): Com 72.9 milhões de downloads mensais em 2026 e 1.2KB de bundle, é a escolha óbvia. Ele permite criar stores globais sem Providers, evitando o "re-render" desnecessário de toda a árvore do cockpit. Ideal para isolar o estado da aba ativa (`activeTab`) e o estado do formulário financeiro (`payMethod`, `payAmount`), tirando-os do componente principal. [1]
- **TanStack Query v5**: O sistema já o utiliza. Em 2026, ele continua soberano para "Server State" (cacheamento de clientes, protocolos, pagamentos). O `useOptimistic` (do React 19) emparelhado com o TanStack Query permite atualizações instantâneas na UI antes mesmo da resposta do servidor. [2]

### 1.2. Primitivos de UI e Abas (Headless UI)
- **shadcn/ui + Base UI (MUI)**: O PAXTER já utiliza o `shadcn/ui` (que repousa sobre Radix UI). No entanto, a equipe MUI lançou o **Base UI** em 2026 como primitivos de ultra-baixo nível. Para o Cockpit, manteremos o `shadcn/ui` para consistência, mas utilizaremos os primitivos `Tabs` para garantir acessibilidade ARIA perfeita, enquanto aplicamos as classes sagradas Paxter (`bevel-3d`, `concave-3d`) por cima. [3]
- **Embla Carousel**: Para a régua de 10 abas, CSS puro com `overflow-x-auto` é antiquado e sem animação. Em 2026, o padrão para scroll horizontal suave é o Embla Carousel (7KB, mobile-first). Ele permitirá as setas laterais (fade indicators) e transições suaves entre as abas sem perder a semântica de "Tabs". [4]

### 1.3. Animações e Micro-interações
- **Motion (anteriormente Framer Motion)**: O padrão absoluto para React em 2026. Ele substitui completamente animações CSS manuais. Usaremos o `<AnimatePresence>` para quando o cliente trocar de aba (efeito de "fade-out" suave) e `whileHover` / `whileTap` para dar a sensação tátil de "bevel" (botão afundando) nas ações do header. [5]
- **Lenis**: Uma biblioteca leve que embrulha o scroll nativo do navegador. Crucial para o Cockpit, pois permite que o header fique "sticky" e animado durante o rolamento sem causar "jitter" (travamentos), mantendo a `position: sticky` funcionando perfeitamente. [6]
- **View Transitions API**: Uma nova API nativa dos browsers (Chromium/Safari) em 2026 para transições de página zero-overhead. Usaremos para o carregamento inicial do cockpit quando o usuário seleciona um paciente. [7]

### 1.4. Performance e Renderização
- **React.lazy e Suspense**: A refatoração quebrará o monólito de 966 linhas. Cada aba (ex: `FinanceiroPanel`, `ProtocolosPanel`) será carregada via `React.lazy`. O React só montará o painel no DOM quando o usuário clicar na aba, reduzindo o tempo de carregamento inicial em 80%. [8]

---

## 2. Plano de Refatoração (Respeitando a Skill Paxter)

A refatoração do arquivo `cockpit-cliente/index.tsx` seguirá rigorosamente a **Lei do Registro de Modelagem** (Seção 0.1 da Skill Layout Paxter):

1. **Modularização**: O arquivo será dividido. O header e as abas serão componentes isolados.
2. **Conformidade Visual**:
   - **Padrao 3**: Títulos das seções (ex: "Ações Rápidas") usarão `BlockTitle` (`bevel-3d` com ícone).
   - **Padrao 8**: Respiro de `gap-3` ou `space-y-4` entre os blocos 3D.
   - **Padrao 12**: Posição fixa para os metadados do paciente no cabeçalho.
3. **Identidade Navy/Ouro**: O header usará o gradiente `#16294a` e acentos dourados, removendo a redundância do `ClientPicker` e do `ClienteCracha`.

---

## 3. Próxima Etapa

Agora que o arsenal está definido e o plano traçado, iniciarei a **Fase 4: Refatoração do Código**.

Vou extrair o estado para o Zustand (via hooks customizados), substituir a régua CSS por um carrossel Embla animado com Motion, e aplicar lazy loading nas abas pesadas, garantindo que o design final seja idêntico ao mockup aprovado.

*Referências:*
[1] Zustand vs Redux 2026: 7x Bundle Gap. Tech Insider.
[2] TanStack Query v5 Documentation.
[3] Base UI v1.0 Release Notes (MUI Team).
[4] Embla Carousel vs Swiper 2026. Pkgpulse.
[5] Motion (formerly Framer Motion) Documentation.
[6] Lenis Smooth Scroll. Darkroom Engineering.
[7] View Transition API - MDN Web Docs.
[8] React Performance Optimization Guide 2026. Turbodocx.
