# Auditoria e Proposta de Redesign: Cockpit Unificado PAXTER

**De:** Manus AI (Dr. Replit Paxter)
**Para:** CEO Dr. Caio Padua (Padcon Conect / PAXTER)
**Data:** 23/07/2026
**Assunto:** Diagnóstico UX, Proposta Visual e Estratégia de Codificação do Cockpit

Prezado Dr. Caio,

Conforme solicitado, realizei a auditoria completa do arquivo `cockpit-cliente/index.tsx` e dos componentes correlatos, cruzando os achados com as regras sagradas do `skill-layout-paxter`. O objetivo foi resolver a confusão visual no cabeçalho, garantir a consistência da identidade e preparar o terreno para uma codificação robusta e performática.

Abaixo, apresento o diagnóstico, a proposta visual e as respostas técnicas às suas dúvidas.

---

## 1. Diagnóstico de UX (O que está errado e por que)

A análise da estrutura atual revela quatro pontos de fricção cognitiva que sobrecarregam o usuário (especialmente em fluxo TDAH-friendly):

**A. Redundância e Dispersão da Identidade**
Atualmente, o cabeçalho contém o `ClientPicker` (que mostra o nome do cliente) e, logo abaixo, o componente `ClienteCracha` exibe novamente a foto, o nome, idade e dados clínicos. Essa duplicação força o olho a saltar para verificar se é o mesmo paciente.

**B. Flutuação de Ação Sem Contexto**
Quando um cliente está selecionado, os três botões de ação (Editar, Drive, Protocolo) "flutuam" ao lado do picker. Quando nenhum cliente está selecionado, esses botões desaparecem, deixando o picker visualmente solto e sem um painel de controle claro.

**C. Scroll Oculto e Densidade**
A régua de 10 abas possui `overflow-x-auto` e `scrollbarWidth: "none"`. Em telas menores, as abas transbordam para fora da viewport. O usuário não percebe imediatamente que pode deslizar para ver "Protocolos", "Financeiro" ou "Cadastro", gerando a sensação de que funcionalidades estão faltando.

**D. Ruído de Marca**
O subtítulo "PADCON CONECT" no cabeçalho repete a marca que já está fixa na sidebar do sistema. Isso ocupa um espaço vertical precioso que poderia ser melhor utilizado.

---

## 2. Proposta de Redesenho (Mockup Visual)

Para resolver esses problemas, propus um redesign que unifica a identidade no cabeçalho e garante que todas as 10 abas sejam perceptíveis.

### 2.1. Estado com Cliente Selecionado
A identidade do cliente foi elevada para o cabeçalho principal, eliminando a necessidade de exibir o crachá completo na lista de ações imediatas.

![Mockup: Cabeçalho com Cliente](https://private-us-east-1.manuscdn.com/sessionFile/fuyESh60ksrNkM9OmEcWoS/sandbox/U6z4bvJDtdXxFLVxGIRZL6-images_1784830060320_na1fn_L2hvbWUvdWJ1bnR1L3dpcmVmcmFtZV9jb2NrcGl0X25vdm9faGVhZGVy.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvZnV5RVNoNjBrc3JOa005T21FY1dvUy9zYW5kYm94L1U2ejRidkpEdGRYeEZMVnhHSVJaTDYtaW1hZ2VzXzE3ODQ4MzAwNjAzMjBfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwzZHBjbVZtY21GdFpWOWpiMk5yY0dsMFgyNXZkbTlmYUdWaFpHVnkucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzg2NzUyMDAwfX19XX0_&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEUCIHPs-6q~QNWTrsUQwweJV7lbPZeZMjC4tfkG2EcrwqTRAiEAjQxztQV9Lir7Ea2sAllSOAkAJAe2Npg~w-pubNvb34k_)

**Decisões de Design:**
- **Identidade Unificada:** O avatar do cliente (foto + iniciais), o nome em fonte serifada de destaque (Cormorant Garamond) e o status (Sem Alarme / Sinal de Alarme) agora vivem no canto esquerdo do header navy.
- **Ações Consolidadas:** Os botões de ação (Editar, Drive, Protocolo) foram movidos para o canto direito, formatados como teclas 3D (`btn-3d-soft` / `btn-3d`), mantendo o padrão de relevância dourada.
- **Abas em 1 Nível com Indicadores:** As 10 abas permanecem em uma única linha, mas agora possuem indicadores de fade (gradiente) nas laterais, sinalizando claramente que há mais conteúdo para explorar. A aba ativa mantém o estilo `panel-3d` elevado.

### 2.2. Estado Vazio (Sem Cliente)
Quando nenhum cliente está selecionado, o sistema deve guiar a ação do usuário de forma clara.

![Mockup: Cabeçalho Sem Cliente](https://private-us-east-1.manuscdn.com/sessionFile/fuyESh60ksrNkM9OmEcWoS/sandbox/U6z4bvJDtdXxFLVxGIRZL6-images_1784830060320_na1fn_L2hvbWUvdWJ1bnR1L3dpcmVmcmFtZV9jb2NrcGl0X3NlbV9jbGllbnRl.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvZnV5RVNoNjBrc3JOa005T21FY1dvUy9zYW5kYm94L1U2ejRidkpEdGRYeEZMVnhHSVJaTDYtaW1hZ2VzXzE3ODQ4MzAwNjAzMjBfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwzZHBjbVZtY21GdFpWOWpiMk5yY0dsMFgzTmxiVjlqYkdsbGJuUmwucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzg2NzUyMDAwfX19XX0_&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEUCIQDaEfsbzZNWP3-OgwAmU3fhQMFEXVsHwFCjX8HWa8xgiQIgbIGG05icVtmbTsII8TX3BU4jCbt9zF1oP6p-2FxMQyY_)

**Decisões de Design:**
- **Picker em Destaque:** O `ClientPicker` ocupa o centro do cabeçalho como um campo gravado (`concave-3d`) com borda dourada, convidando à interação.
- **Botões Inativos:** As ações (Editar, Drive, Protocolo) permanecem visíveis, mas em estado "fantasma" (opacidade reduzida), ensinando ao usuário o que estará disponível assim que um paciente for escolhido.
- **Área de Conteúdo:** Um painel central (`panel-3d`) com ícone `UserRound` e texto "SELECIONE O PACIENTE" substitui a área de abas, evitando a confusão de abas apagadas.

---

## 3. Estratégia de Codificação (Como codificar)

Para implementar essa nova visão respeitando as regras sagradas do sistema 3D, a arquitetura do componente deve evoluir de um monólito para componentes modulares.

### 3.1. Componentes Propostos

| Componente | Responsabilidade | Nível de Estado |
| :--- | :--- | :--- |
| `CockpitHeader` | Renderiza o bloco sticky. Decide se mostra o `ClientIdentity` ou o `ClientPicker` centralizado. | Local (`useState`) |
| `ClientIdentity` | Exibe avatar, nome (Cormorant Garamond), idade e badge de alarme. | Recebe `client` via props |
| `ActionButtons` | Renderiza Editar, Drive e Protocolo. Condiciona a opacidade com base na existência do cliente. | Local (Hooks de mutation) |
| `CockpitTabs` | A régua horizontal. Gerencia o estado da aba ativa e a persistência via `localStorage`. | Local (`useState`) |
| `CockpitContent` | O painel claro abaixo. Usa `React.lazy` e `Suspense` para carregar os 10 módulos sob demanda. | Local |

### 3.2. Gerenciamento de Estado

Atualmente, o arquivo possui mais de 15 variáveis `useState` misturando a lógica de UI (abas, cliente) com a lógica de formulários (Financeiro, Asaas). 

**Refatoração Recomendada:**
- Manter o estado de `clienteId` e `aba` no componente pai (`CockpitCliente`).
- Extrair a lógica do módulo Financeiro (variáveis `payMethod`, `payAmount`, etc.) para um hook customizado `useFinanceiro(clienteId)` ou para o componente `FinanceiroTab`. Isso limpa drasticamente o `index.tsx`.

### 3.3. Otimização de Renderização

Com 10 abas carregando múltiplos painéis (ex: `NovoProtocolo`, `Injetaveis`, `EvolucaoExamesPanel`), o componente atual força o React a montar tudo na árvore virtual a cada renderização de abas.

**Solução:**
Utilizar `React.lazy` com `Suspense` para cada aba pesada:
```tsx
const PrescricaoTab = lazy(() => import("./panels/PrescricaoPanel"));
const FinanceiroTab = lazy(() => import("./panels/FinanceiroPanel"));

// Dentro do render:
<Suspense fallback={<Skeleton className="h-64 rounded-lg panel-3d-sub" />}>
  {aba === "prescricao" && <PrescricaoTab clientId={clienteId} />}
  {aba === "financeiro" && <FinanceiroTab clientId={clienteId} />}
</Suspense>
```
Isso garante que o código e os dados de cada aba só sejam processados no exato momento em que o usuário clica nela.

---

## 4. Resposta à Pergunta Específica: Ferramentas em Julho de 2026

Dr. Caio, em relação às melhores bibliotecas para construir painéis e abas complexas no React em 2026, o ecossistema mudou significativamente em direção às soluções "Headless" (sem estilo pré-definido).

### 4.1. Qual a melhor solução de sticky header com tabs em React em 2026?

A melhor abordagem não é usar uma biblioteca "completa" (como Material UI ou Ant Design), mas sim uma **Biblioteca Headless** que gerencie apenas a acessibilidade, o foco de teclado e a semântica ARIA, enquanto você aplica as suas classes sagradas (`panel-3d`, `bevel-3d`).

**As 3 melhores opções atuais:**

| Biblioteca | Vantagens para o PAXTER | Desvantagens |
| :--- | :--- | :--- |
| **shadcn/ui** (Camada atual do PAXTER) | Copia o código para o seu repositório. Você tem controle total sobre as classes CSS. Já usa Radix ou Base UI por baixo dos panos. | Requer que você configure as cores do Tailwind para casar perfeitamente com o Navy/Ouro, o que já está feito. |
| **Base UI** (MUI Team) | A evolução natural do Radix. Lançou v1.0 estável em 2026. Oferece primitivos extremamente flexíveis e baixa sobrecarga de código. É o que eu recomendo para novas implementações. | A API é um pouco mais complexa que o Radix puro. |
| **Ark UI** | Funciona não só em React, mas também em Vue e Solid. Usa máquinas de estado (XState) para uma robustez extrema. | Exige aprender o paradigma de "máquina de estados" para componentes simples. |

### 4.2. Recomendação para o Cockpit Unificado

**Mantenha e atualize o uso do Radix UI / Base UI.** 
O PAXTER já está construído sobre os fundamentos do `shadcn/ui` (que usa Radix). Para as abas (`Tabs`), o componente primitivo do Radix/Base UI é perfeito porque ele separa o `<Tabs.List>` (a régua) do `<Tabs.Content>` (o painel).

**Como implementar a régua de abas com scroll infalível:**
Não use apenas CSS. Use a abstração do Radix para a lógica de foco, e adicione um "viewport observer" para as setas laterais (indicadores de fade). 
Se quiser uma solução pronta para a rolagem horizontal suave das abas, a biblioteca `embla-carousel-react` é o padrão da indústria em 2026 para transições suaves sem perder a semântica de "abas" para leitores de tela.

---

## 5. Resumo em 1 Linha

Unificamos a identidade do paciente no cabeçalho para eliminar redundância, usamos indicadores de fade nas abas para resolver o scroll oculto e mantemos a arquitetura 3D (Navy/Ouro) recomendando a evolução para primitivos Base UI/shadcn com React.lazy para máxima performance.

Estou à disposição para executar a refatoração do código imediatamente após sua aprovação visual deste mockup.

Atenciosamente,

**Manus AI (Dr. Replit Paxter)**  
Padcon Conect / PAXTER
