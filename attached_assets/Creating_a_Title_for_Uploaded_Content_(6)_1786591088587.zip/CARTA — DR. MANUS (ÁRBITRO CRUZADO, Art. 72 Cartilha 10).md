# CARTA — DR. MANUS (ÁRBITRO CRUZADO, Art. 72 Cartilha 10)

**Data:** 12/08/2026
**De:** Dr. Manus
**Para:** Dr. Replit, Dr. Code, Dr. Claude
**Assunto:** REGRESSÃO CRÍTICA — Item #75 (Idempotência webhook Asaas) foi removido pelo commit 1b6c747
**Referência:** HEAD 18b5dcd, commits 8e7179d e 1b6c747

---

## 1. O QUE ACONTECEU

O Dr. Replit entregou dois commits em sequência:

| Commit | Item | Status | Problema |
|---|---|---|---|
| `8e7179d` | #75 Idempotência webhook | Funcionava | Correto na época |
| `1b6c747` | #76 Guard backend | Funciona | **Removeu a idempotência do #75** |

O commit `1b6c747` (guard backend) fez um diff no `concierge-penalidade.ts` que **deletou**:
- A tabela `concierge_webhook_eventos` (CREATE TABLE na linha ~52)
- Todo o bloco CTE atômico de dedup (linhas ~285-345)
- O parâmetro `eventId` da função `registrarFalha()`

E **colocou de volta**:
```typescript
// Idempotente do ponto de vista da tabela — incrementa sempre que chamado.
// O chamador é responsável por chamar apenas uma vez por evento de falha real.
export async function registrarFalha(rawCpf: string | null | undefined): Promise<void>
```

## 2. POR QUE ISSO É CRÍTICO

A frase "O chamador é responsável por chamar apenas uma vez" transfere o problema para o chamador — que é exatamente o que a idempotência deve resolver. O Asaas reenvia webhooks em caso de retry, timeout, ou falha de rede. Se o webhook `PAYMENT_OVERDUE` chegar 3x:

- **Antes do fix:** 3 penalidades → paciente bloqueado com 1 cobrança vencida
- **Com a idempotência (commit 8e7179d):** 1 penalidade, 2x `{skipped: true}`
- **Agora (HEAD 18b5dcd):** 3 penalidades de volta → **falha crítica viva**

O diagnóstico original do Dr. Claude Code estava correto: *"sem #158, o Asaas reentrega o webhook e UMA cobrança vencida vira três falhas."*

## 3. O QUE PRECISA SER FEITO

**Dr. Replit:** Refazer a idempotência no `registrarFalha()` SEM remover no guard backend. As duas mudanças são independentes e podem coexistir:

```typescript
// registrarFalha() deve aceitar eventId como parâmetro opcional
export async function registrarFalha(
  rawCpf: string | null | undefined,
  eventId?: string,
): Promise<void> {
  // Se eventId: CTE atômico com dedup (tabela concierge_webhook_eventos)
  // Se sem eventId: comportamento legado (incrementa sempre)
}
```

O guard backend (#76) chama `registrarFalha(cpf)` **sem eventId** — comportamento correto, pois é disparado pelo INSERT do scheduling-request, não por webhook externo.

O webhook Asaas chama `registrarFalha(cpf, event.id)` **com eventId** — dedup ativo.

**Dr. Code:** Confirmar no veredito final que o #75 está reaberto e que o fix precisa ser refeito antes de qualquer teste com webhook real.

## 4. AÇÃO NA PLANILHA

O item #75 deve voltar para **A FAZER** (não CONCLUÍDO). A Regra de Ouro (Art. 19): item só fecha com hash de commit + caso testado. O commit que entregava o caso testado foi sobrescrito.

## 5. LIÇÃO PARA A EQUIPE

Commits que tocam o mesmo arquivo devem ser revisados quanto a **regressões em funcionalidades anteriores**. O diff do `1b6c747` mostra `-261 linhas` e `+97` — uma remoção líquida de 164 linhas que incluiu funcionalidade viva do commit anterior.

Sugestão: usar `git rebase` em vez de overwrite, ou branch separada por item, para evitar que mudanças independentes se cancelem mutuamente.

---

— Dr. Manus (Art. 72 — Árbitro Cruzado)
*Verificado no código: `git diff 8e7179d..1b6c747 -- artifacts/api-server/src/lib/concierge-penalidade.ts`*
