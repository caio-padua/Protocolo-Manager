# CARTA — DR. MANUS (ÁRBITRO CRUZADO, Art. 72) — INSTRUÇÕES PARA DR. REPLT

**Data:** 12/08/2026
**De:** Dr. Manus (com aval do CEO Dr. Caio)
**Para:** Dr. Replit
**Assunto:** ORDEM DE EXECUÇÃO — #75 com eventId obrigatório + caso 21 + padronização planilha

---

## ORDENADO PELO CEO DR. CAIO

Esta carta tem aval direto do CEO. Execute na ordem abaixo, sem desvios.

---

## TAREFA 1 — REFZER #75 (IDEMPOTÊNCIA COM EVENTID OBRIGATÓRIO)

### Correção técnica do Dr. Code (aceita por mim e pelo CEO):

O `eventId` deve ser **OBRIGATÓRIO** — não opcional. Sem exceção.

```typescript
// ANTES (errado — porta aberta para regressão):
export async function registrarFalha(
  rawCpf: string | null | undefined,
  eventId?: string,  // ← OPCIONAL = porta aberta
): Promise<void>

// DEPOIS (correto — toda penalidade rastreável):
export async function registrarFalha(
  rawCpf: string | null | undefined,
  eventId: string,  // ← OBRIGATÓRIO
): Promise<void>
```

### Alvo correto (corrigido pelo Dr. Manus — minha carta anterior estava errada):

**O guard #76 NÃO chama registrarFalha.** Ele apenas bloqueia. O alvo é o **POLLING** (linha 789 do scheduling.ts):

```typescript
// Linha 789 (polling) — DEVE gerar eventId determinístico com timestamp:
const eventId = `poll:${row.id}:${mapped}:${Date.now()}`;
registrarFalha(row.patientCpf, eventId);
```

**Incluir timestamp** para evitar colisão quando um pedido expira, é reaberto, e expira de novo (corrigido pelo Dr. Code).

### Webhook Asaas (rotas/asaas.ts):

```typescript
// Usar event.id do payload Asaas:
registrarFalha(eventData.payment.cpf, event.id);
```

### Implementação da tabela de dedup:

```sql
CREATE TABLE IF NOT EXISTS concierge_webhook_eventos (
  event_id       TEXT        NOT NULL PRIMARY KEY,
  cpf            TEXT        NOT NULL,
  processado_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
)
```

### CTE atômico:

```typescript
// dedup + UPSERT em um único SQL
await db.execute(sql`
  WITH dedup AS (
    INSERT INTO concierge_webhook_eventos (event_id, cpf)
    VALUES (${eventId}, ${cpf})
    ON CONFLICT (event_id) DO NOTHING
    RETURNING event_id
  )
  INSERT INTO concierge_penalidades (cpf, tentativas_falha, ...)
  SELECT ${cpf}, COALESCE((SELECT tentativas_falha FROM concierge_penalidades WHERE cpf = ${cpf}), 0) + 1, ...
  FROM dedup
`);
```

**SEM caminho legado que incrementa sempre.** Toda chamada de `registrarFalha` precisa de um eventId.

---

## TAREFA 2 — CRIAR CASO 21 (TESTE DO GUARD BACKEND #76)

O guard #76 está marcado CONCLUÍDO mas não tem teste automatizado. Só tem um curl manual que não sobrevive à próxima refatoração.

```typescript
// Teste: POST /scheduling/requests com path=concierge e CPF bloqueado
// Esperado: 403 { code: "CONCIERGE_BLOCKED" }

// Setup:
// INSERT INTO concierge_penalidades (cpf, tentativas_falha, bloqueado_permanente)
// VALUES ('12345678900', 3, true) ON CONFLICT DO NOTHING

// Teste:
// POST /scheduling/requests body: { entrada: "dr_caio", path: "concierge", patientCpf: "12345678900", ... }
// Assert: status 403, code "CONCIERGE_BLOCKED"

// Teste negativo (CPF não bloqueado):
// POST /scheduling/requests com CPF limpo
// Assert: status 200, pedido criado normalmente
```

Adicione este caso como teste automatizado no arquivo `concierge-penalidade.test.ts`.

---

## TAREFA 3 — PADRONIZAR LINHAS DA PLANILHA

As linhas 71-73 (itens #74-#76) usam ordem de colunas diferente das linhas 64-70 (itens #57-#63). Qualquer script que leia por posição vai ler errado.

Reescreva as linhas 71-73 na mesma ordem das linhas 64-70:

```
Col A: Nº do item
Col B: Data
Col C: Hora
Col D: Descrição
Col E: Responsável
Col F: Estado
Col G: Prioridade
Col H: Depende de
```

---

## TAREFA 4 — CORRIGIR POST DAS 23:09 NO SLACK

O post das 23:09 diz "#74, #75, #76 CONCLUÍDO" — mas o #75 está reaberto por regressão. Poste um reply em thread apontando para o alerta de regressão:

> "Correção: #75 reaberto por regressão no commit 1b6c747. Status atual: A FAZER - REGRESSAO."

---

## TAREFA 5 — SOBRE O #73 (ENDPOINT DE VERIFICAÇÃO)

O #73 foi subido de P2 para **P1** por decisão do CEO. Este endpoint verifica se os itens da planilha estão realmente CONCLUÍDO no código. A partir de agora, **nenhum item pode fechar sem o #73 rodar verde**.

Sua parte: quando o #73 estiver implementado (Dr. Code), o bloco A (verificação por push) deve rodar em cada push. Item não fecha sem verde.

---

## O QUE NÃO FAZER

- NÃO mexer no guard #76 (linha 495) — ele está correto, apenas bloqueia
- NÃO criar caminho legado sem eventId
- NÃO usar `new Date()` — sempre `brtNow()` de `lib/brt.ts`
- NÃO dropar coluna ou tabela — toda mudança = ADD COLUMN
- NÃO marcar CONCLUÍDO sem caso testado colado

---

## QUANDO TERMINAR

1. Commit com hash rastreável
2. Caso testado (curl ou test automatizado) colado no commit ou na planilha
3. Postar no Slack: "Item #75 CONCLUÍDO — commit {hash} — caso testado: {output}"
4. Atualizar planilha (coluna F72 → CONCLUÍDO)

---

— Dr. Manus (Art. 72 — Árbitro Cruzado)
*Ordenado pelo CEO Dr. Caio*
