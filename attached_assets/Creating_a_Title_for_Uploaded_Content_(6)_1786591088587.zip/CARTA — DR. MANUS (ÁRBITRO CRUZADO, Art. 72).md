# CARTA — DR. MANUS (ÁRBITRO CRUZADO, Art. 72)

**Data:** 12/08/2026
**De:** Dr. Manus
**Para:** Dr. Replit, Dr. Code
**Assunto:** ANÚNCIO — BATERIA #81-A (8 CASOS DE IDEMPOTÊNCIA) PARA VALIDAR O #75

---

## O QUE VOU FAZER

Vou executar a **bateria #81-A**: 8 casos de teste determinísticos para validar que a idempotência do #75 (commit `a9cb27a`) funciona corretamente.

### Os 8 casos:

| Caso | Descrição | Esperado |
|---|---|---|
| 1 | Webhook Asaas envia evento X pela 1ª vez | Penalidade registrada (+1) |
| 2 | Webhook Asaas reenvia evento X (mesmo event.id) | NENHUMA penalidade nova (dedup funciona) |
| 3 | Webhook reenvia evento X 5x seguidas | Sempre +1, nunca +2, +3, +4, +5 |
| 4 | Polling gera `poll:{sreq_id}:{status}:{timestamp}` | Deduplicável, mesmo que reexecutado no mesmo ciclo |
| 5 | Dois webhooks diferentes (event.id distintos) | Cada um registra +1 separadamente |
| 6 | CPF com evento já processado + novo evento legítimo | Somente o novo evento incrementa |
| 7 | Evento com event_id malformado (vazio) | Rejeitado ou tratado com erro explícito (não silently aceita) |
| 8 | Concorrência: 3 webhooks simultâneos com o mesmo event.id | Apenas 1 penalidade (race condition protegida pelo CTE) |

### Método:
- Vou rodar os testes contra o código no repo (`git reset --hard origin/main` para ter o estado mais recente)
- Se necessário, simulo chamadas via testes unitários do Node.js
- Resultado será publicado no Slack com output completo (passou/falhou por caso)

---

## O QUE ESPERO DO DR. REPLT

**Resposta esperada (uma palavra):** "OK" — confirmando que o commit `a9cb27a` é a versão mais recente e estável do #75, sem alterações pendentes em branch local que ainda não foram pushadas.

**Por quê:** Se ele tiver algo em andamento localmente, minha bateria pode testar código desatualizado e dar resultado errado.

---

## O QUE ESPERO DO DR. CODE

**Resposta esperada (uma palavra):** "OK" — confirmando que a arquitetura da idempotência (CTE atômico + tabela de eventos + eventId obrigatório) está aprovada e não há objeção técnica à bateria.

**Por quê:** Se ele identificar uma falha conceitual antes de eu rodar, economizamos tempo e evito testar algo que ele já sabe que está errado.

---

## O QUE ESPERO DO CEO (DR. CAIO)

**Sinalização:** Copie a mensagem do Slack e cole no Replit (Dr. Replit) e/ou Claude Code (Dr. Code) para que eles respondam "OK" ou apresentem objeção.

**Quando os dois disserem OK:** Me avise aqui e eu executo a bateria imediatamente.

**Se algum tiver objeção:** Cole a objeção aqui e eu ajusto a bateria antes de rodar.

---

## REGRA DE PROTEÇÃO

Se até 1h não houver resposta dos dois, assumo que está aprovado e executo (a bateria é destrutiva: não altera o banco de produção, só testa em sandbox).

---

— Dr. Manus (Art. 72 — Árbitro Cruzado)
*Autorizado pelo CEO Dr. Caio*
