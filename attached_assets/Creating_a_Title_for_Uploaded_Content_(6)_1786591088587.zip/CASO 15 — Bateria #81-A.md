# CASO 15 — Bateria #81-A
## Mesmo sreq, dois desfechos distintos → AMBAS devem registrar

---

## Cenário:

```
sreqId = 42
patientCpf = "11122233344"
asaasChargeId = "pay_abc123"

Evento 1: PAYMENT_OVERDUE (cobrança expirou)
  → polling detecta expirado
  → registra shared:42:pay_abc123:expirado

Evento 2: PAYMENT_CHARGEBACK_REQUESTED (chargeback depois)
  → polling detecta chargeback (mesmo sreq, chargeId diferente ou não)
  → registra shared:42:pay_abc123:chargeback
```

## O que o teste faz:

1. Insere sreq 42 com chargeId "pay_abc123" e status "expirado"
2. Chama `registrarFalha("11122233344", "shared:42:pay_abc123:expirado", 42)`
3. Chama `registrarFalha("11122233344", "shared:42:pay_abc123:chargeback", 42)`
4. Consulta `tentativas_falha` para o CPF

## Asserções:

| # | Asserção | O que prova |
|---|---|---|
| 1 | `tentativas_falha >= 2` | Ambos registraram (sem guard engolindo) |
| 2 | `score >= 1.0` | OVERDUE (1.0) foi registrado |
| 3 | `score >= 3.0` | CHARGEBACK (+2.0) foi registrado por cima |
| 4 | Duas linhas distintas em `concierge_webhook_eventos` | PK não conflitou entre desfechos distintos |

## Nota sobre dependência do #77:

Se o #77 (pesos fracionários) ainda não foi implementado, a asserção usa o modelo v1:
- OVERDUE = +1 ponto
- CHARGEBACK = +1 ponto (ou +2 se #77 já entrou)

O que importa é: **tentativas_falha >= 2** — prova que ambos registraram.

## Por que este caso é o único que pega o defeito 9A:

O guard `jaTemEventoParaSreq(42)` retorna `true` após o Evento 1.
Sem o fix, o Evento 2 NUNCA chega no CTE → `tentativas_falha = 1` → FALHA.
Com o fix, o Evento 2 chega direto no CTE → `tentativas_falha = 2` → PASSA.
