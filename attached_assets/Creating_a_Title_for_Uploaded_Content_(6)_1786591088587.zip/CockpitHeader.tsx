/**
 * CockpitHeader — Faixa superior unificada (Onda Fusão 2.0, 23/07/2026)
 *
 * Decisão do CEO (redesenho aprovado): a identidade do paciente vive DIRETAMENTE
 * no cabeçalho navy/ouro. O ClientPicker fica à direita, junto com ações rápidas
 * (Editar, Drive, Protocolo). Elimina a redundância com o ClienteCracha inferior.
 *
 * Conformidade Skill Layout Paxter:
 *   - Gradiente navy #1e3668 → #16294a → #0f1e3a
 *   - Borda ouro rgba(231,205,143,0.25)
 *   - Botões btn-3d-soft / btn-3d
 *   - Fonte var(--app-font-display) no título
 *
 * Animação: Motion (framer-motion v12) para entrada/exit da identidade.
 */
import { useMemo } from "react";

import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Pencil,
  FolderOpen,
  Plus,
  Loader2,
  ShieldCheck,
  ShieldAlert,
  CalendarDays,
  UserRound,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { ClientPicker } from "@/components/ClientPicker";
import { useCockpitStore } from "./store";
import type { Client } from "@workspace/api-client-react";

// ─── Constantes visuais ──────────────────────────────────────────────────────

const NAVY = "#16294a";
const GOLD = "#9a7b32";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function idade(birthDate: string | null | undefined): number | null {
  if (!birthDate) return null;
  const raw = birthDate.replace("T00:00:00.000Z", "");
  const parts = raw.split("-");
  if (parts.length !== 3) return null;
  const [y, m, d] = parts.map(Number);
  if (Number.isNaN(y) || Number.isNaN(m) || Number.isNaN(d)) return null;
  const today = new Date();
  const dob = new Date(y, m - 1, d);
  let age = today.getFullYear() - dob.getFullYear();
  const mDiff = today.getMonth() - dob.getMonth();
  if (mDiff < 0 || (mDiff === 0 && today.getDate() < dob.getDate())) age--;
  return age;
}

// ─── Motion variants ─────────────────────────────────────────────────────────

const identityEnter = {
  initial: { opacity: 0, x: -12, scale: 0.97 },
  animate: { opacity: 1, x: 0, scale: 1, transition: { duration: 0.28, ease: [0.22, 1, 0.36, 1] } },
  exit: { opacity: 0, x: 8, scale: 0.97, transition: { duration: 0.15 } },
};

// ─── Componente ──────────────────────────────────────────────────────────────

interface CockpitHeaderProps {
  /** Lista de clientes para o picker. */
  opcoes: { id: number; name: string; cpf?: string | null }[];
  /** Cliente selecionado (do useGetClient). */
  client: Client | undefined;
  /** Callback para o Google Drive setup. */
  onDriveSetup: () => void;
  /** Estado de loading do Drive. */
  drivePending: boolean;
  /** Se há red flag no crachá. */
  hasRedFlag: boolean;
}

export default function CockpitHeader({
  opcoes,
  client,
  onDriveSetup,
  drivePending,
  hasRedFlag,
}: CockpitHeaderProps) {
  const clienteId = useCockpitStore((s) => s.clienteId);
  const setClienteId = useCockpitStore((s) => s.setClienteId);

  // Dados derivados
  const anos = useMemo(() => idade(client?.birthDate), [client?.birthDate]);
  const nome = client?.name ?? "";
  const cpf = client?.cpf ?? "";
  const photoUrl = client?.photoUrl ?? null;

  return (
    <header
      className="flex flex-wrap items-center justify-between gap-4 px-5 py-4"
      style={{
        background: "linear-gradient(180deg,#1e3668 0%,#16294a 55%,#0f1e3a 100%)",
        borderBottom: "1px solid rgba(231,205,143,0.25)",
        boxShadow: "0 4px 24px rgba(0,0,0,0.35)",
      }}
    >
      {/* ── LADO ESQUERDO: Branding + Identidade do paciente ── */}
      <div className="flex items-center gap-5 flex-wrap">
        {/* Branding */}
        <div className="flex flex-col gap-0.5 shrink-0">
          <span className="text-[10px] font-semibold uppercase tracking-[0.30em] text-slate-400">
            Padcon Conect
          </span>
          <span
            className="text-[18px] font-bold leading-tight tracking-[0.08em] uppercase"
            style={{
              fontFamily: "var(--app-font-display)",
              color: "#e7cd8f",
              textShadow: "0 1px 8px rgba(0,0,0,0.55)",
            }}
          >
            Cockpit da Consulta
          </span>
        </div>

        {/* Separador vertical dourado */}
        <div
          className="h-12 w-px shrink-0 self-center"
          style={{ background: "linear-gradient(180deg, transparent, rgba(231,205,143,0.5), transparent)" }}
        />

        {/* Identidade do paciente (AnimatePresence para transição suave) */}
        <AnimatePresence mode="wait">
          {clienteId != null && client ? (
            <motion.div
              key={`identity-${clienteId}`}
              className="flex items-center gap-3 shrink-0"
              {...identityEnter}
            >
              {/* Avatar com moldura ouro */}
              <div
                className="relative flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-[6px] overflow-hidden"
                style={{
                  border: `2px solid ${GOLD}`,
                  boxShadow: `0 2px 10px ${GOLD}33`,
                  background: "#eef1f5",
                }}
              >
                {photoUrl ? (
                  <Avatar className="h-full w-full rounded-[4px]">
                    <AvatarImage src={photoUrl} alt={nome} />
                    <AvatarFallback className="rounded-[4px] bg-slate-200 text-slate-500">
                      <UserRound className="h-6 w-6" />
                    </AvatarFallback>
                  </Avatar>
                ) : (
                  <UserRound className="h-6 w-6" style={{ color: "#9aa7b6" }} />
                )}
                {/* LED de alarme (canto inferior direito) */}
                {hasRedFlag && (
                  <div
                    className="absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-[#0f1e3a]"
                    style={{ background: "#ef4444", boxShadow: "0 0 6px rgba(239,68,68,0.6)" }}
                  />
                )}
              </div>

              {/* Nome + meta */}
              <div className="min-w-0">
                <div
                  className="truncate text-[16px] font-bold leading-tight tracking-[0.02em]"
                  style={{
                    fontFamily: "var(--app-font-display)",
                    color: "#e7cd8f",
                    textShadow: "0 1px 4px rgba(0,0,0,0.4)",
                  }}
                  title={nome}
                >
                  {nome}
                </div>
                <div className="flex items-center gap-2 mt-0.5 text-[10px] font-semibold uppercase tracking-[0.10em] text-slate-400">
                  <span className="flex items-center gap-1">
                    <CalendarDays className="h-2.5 w-2.5" />
                    {anos != null ? `${anos} anos` : "—"}
                  </span>
                  {cpf && (
                    <>
                      <span style={{ color: "rgba(231,205,143,0.3)" }}>·</span>
                      <span>CPF {cpf}</span>
                    </>
                  )}
                  <span style={{ color: "rgba(231,205,143,0.3)" }}>·</span>
                  <span
                    className="flex items-center gap-1"
                    style={{ color: hasRedFlag ? "#ef4444" : "#34d399" }}
                  >
                    {hasRedFlag
                      ? <><ShieldAlert className="h-2.5 w-2.5" /> Alerta</>
                      : <><ShieldCheck className="h-2.5 w-2.5" /> Sem alarme</>
                    }
                  </span>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              className="flex items-center gap-2 shrink-0"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <UserRound className="h-5 w-5 text-slate-500" />
              <span className="text-[11px] font-bold uppercase tracking-widest text-slate-500">
                Selecione o cliente
              </span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── LADO DIREITO: Ações + Picker ── */}
      <div className="flex items-center gap-3 flex-wrap">
        {client && (
          <div className="flex items-center gap-2">
            <Link href={`/clients/${client.id}/edit`}>
              <Button className="btn-3d-soft h-8 text-[10px] font-black px-3">
                <Pencil className="w-3 h-3 mr-1.5" /> EDITAR
              </Button>
            </Link>
            <Button
              className="btn-3d-soft h-8 text-[10px] font-black px-3"
              onClick={onDriveSetup}
              disabled={drivePending}
            >
              {drivePending
                ? <Loader2 className="w-3 h-3 mr-1.5 animate-spin" />
                : <FolderOpen className="w-3 h-3 mr-1.5" />}
              DRIVE
            </Button>
            <Link href={`/protocols/new?clientId=${client.id}`}>
              <Button className="btn-3d-gold h-8 text-[10px] font-black px-3">
                <Plus className="w-3 h-3 mr-1.5" /> PROTOCOLO
              </Button>
            </Link>
          </div>
        )}
        <ClientPicker
          clientes={opcoes}
          value={clienteId}
          onChange={(id) => setClienteId(id)}
          placeholder="Selecionar cliente…"
          triggerClassName="min-w-[260px] bg-white/95 text-[#16294a] font-semibold shadow-lg"
        />
      </div>
    </header>
  );
}
