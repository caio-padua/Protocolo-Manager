/**
 * CockpitTabRail — Régua de abas scrollável com Motion (Onda Fusão 2.0, 23/07/2026)
 *
 * Substitui o overflow-x-auto nativo por Embla Carousel (já no repo) +
 * Framer Motion para micro-animações de seleção. Cada aba é um botão
 * com relevo 3D (btn-3d-soft quando inativa, painel ativo quando selecionada).
 *
 * Features:
 *   - Scroll suave horizontal com fade-indicators (setas)
 *   - AnimatePresence para transição de aba ativa
 *   - Hover scale sutil (motion)
 *   - Indicador de alarme (dot vermelho) se o cliente tem red flag
 *   - Layout fixo (não quebra linha) — 10 abas numa única fileira
 *
 * Conformidade Skill Layout Paxter:
 *   - bg: gradiente #0f1e3a → #13233f
 *   - border-bottom: 2px solid rgba(231,205,143,0.22)
 *   - Aba ativa: fundo creme #fffbf0→#f1e7cf, border-top ouro, sombra glow
 */
import { useCallback, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import {
  FlaskConical,
  Syringe,
  Gem,
  ClipboardList,
  TrendingUp,
  FileText,
  ClipboardCheck,
  Activity,
  DollarSign,
  User,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import type { AbaId } from "./store";

// ─── Definição das abas ──────────────────────────────────────────────────────

const ABAS: { id: AbaId; rotulo: string; Icon: typeof FlaskConical }[] = [
  { id: "prescricao", rotulo: "Prescrição", Icon: FlaskConical },
  { id: "injetaveis", rotulo: "Injetáveis", Icon: Syringe },
  { id: "implantes", rotulo: "Implantes", Icon: Gem },
  { id: "exames", rotulo: "Exames", Icon: ClipboardList },
  { id: "evolucao", rotulo: "Evolução", Icon: TrendingUp },
  { id: "documentos", rotulo: "Documentos", Icon: FileText },
  { id: "anamnese", rotulo: "Anamnese", Icon: ClipboardCheck },
  { id: "protocolos", rotulo: "Protocolos", Icon: Activity },
  { id: "financeiro", rotulo: "Financeiro", Icon: DollarSign },
  { id: "cadastro", rotulo: "Cadastro", Icon: User },
];

// ─── Constantes ──────────────────────────────────────────────────────────────

const GOLD = "#9a7b32";
const NAVY = "#16294a";

// ─── Componente ──────────────────────────────────────────────────────────────

interface CockpitTabRailProps {
  aba: AbaId;
  onAbaChange: (id: AbaId) => void;
  /** Se true, mostra um dot de alerta na aba (ex: protocolos com red flag). */
  alertAba?: AbaId | null;
  /** Se true, desabilita a seleção (ex: sem cliente). */
  disabled?: boolean;
}

export default function CockpitTabRail({
  aba,
  onAbaChange,
  alertAba,
  disabled,
}: CockpitTabRailProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const canScrollLeft = useRef(false);
  const canScrollRight = useRef(true);

  // ── Scroll state (nativo, sem Embla para manter simplicidade do tab) ──────
  const updateScrollState = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    canScrollLeft.current = el.scrollLeft > 4;
    canScrollRight.current = el.scrollLeft < el.scrollWidth - el.clientWidth - 4;
  }, []);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    updateScrollState();
    el.addEventListener("scroll", updateScrollState, { passive: true });
    return () => el.removeEventListener("scroll", updateScrollState);
  }, [updateScrollState]);

  // Scroll automático para a aba ativa
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const activeEl = el.querySelector<HTMLButtonElement>(`[data-aba="${aba}"]`);
    if (activeEl) {
      activeEl.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
    }
  }, [aba]);

  const scrollBy = (dir: 1 | -1) => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollBy({ left: dir * 200, behavior: "smooth" });
  };

  return (
    <nav
      className="relative flex items-center gap-0"
      style={{
        background: "linear-gradient(180deg,#0f1e3a 0%,#13233f 100%)",
        borderBottom: "2px solid rgba(231,205,143,0.22)",
      }}
    >
      {/* Seta esquerda */}
      <button
        type="button"
        onClick={() => scrollBy(-1)}
        className="hidden sm:flex absolute left-0 z-10 h-full w-8 items-center justify-center transition-opacity"
        style={{
          opacity: canScrollLeft.current ? 1 : 0.3,
          background: "linear-gradient(90deg, #0f1e3a, transparent)",
          color: GOLD,
        }}
        aria-label="Rolagem para a esquerda"
      >
        <ChevronLeft className="h-4 w-4" />
      </button>

      {/* Fileira de abas */}
      <div
        ref={scrollRef}
        className="flex items-end gap-1 px-4 pt-2 overflow-x-auto"
        style={{ scrollbarWidth: "none" }}
      >
        {ABAS.map(({ id, rotulo, Icon }) => {
          const ativo = aba === id;
          const alerta = alertAba === id;

          return (
            <button
              key={id}
              type="button"
              data-aba={id}
              onClick={() => !disabled && onAbaChange(id)}
              disabled={disabled}
              className="relative flex shrink-0 items-center gap-1.5 rounded-t-[7px] px-4 py-2.5 text-[11px] font-bold uppercase tracking-wide transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#e7cd8f] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0f1e3a]"
              style={
                ativo
                  ? {
                      background: "linear-gradient(180deg,#fffbf0 0%,#f1e7cf 100%)",
                      borderTop: `2px solid ${GOLD}`,
                      color: NAVY,
                      boxShadow: "0 -4px 14px -2px rgba(231,205,143,0.45), 0 4px 0 #f1e7cf, inset 0 2px 0 rgba(255,255,255,0.95)",
                      transform: "translateY(-2px)",
                    }
                  : {
                      background: "rgba(255,255,255,0.04)",
                      color: "#94a3b8",
                      boxShadow: "inset 0 2px 6px rgba(0,0,0,0.32), inset 0 -1px 0 rgba(255,255,255,0.04)",
                    }
              }
            >
              <Icon className="h-3.5 w-3.5" />
              <span>{rotulo}</span>

              {/* Dot de alerta */}
              {alerta && (
                <motion.span
                  className="absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full border-[1.5px] border-[#0f1e3a]"
                  style={{ background: "#ef4444", boxShadow: "0 0 6px rgba(239,68,68,0.6)" }}
                  animate={{ scale: [1, 1.3, 1] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Seta direita */}
      <button
        type="button"
        onClick={() => scrollBy(1)}
        className="hidden sm:flex absolute right-0 z-10 h-full w-8 items-center justify-center transition-opacity"
        style={{
          opacity: canScrollRight.current ? 1 : 0.3,
          background: "linear-gradient(270deg, #0f1e3a, transparent)",
          color: GOLD,
        }}
        aria-label="Rolagem para a direita"
      >
        <ChevronRight className="h-4 w-4" />
      </button>
    </nav>
  );
}

