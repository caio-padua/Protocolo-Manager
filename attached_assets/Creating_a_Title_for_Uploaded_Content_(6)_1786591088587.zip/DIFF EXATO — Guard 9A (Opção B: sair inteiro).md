# DIFF EXATO — Guard 9A (Opção B: sair inteiro)
## Para Dr. Replit aplicar e commitar

---

## ARQUIVO 1: `artifacts/api-server/src/lib/concierge-penalidade.ts`

### Remover (linhas ~310-320):

```ts
// ❌ REMOVER INTEIRO:
export async function jaTemEventoParaSreq(
  schedulingRequestId: number,
): Promise<boolean> {
  // ... SELECT 1 FROM concierge_webhook_eventos
  //   WHERE scheduling_request_id = $1
}
```

### Adicionar (mesmo arquivo, junto da migração):

```ts
// ✅ ADICIONAR — 3 colunas na tabela concierge_webhook_eventos:
// scheduling_request_id INT
// desfecho TEXT  (canonical: "expirado" | "cancelado" | "chargeback")
// asaas_event_id TEXT NULL
```

---

## ARQUIVO 2: `artifacts/api-server/src/routes/scheduling.ts`

### Antes (linha ~797):

```ts
// ❌ ANTES:
jaTemEventoParaSreq(row.id)
  .then((jaRegistrou) => {
    if (jaRegistrou) {
      // PULA — NÃO chama registrarFalha
      return;
    }
    return registrarFalha(row.patientCpf, sharedEventId, row.id);
  })
```

### Depois:

```ts
// ✅ DEPOIS — chama direto, o CTE ON CONFLICT faz a dedup:
registrarFalha(row.patientCpf, sharedEventId, row.id);
```

---

## ARQUIVO 3: `docs/concierge/ARQUITETURA.md`

### Corrigir seção 5.3:

```
❌ ANTES: "guard 9A fica"
✅ DEPOIS: "guard 9A removido — a PK do eventId deduplica tudo.
            Duas chamadas do mesmo fato → ON CONFLICT DO NOTHING."
```

---

## COMANDOS DE VERIFICAÇÃO (obrigatórios na entrega)

```bash
# 1. git diff --stat do commit
git diff --stat HEAD~1

# 2. Confirmar que jaTemEventoParaSreq não existe mais
git grep -n "jaTemEventoParaSreq"

# 3. Confirmar que as 3 colunas estão na tabela
grep -A5 "scheduling_request_id" artifacts/api-server/src/lib/concierge-penalidade.ts
```

---

## EXPECTED RESULT:
- `git grep jaTemEventoParaSreq` → nenhuma ocorrência
- Polling chama `registrarFalha()` diretamente (sem guard)
- Webhook chama `registrarFalha()` diretamente (já chamava)
- Tabela tem 3 colunas novas: `scheduling_request_id`, `desfecho`, `asaas_event_id`
