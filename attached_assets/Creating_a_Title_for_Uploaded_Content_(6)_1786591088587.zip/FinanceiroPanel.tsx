/**
 * FinanceiroPanel — Aba Financeiro (Onda Fusão 2.0, 23/07/2026)
 *
 * Extraído do cockpit-cliente/index.tsx monólito (linhas 642-868).
 * KPIs (Total Pago / Pendente), formulário Asaas, formulário pagamento manual,
 * histórico de pagamentos.
 *
 * Estado: gerido pelo Zustand store (showPaymentForm, payMethod, etc.).
 * Mutations: criadas localmente com useMutation + useToast.
 */
import { useMemo } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import {
  DollarSign,
  Plus,
  Zap,
  Loader2,
  QrCode,
  CreditCard,
  Receipt,
  Banknote,
  ExternalLink,
  CreditCard as CreditCardIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useListPayments, getListPaymentsQueryKey } from "@workspace/api-client-react";
import { useCockpitStore } from "../store";
import type { PayMethod } from "../store";

const METHOD_ICONS: Record<string, JSX.Element> = {
  pix: <QrCode className="w-4 h-4" />,
  credit: <CreditCard className="w-4 h-4" />,
  debit: <CreditCard className="w-4 h-4" />,
  boleto: <Receipt className="w-4 h-4" />,
  cash: <Banknote className="w-4 h-4" />,
  credit_card: <CreditCard className="w-4 h-4" />,
  debit_card: <CreditCard className="w-4 h-4" />,
  transfer: <Banknote className="w-4 h-4" />,
};

const METHOD_LABELS: Record<string, string> = {
  pix: "PIX", credit: "CRÉDITO", debit: "DÉBITO", boleto: "BOLETO",
  cash: "DINHEIRO", credit_card: "CARTÃO CRÉDITO", debit_card: "CARTÃO DÉBITO",
  transfer: "TRANSFERÊNCIA", insurance: "CONVÊNIO", asaas: "ASAAS (LINK)",
};

function brl(v: number) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v);
}

export default function FinanceiroPanel({ clientId }: { clientId: number }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const apiBase = import.meta.env.VITE_API_URL || "/api";

  // Estado do store
  const showPaymentForm = useCockpitStore((s) => s.showPaymentForm);
  const payMethod = useCockpitStore((s) => s.payMethod);
  const payAmount = useCockpitStore((s) => s.payAmount);
  const payDate = useCockpitStore((s) => s.payDate);
  const payInstallments = useCockpitStore((s) => s.payInstallments);
  const payCardLabel = useCockpitStore((s) => s.payCardLabel);
  const payDescription = useCockpitStore((s) => s.payDescription);
  const showAsaasForm = useCockpitStore((s) => s.showAsaasForm);
  const asaasAmount = useCockpitStore((s) => s.asaasAmount);
  const asaasDesc = useCockpitStore((s) => s.asaasDesc);
  const asaasDate = useCockpitStore((s) => s.asaasDate);

  const setPayMethod = useCockpitStore((s) => s.setPayMethod);
  const setPayAmount = useCockpitStore((s) => s.setPayAmount);
  const setPayDate = useCockpitStore((s) => s.setPayDate);
  const setPayInstallments = useCockpitStore((s) => s.setPayInstallments);
  const setPayCardLabel = useCockpitStore((s) => s.setPayCardLabel);
  const setPayDescription = useCockpitStore((s) => s.setPayDescription);
  const resetPaymentForm = useCockpitStore((s) => s.resetPaymentForm);
  const openAsaasForm = useCockpitStore((s) => s.openAsaasForm);
  const closeAsaasForm = useCockpitStore((s) => s.closeAsaasForm);
  const setAsaasAmount = useCockpitStore((s) => s.setAsaasAmount);
  const setAsaasDesc = useCockpitStore((s) => s.setAsaasDesc);
  const setAsaasDate = useCockpitStore((s) => s.setAsaasDate);
  const resetAsaasForm = useCockpitStore((s) => s.resetAsaasForm);
  const openPaymentForm = useCockpitStore((s) => s.openPaymentForm);
  const closePaymentForm = useCockpitStore((s) => s.closePaymentForm);

  // Dados
  const { data: payments, isLoading: loadingPayments } = useListPayments(
    { clientId },
    { query: { enabled: !!clientId, queryKey: getListPaymentsQueryKey({ clientId }) } },
  );

  // KPIs
  const totalPago = useMemo(
    () => (payments ?? []).filter(p => p.status === "paid").reduce((s, p) => s + p.amount, 0),
    [payments],
  );
  const totalPendente = useMemo(
    () => (payments ?? []).filter(p => p.status === "pending" || p.status === "overdue").reduce((s, p) => s + p.amount, 0),
    [payments],
  );

  // Mutations
  const createPayment = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${apiBase}/payments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientId,
          amount: parseFloat(payAmount),
          method: payMethod,
          status: "paid",
          paidAt: payDate,
          description: payDescription || `${payMethod.toUpperCase()} - ${payDate}`,
          installments: payMethod === "credit" ? parseInt(payInstallments) : null,
          cardLabel: payMethod === "credit" ? payCardLabel : null,
        }),
      });
      if (!res.ok) throw new Error(await res.text());
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Pagamento registrado!" });
      queryClient.invalidateQueries({ queryKey: getListPaymentsQueryKey({ clientId }) });
      resetPaymentForm();
    },
    onError: (err: Error) => toast({ title: "Erro", description: err.message, variant: "destructive" }),
  });

  const createAsaasCharge = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${apiBase}/asaas/charge`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientId,
          amount: parseFloat(asaasAmount),
          description: asaasDesc || undefined,
          dueDate: asaasDate || undefined,
        }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error((data as any).error || "Erro ao gerar cobrança");
      }
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({ title: "Cobrança gerada!", description: "Link de pagamento criado no Asaas." });
      queryClient.invalidateQueries({ queryKey: getListPaymentsQueryKey({ clientId }) });
      resetAsaasForm();
      if (data?.invoiceUrl) window.open(data.invoiceUrl, "_blank");
    },
    onError: (err: Error) => toast({ title: "Erro", description: err.message, variant: "destructive" }),
  });

  return (
    <div className="space-y-6">
      {/* KPI row */}
      <div className="grid grid-cols-2 gap-4">
        <div className="panel-3d-sub p-5 border-none text-center">
          <div className="text-[9px] font-black uppercase tracking-[0.2em] text-muted-foreground mb-2">Total Pago</div>
          <div
            className="text-3xl font-black tabular-nums"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#16a34a", fontVariantNumeric: "lining-nums tabular-nums" }}
          >
            {brl(totalPago)}
          </div>
        </div>
        <div className="panel-3d-sub p-5 border-none text-center">
          <div className="text-[9px] font-black uppercase tracking-[0.2em] text-muted-foreground mb-2">Pendente</div>
          <div
            className="text-3xl font-black tabular-nums"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: totalPendente > 0 ? "#dc2626" : "#6b7280", fontVariantNumeric: "lining-nums tabular-nums" }}
          >
            {brl(totalPendente)}
          </div>
        </div>
      </div>

      {/* Botões de ação */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="bevel-3d px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-widest inline-flex items-center gap-2 flex-1">
          <DollarSign className="h-3 w-3 text-primary" /> Lançamentos Financeiros
        </div>
        <Button
          className="btn-3d-soft h-8 text-[10px] font-black"
          onClick={openAsaasForm}
        >
          <Zap className="w-3.5 h-3.5 mr-1.5 text-primary" /> COBRAR PELO ASAAS
        </Button>
        <Button
          className="btn-3d h-8 text-[10px] font-black"
          onClick={openPaymentForm}
        >
          <Plus className="w-3.5 h-3.5 mr-1.5" /> NOVO PAGAMENTO
        </Button>
      </div>

      {/* Form Asaas */}
      {showAsaasForm && (
        <Card className="panel-3d border-primary/30 animate-in zoom-in-95 duration-200">
          <CardContent className="p-6 space-y-6">
            <div className="bevel-3d px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-widest inline-flex items-center gap-2">
              <Zap className="h-3 w-3 text-primary" /> Cobrança online (PIX / Boleto / Cartão)
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-1.5">
                <label className="text-[9px] uppercase tracking-[0.2em] font-black text-muted-foreground">Valor (R$) — mínimo 5,00</label>
                <Input type="number" step="0.01" min="5" placeholder="0,00" className="field-engraved h-10 text-sm font-bold" value={asaasAmount} onChange={e => setAsaasAmount(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <label className="text-[9px] uppercase tracking-[0.2em] font-black text-muted-foreground">Descrição (opcional)</label>
                <Input placeholder="Ex: Protocolo S1" className="field-engraved h-10 text-sm font-bold" value={asaasDesc} onChange={e => setAsaasDesc(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <label className="text-[9px] uppercase tracking-[0.2em] font-black text-muted-foreground">Vencimento (opcional)</label>
                <Input type="date" className="field-engraved h-10 text-sm font-bold" value={asaasDate} onChange={e => setAsaasDate(e.target.value)} />
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <Button className="btn-3d-soft" onClick={closeAsaasForm}>CANCELAR</Button>
              <Button
                className="btn-3d px-6"
                onClick={() => createAsaasCharge.mutate()}
                disabled={!asaasAmount || parseFloat(asaasAmount) < 5 || createAsaasCharge.isPending}
              >
                {createAsaasCharge.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Zap className="w-4 h-4 mr-2" />}
                GERAR LINK DE PAGAMENTO
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Form pagamento manual */}
      {showPaymentForm && (
        <Card className="panel-3d border-primary/30 animate-in zoom-in-95 duration-200">
          <CardContent className="p-6 space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="space-y-1.5">
                <label className="text-[9px] uppercase tracking-[0.2em] font-black text-muted-foreground">Modalidade</label>
                <div className="concave-3d p-0.5">
                  <Select value={payMethod} onValueChange={(v) => setPayMethod(v as PayMethod)}>
                    <SelectTrigger className="border-none bg-transparent shadow-none focus:ring-0 h-9 text-sm font-bold"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pix">PIX</SelectItem>
                      <SelectItem value="credit">Crédito</SelectItem>
                      <SelectItem value="debit">Débito</SelectItem>
                      <SelectItem value="boleto">Boleto</SelectItem>
                      <SelectItem value="cash">Dinheiro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-[9px] uppercase tracking-[0.2em] font-black text-muted-foreground">Valor (R$)</label>
                <Input type="number" step="0.01" placeholder="0,00" className="field-engraved h-10 text-sm font-bold" value={payAmount} onChange={e => setPayAmount(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <label className="text-[9px] uppercase tracking-[0.2em] font-black text-muted-foreground">Data</label>
                <Input type="date" className="field-engraved h-10 text-sm font-bold" value={payDate} onChange={e => setPayDate(e.target.value)} />
              </div>
              {payMethod === "credit" && (
                <div className="space-y-1.5">
                  <label className="text-[9px] uppercase tracking-[0.2em] font-black text-muted-foreground">Parcelas</label>
                  <div className="concave-3d p-0.5">
                    <Select value={payInstallments} onValueChange={setPayInstallments}>
                      <SelectTrigger className="border-none bg-transparent shadow-none focus:ring-0 h-9 text-sm font-bold"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {[1,2,3,4,5,6,7,8,9,10,11,12].map(n => (
                          <SelectItem key={n} value={String(n)}>{n}x</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {payMethod === "credit" && (
                <div className="space-y-1.5">
                  <label className="text-[9px] uppercase tracking-[0.2em] font-black text-muted-foreground">Cartão (identificação)</label>
                  <Input placeholder="Ex: Nubank, Itaú Mastercard…" className="field-engraved h-10 text-sm font-bold" value={payCardLabel} onChange={e => setPayCardLabel(e.target.value)} />
                </div>
              )}
              <div className="space-y-1.5 flex-1">
                <label className="text-[9px] uppercase tracking-[0.2em] font-black text-muted-foreground">Descrição</label>
                <Input placeholder="Opcional — ex: Parcela 1/3" className="field-engraved h-10 text-sm font-bold" value={payDescription} onChange={e => setPayDescription(e.target.value)} />
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <Button className="btn-3d-soft" onClick={closePaymentForm}>CANCELAR</Button>
              <Button
                className="btn-3d px-6"
                onClick={() => createPayment.mutate()}
                disabled={!payAmount || createPayment.isPending}
              >
                {createPayment.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <DollarSign className="w-4 h-4 mr-2" />}
                REGISTRAR PAGAMENTO
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Histórico de pagamentos */}
      {loadingPayments ? (
        <Skeleton className="h-64 rounded-lg panel-3d-sub" />
      ) : !payments?.length ? (
        <div className="text-center py-16 panel-3d border-none bg-white/50">
          <CreditCardIcon className="mx-auto h-12 w-12 text-muted-foreground opacity-20 mb-4" />
          <p className="text-muted-foreground uppercase font-bold text-sm tracking-widest">Nenhum registro financeiro.</p>
        </div>
      ) : (
        <div className="panel-3d border-none overflow-hidden">
          <div className="divide-y divide-border/40">
            {payments.map(payment => {
              const methodIcon = METHOD_ICONS[payment.method as string] || <DollarSign className="w-4 h-4" />;
              const methodLabel = METHOD_LABELS[payment.method as string] || (payment.method as string).toUpperCase();
              const invoiceUrl = (payment as any).asaasInvoiceUrl as string | null;

              return (
                <div key={payment.id} className="p-5 flex items-center justify-between hover:bg-muted/30 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className={`w-11 h-11 panel-3d-sub flex items-center justify-center border-none shadow-sm ${payment.status === "paid" ? "text-emerald-600" : "text-amber-600"}`}>
                      {methodIcon}
                    </div>
                    <div>
                      <p className="font-black text-primary flex items-center gap-2 uppercase tracking-tight text-sm">
                        {methodLabel}
                        {(payment as any).installments && (
                          <span className="concave-3d px-1.5 py-0.5 text-[10px] lowercase text-muted-foreground">{(payment as any).installments}x</span>
                        )}
                        {(payment as any).cardLabel && (
                          <span className="text-[10px] font-bold text-muted-foreground/60">({(payment as any).cardLabel})</span>
                        )}
                      </p>
                      <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mt-1">
                        {payment.paidAt
                          ? format(new Date(payment.paidAt), "dd/MM/yyyy")
                          : payment.dueDate
                          ? `Venc: ${format(new Date(payment.dueDate), "dd/MM/yyyy")}`
                          : "—"}
                        {payment.description && <span className="mx-2 opacity-30">|</span>}
                        {payment.description}
                      </p>
                    </div>
                  </div>
                  <div className="text-right flex items-center gap-3">
                    {invoiceUrl && payment.status !== "paid" && (
                      <Button className="btn-3d h-8 text-[10px] font-black" onClick={() => window.open(invoiceUrl!, "_blank")}>
                        <ExternalLink className="w-3.5 h-3.5 mr-1.5" /> PAGAR
                      </Button>
                    )}
                    <div className="screen-3d px-3 py-1 font-black text-primary tabular-nums" style={{ fontFamily: "'Cormorant Garamond', serif", fontVariantNumeric: "lining-nums tabular-nums" }}>
                      {brl(payment.amount)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
