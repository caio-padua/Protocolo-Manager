/**
 * PADAXOR · Carta de Tratamento Premium
 * Filosofia local: classicismo clínico toscano, grelha ortogonal e leitura por varredura.
 * A marca PADAXOR conduz a capa; clínica emite; PADCON é proveniência discreta.
 * Fiação demonstrada: somente campos existentes em substances e protocol_items.
 */
import { useMemo, useState } from "react";

type MetricMap = Record<string, number | null>;
type Benefit = { label: string; text: string };

const brandAssets = {
  padaxor: "/manus-storage/padaxor-wordmark-nobg_ffc66c25.png",
  padcon: "/manus-storage/padcon-platform-line_56cf7b2a.png",
  symbolGlass: "/manus-storage/03-loginho-vidro-sistema_4d43adef.png",
};

type Substance = {
  letter: string;
  name: string;
  color: string;
  category: string;
  categoryType: string;
  subcategory: string;
  procedure: string;
  starRating: number;
  protocolDose: string;
  defaultDose: string;
  via: string;
  sessionsTotal: number;
  sessionsCompleted: number;
  interval: string;
  startDate: string;
  frequency: string;
  concentration: string;
  ampouleVolume: string;
  duration: string;
  timeToEffect: string;
  posology: string;
  composition: string[];
  description: string;
  mainFunction: string;
  perceivedEffects: string;
  impacts: MetricMap;
  meters: MetricMap;
  benefits: Benefit[];
  contraindications: string;
  scientificEvidence: string;
};

const dimensions = [
  { key: "longevity", label: "Longevidade" },
  { key: "cardiovascular", label: "Cardiovascular" },
  { key: "muscular", label: "Muscular" },
  { key: "metabolism", label: "Metabolismo" },
  { key: "neurological", label: "Neurológico" },
  { key: "bones", label: "Ossos & articulações" },
];

const meterDimensions = [
  { key: "weightLoss", label: "Emagrecimento" },
  { key: "hypertrophy", label: "Hipertrofia" },
  { key: "muscleRecovery", label: "Recuperação muscular" },
  { key: "neurocognition", label: "Neurocognição" },
];

const substances: Substance[] = [
  {
    letter: "A", name: "Coenzima Q10", color: "#3D7A7A", category: "Ortomolecular", categoryType: "Simples", subcategory: "Energia celular", procedure: "Intramuscular (IM)", starRating: 5,
    protocolDose: "100 mg / 2 ml", defaultDose: "100 mg / 2 ml", via: "Intramuscular", sessionsTotal: 6, sessionsCompleted: 1, interval: "14 dias", startDate: "12 ago 2026", frequency: "Quinzenal", concentration: "100 mg", ampouleVolume: "2 ml", duration: "15 min", timeToEffect: "2 a 4 semanas", posology: "Conforme cronograma clínico individual.",
    composition: ["Coenzima Q10 · 100 mg"],
    description: "Substância cadastrada como suporte à geração de energia nas mitocôndrias e à proteção contra a oxidação.",
    mainFunction: "Apoio à energia celular, à disposição e ao suporte cardiovascular dentro do seu plano.",
    perceivedEffects: "Mais energia e resistência; melhor recuperação e percepção de suporte cardiovascular.",
    impacts: { longevity: 5, cardiovascular: 5, muscular: 4, metabolism: 4, neurological: 3, bones: null },
    meters: { weightLoss: null, hypertrophy: null, muscleRecovery: 3, neurocognition: 3 },
    benefits: [
      { label: "Longevidade", text: "Combustível mitocondrial central na vitalidade celular ao longo da vida." },
      { label: "Qualidade de vida", text: "Mais energia e suporte cardiovascular no dia a dia." },
      { label: "Energia", text: "Apoia a geração de energia pelas células." },
      { label: "Clareza", text: "Pode compor o cuidado voltado à disposição e foco funcional." },
    ],
    contraindications: "Revisar com a equipe qualquer condição clínica, medicamento em uso ou reação anterior antes da aplicação.",
    scientificEvidence: "Base científica e pertinência clínica são avaliadas pelo profissional responsável para este protocolo.",
  },
  {
    letter: "B", name: "NADH Pellet", color: "#7450A5", category: "Ortomolecular", categoryType: "Implante", subcategory: "Energia e foco", procedure: "Implante", starRating: 3,
    protocolDose: "200 mg · 2 a 4 pellets", defaultDose: "200 mg", via: "Implante", sessionsTotal: 1, sessionsCompleted: 0, interval: "Conforme avaliação", startDate: "A definir", frequency: "Aplicação única", concentration: "200 mg", ampouleVolume: "—", duration: "60 min", timeToEffect: "Conforme acompanhamento", posology: "Aplicação e acompanhamento definidos pela equipe responsável.",
    composition: ["NADH · 200 mg", "Pellets conforme indicação"],
    description: "Forma ativa da vitamina B3 cadastrada para compor estratégias de energia e foco mental.",
    mainFunction: "Apoiar energia e clareza mental dentro da sequência de cuidado indicada para você.",
    perceivedEffects: "Foco mental e disposição conforme resposta individual e acompanhamento clínico.",
    impacts: { longevity: 4, cardiovascular: 2, muscular: 2, metabolism: 5, neurological: 5, bones: null },
    meters: { weightLoss: null, hypertrophy: null, muscleRecovery: null, neurocognition: 4 },
    benefits: [
      { label: "Energia", text: "Componente cadastrado para apoiar rotas relacionadas à energia celular." },
      { label: "Clareza mental", text: "Pode integrar objetivos de foco e desempenho neurocognitivo." },
      { label: "Performance", text: "Inserido no protocolo de acordo com a avaliação individual." },
    ],
    contraindications: "A indicação e o momento de aplicação dependem de avaliação clínica individual e de seus antecedentes.",
    scientificEvidence: "A equipe contextualiza a evidência disponível e a adequação ao seu caso durante a consulta.",
  },
  {
    letter: "C", name: "Blend Mitocondrial", color: "#A46F2D", category: "Ortomolecular", categoryType: "Blend", subcategory: "Recuperação e metabolismo", procedure: "Endovenoso (IV)", starRating: 4,
    protocolDose: "Conforme prescrição", defaultDose: "Conforme composição", via: "Endovenoso", sessionsTotal: 4, sessionsCompleted: 2, interval: "7 dias", startDate: "12 ago 2026", frequency: "Semanal", concentration: "Conforme ativos", ampouleVolume: "Conforme diluição", duration: "30 min", timeToEffect: "2 a 4 semanas", posology: "A dose segue a composição, a prescrição e o acompanhamento do profissional responsável.",
    composition: ["Complexo B", "L-carnitina", "Magnésio", "Taurina"],
    description: "Blend cadastrado com ativos voltados ao suporte à produção de energia das células, ao metabolismo e à recuperação.",
    mainFunction: "Apoiar o eixo metabólico, muscular e neurocognitivo previsto no seu protocolo.",
    perceivedEffects: "Possível percepção de suporte à rotina, à recuperação e à disposição; a resposta é individual.",
    impacts: { longevity: 3, cardiovascular: 3, muscular: 5, metabolism: 4, neurological: 4, bones: 2 },
    meters: { weightLoss: null, hypertrophy: 2, muscleRecovery: 4, neurocognition: 3 },
    benefits: [
      { label: "Recuperação", text: "Apoio cadastrado ao eixo muscular e à rotina de recuperação." },
      { label: "Metabolismo", text: "Composição orientada ao suporte metabólico previsto na estratégia." },
      { label: "Energia", text: "Ativos selecionados para participar de rotas de energia celular." },
      { label: "Performance", text: "Integra o planejamento construído pela equipe, sem promessa de desempenho individual." },
    ],
    contraindications: "Comunique sintomas, alergias, condições preexistentes e produtos em uso antes de cada sessão.",
    scientificEvidence: "A composição e sua utilização são revisadas pela equipe de acordo com a indicação clínica individual.",
  },
];

function scrollToSection(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function ClinicIssuer({ compact = false }: { compact?: boolean }) {
  return <div className={`clinic-issuer ${compact ? "clinic-issuer-compact" : ""}`} aria-label="Identidade reservada à clínica emissora">
    <span className="clinic-logo-slot" aria-hidden="true">CL</span>
    <span className="clinic-issuer-copy"><b>CLÍNICA EMISSORA</b><small>logotipo, nome e unidade de atendimento</small></span>
  </div>;
}

function InternalPadaxorMark({ inverse = false }: { inverse?: boolean }) {
  return <div className={`internal-padaxor-mark ${inverse ? "is-inverse" : ""}`} aria-label="PADAXOR Clinical Intelligent System">
    <img src={brandAssets.padaxor} alt="PADAXOR" />
    <span>Clinical Intelligent System</span>
  </div>;
}

function PlatformFooter({ page, inverse = false }: { page: string; inverse?: boolean }) {
  return <footer className={`paper-footer platform-footer ${inverse ? "is-inverse" : ""}`}>
    <span className="issuer-line">DOCUMENTO CLÍNICO INDIVIDUAL · EMITIDO PELA CLÍNICA RESPONSÁVEL</span>
    <span className="platform-credit"><span>tecnologia</span><img src={brandAssets.padcon} alt="PADCON" /></span>
    <span>{page}</span>
  </footer>;
}

function RadarChart({ values, definitions, title }: { values: MetricMap; definitions: { key: string; label: string }[]; title: string }) {
  const available = definitions.filter((definition) => values[definition.key] !== null && values[definition.key] !== undefined);
  const count = Math.max(available.length, 3);
  const point = (index: number, radius: number) => {
    const angle = (Math.PI * 2 * index) / count - Math.PI / 2;
    return `${50 + Math.cos(angle) * radius},${50 + Math.sin(angle) * radius}`;
  };
  const polygon = (radius: number) => Array.from({ length: count }, (_, index) => point(index, radius)).join(" ");
  const valuePolygon = available.map((definition, index) => point(index, 12 + ((values[definition.key] ?? 0) / 5) * 27)).join(" ");

  if (available.length < 3) return <div className="radar-empty"><span>MAPA 0–5</span><b>Dados insuficientes para radar</b></div>;

  return <figure className="radar-figure" aria-label={title}>
    <figcaption>{title}<small>escala cadastrada 0–5</small></figcaption>
    <svg viewBox="0 0 100 100" role="img" aria-label={title}>
      {[12, 22, 32, 42].map((radius) => <polygon className="radar-grid" points={polygon(radius)} key={radius} />)}
      {available.map((definition, index) => <line className="radar-spoke" x1="50" y1="50" x2={point(index, 42).split(",")[0]} y2={point(index, 42).split(",")[1]} key={definition.key} />)}
      <polygon className="radar-area" points={valuePolygon} />
      {available.map((definition, index) => { const coords = point(index, 12 + ((values[definition.key] ?? 0) / 5) * 27).split(","); return <circle className="radar-dot" cx={coords[0]} cy={coords[1]} r="1.6" key={definition.key} />; })}
    </svg>
    <div className="radar-key">{available.map((definition) => <span key={definition.key}><b>{values[definition.key]}</b>{definition.label}</span>)}</div>
  </figure>;
}

function MicroVerticalBars({ values, title }: { values: MetricMap; title: string }) {
  const available = dimensions.filter((dimension) => values[dimension.key] !== null && values[dimension.key] !== undefined && (values[dimension.key] ?? 0) > 0);
  return <figure className="micro-bars" aria-label={title}>
    <figcaption><span>{title}</span><small>Y · grau 0–5</small></figcaption>
    <div className="micro-bars-grid">
      {[5, 4, 3, 2, 1].map((value) => <i className="micro-grid-line" style={{ bottom: `${value * 20}%` }} key={value} />)}
      {available.map((dimension) => <div className="micro-bar-column" key={dimension.key}>
        <b className="micro-bar" style={{ height: `${(values[dimension.key] ?? 0) * 20}%` }}><em>{values[dimension.key]}</em></b><span>{dimension.label}</span>
      </div>)}
    </div>
    <div className="x-axis-note">X · sistemas corporais cadastrados</div>
  </figure>;
}

function Meters({ values }: { values: MetricMap }) {
  const available = meterDimensions.filter((dimension) => values[dimension.key] !== null && values[dimension.key] !== undefined && (values[dimension.key] ?? 0) > 0);
  return <aside className="meter-panel" aria-label="Medidores de resultado cadastrados">
    <header><span>MEDIDORES DE RESULTADO</span><small>escala 0–5</small></header>
    {available.length ? <div className="meter-panel-list">{available.map((dimension) => <div className="meter-item" key={dimension.key}>
      <b>{dimension.label}</b><i aria-hidden="true">{Array.from({ length: 5 }, (_, index) => <em className={index < (values[dimension.key] ?? 0) ? "is-filled" : ""} key={index} />)}</i><small>{values[dimension.key]}/5</small>
    </div>)}</div> : <p className="meter-empty">Nenhum medidor adicional foi cadastrado para esta substância.</p>}
    <p className="meter-reading">Indicadores de cadastro para organizar a conversa clínica; não são promessa de resultado individual.</p>
  </aside>;
}

function Chart({ active }: { active: string | "todos" }) {
  const visible = active === "todos" ? substances : substances.filter((substance) => substance.letter === active);
  return <div className="chart-frame" aria-label="Matriz de ênfases do protocolo">
    <div className="y-axis-title">ÊNFASE CADASTRADA</div><div className="chart-y-labels" aria-hidden="true"><span>5</span><span>4</span><span>3</span><span>2</span><span>1</span><span>0</span></div>
    <div className="chart-grid">{[5, 4, 3, 2, 1, 0].map((tick) => <div className="grid-line" key={tick} />)}
      {dimensions.map((dimension) => <div className="dimension-column" key={dimension.key}><div className="bar-cluster">{visible.map((substance) => {
        const value = substance.impacts[dimension.key]; return value === null ? <span className={`data-empty pattern-${substance.letter.toLowerCase()}`} key={substance.letter}>—</span> : <span className={`vertical-bar pattern-${substance.letter.toLowerCase()}`} key={substance.letter} style={{ height: `${value * 20}%` }} aria-label={`${substance.name}, ${dimension.label}, ${value} de 5`} />;
      })}</div><span className="dimension-name">{dimension.label.split(" ").map((word) => <span key={word}>{word}</span>)}</span></div>)}
    </div><div className="x-axis-title">ÁREAS CADASTRADAS NO CATÁLOGO CLÍNICO</div>
  </div>;
}

function CoverPage({ totalSessions, completedSessions, dossierPages }: { totalSessions: number; completedSessions: number; dossierPages: number }) {
  return <section className="paper-sheet cover-sheet" id="carta">
    <div className="cover-grain" aria-hidden="true" />
    <header className="cover-head"><ClinicIssuer /><span className="cover-document-number">CARTA DE TRATAMENTO · 01</span></header>
    <div className="cover-hero">
      <div className="cover-symbol-frame" aria-hidden="true"><img src={brandAssets.symbolGlass} alt="" /></div>
      <p className="cover-kicker">SISTEMA CLÍNICO INTELIGENTE</p>
      <h1>PADAXOR</h1>
      <p className="cover-system">Clinical Intelligent System</p>
      <div className="cover-rule" />
      <h2>Carta do seu<br /><em>protocolo de cuidado.</em></h2>
      <p className="cover-intro">Um dossiê de orientação clínica individual que torna a prescrição, as substâncias e o acompanhamento legíveis em uma única varredura.</p>
    </div>
    <div className="cover-info-grid">
      <div><span>PACIENTE</span><b>Nome do paciente</b></div><div><span>PROTOCOLO</span><b>Plano clínico individual</b></div><div><span>RESPONSÁVEL</span><b>Profissional responsável · CRM</b></div>
    </div>
    <div className="cover-status-grid">
      <div className="cover-seal-box"><span>SESSÕES REGISTRADAS</span><div className="cover-progress-seal" aria-label={`${completedSessions} de ${totalSessions} sessões registradas`}><svg viewBox="0 0 120 120" aria-hidden="true"><circle className="cover-seal-track" cx="60" cy="60" r="45" /><circle className="cover-seal-progress" cx="60" cy="60" r="45" strokeDasharray="283" strokeDashoffset={283 * (1 - completedSessions / totalSessions)} /></svg><div><b>{String(completedSessions).padStart(2, "0")}</b><i>de {String(totalSessions).padStart(2, "0")}</i></div></div></div>
      <div><span>DOSSIÊS DE SUBSTÂNCIAS</span><b>{String(dossierPages).padStart(2, "0")}</b></div>
      <p>Leia o mapa geral, localize sua substância e leve perguntas à equipe. O documento apoia a consulta e não substitui a avaliação clínica.</p>
    </div>
    <PlatformFooter page="01" inverse />
  </section>;
}

function SubstanceDossier({ substance, number, page }: { substance: Substance; number: number; page: string }) {
  return <section className="paper-sheet dossier-sheet" id={number === 1 ? "componentes" : undefined} aria-labelledby={`substance-${substance.letter}`}>
    <header className="document-head dossier-document-head"><div><p className="eyebrow">FICHA DE SUBSTÂNCIA · {String(number).padStart(2, "0")}</p><h2 id={`substance-${substance.letter}`}>{substance.name}</h2><span className="substance-meta">{substance.categoryType} · {substance.subcategory} · {substance.procedure}</span></div><InternalPadaxorMark /></header>
    <dl className="administration-grid"><div><dt>DOSE PRESCRITA</dt><dd>{substance.protocolDose}</dd></div><div><dt>VIA</dt><dd>{substance.via}</dd></div><div><dt>SESSÕES</dt><dd>{substance.sessionsCompleted}/{substance.sessionsTotal}</dd></div><div><dt>INTERVALO</dt><dd>{substance.interval}</dd></div><div><dt>DURAÇÃO</dt><dd>{substance.duration}</dd></div><div><dt>TEMPO ATÉ EFEITO</dt><dd>{substance.timeToEffect}</dd></div></dl>
    <div className="substance-overview-grid">
      <div className="clinical-copy"><div><span>O QUE É</span><p>{substance.description}</p></div><div><span>FUNÇÃO NO SEU PLANO</span><p>{substance.mainFunction}</p></div><div><span>O QUE PODE SER PERCEBIDO</span><p>{substance.perceivedEffects}</p></div></div>
      <div className="radar-column"><RadarChart values={substance.impacts} definitions={dimensions} title="Mapa de sistemas" /><div className="evidence-rating"><span>ESCALA CLÍNICA</span><b><strong>{substance.starRating}</strong><i>/5</i></b><small>registro disponível no catálogo clínico</small></div></div>
    </div>
    <div className="visual-scan-grid"><MicroVerticalBars values={substance.impacts} title="Mapa de sistemas" /><Meters values={substance.meters} /></div>
    <div className="dossier-bottom-grid">
      <section className="composition-block"><span>COMPOSIÇÃO & POSOLOGIA</span><p>{substance.composition.join(" · ")}</p><dl><div><dt>CONCENTRAÇÃO</dt><dd>{substance.concentration}</dd></div><div><dt>VOLUME</dt><dd>{substance.ampouleVolume}</dd></div><div><dt>RITMO</dt><dd>{substance.frequency}</dd></div><div><dt>DOSE BASE</dt><dd>{substance.defaultDose}</dd></div></dl><em>{substance.posology}</em></section>
      <section className="benefit-block"><span>BENEFÍCIOS CADASTRADOS</span><div>{substance.benefits.map((benefit) => <p key={benefit.label}><b>{benefit.label}</b>{benefit.text}</p>)}</div></section>
      <section className="safety-block"><span>SEGURANÇA</span><p>{substance.contraindications}</p></section>
      <section className="science-block"><span>CIÊNCIA & INDICAÇÃO</span><p>{substance.scientificEvidence}</p><small>O uso é individualizado pela equipe responsável, conforme avaliação clínica.</small></section>
    </div>
    <PlatformFooter page={page} />
  </section>;
}

export default function Home() {
  const [active, setActive] = useState<string | "todos">("todos");
  const focusSummary = useMemo(() => dimensions.map((dimension) => ({ label: dimension.label, total: substances.reduce((sum, substance) => sum + (substance.impacts[dimension.key] ?? 0), 0) })).sort((a, b) => b.total - a.total).slice(0, 3), []);
  const totalSessions = useMemo(() => substances.reduce((sum, substance) => sum + substance.sessionsTotal, 0), []);
  const completedSessions = useMemo(() => substances.reduce((sum, substance) => sum + substance.sessionsCompleted, 0), []);

  return <main className="classic-protocol-shell">
    <nav className="screen-nav" aria-label="Navegação do documento"><InternalPadaxorMark /><div className="nav-links"><button onClick={() => scrollToSection("carta")}>Capa</button><button onClick={() => scrollToSection("mapa")}>Mapa</button><button onClick={() => scrollToSection("componentes")}>Dossiês</button><button onClick={() => scrollToSection("roteiro")}>Roteiro</button></div><button className="print-button" onClick={() => window.print()}>Versão para impressão · A4</button></nav>
    <CoverPage totalSessions={totalSessions} completedSessions={completedSessions} dossierPages={substances.length} />
    <section className="paper-sheet map-sheet" id="mapa"><header className="document-head"><div><p className="eyebrow">CARTA DO PROTOCOLO · 02</p><h2>Mapa de <em>ênfases</em></h2></div><InternalPadaxorMark /></header><div className="map-intro-grid"><div className="map-intro"><h3>Como ler este mapa</h3><p>As barras verticais organizam, por substância, as áreas clínicas registradas para o seu plano. A leitura apoia a conversa com a equipe; não mede seu estado de saúde nem prevê resultados individuais.</p></div><div className="legend-card"><span>LEITURA DAS SUBSTÂNCIAS</span>{substances.map((substance) => <button key={substance.letter} onClick={() => setActive(active === substance.letter ? "todos" : substance.letter)} className={`legend-item ${active === substance.letter ? "is-active" : ""}`}><i className={`legend-mark pattern-${substance.letter.toLowerCase()}`} /><b>{substance.letter}</b>{substance.name}</button>)}</div></div><Chart active={active} /><div className="focus-strip"><div className="focus-heading"><span>SÍNTESE DA MATRIZ</span><p>Três áreas com maior soma de registros</p></div>{focusSummary.map((item, index) => <div className="focus-item" key={item.label}><b>0{index + 1}</b><span>{item.label}</span><small>{item.total} pontos registrados</small></div>)}</div><aside className="interpretation-note"><b>Nota de transparência.</b> A ausência de barra significa que a área não foi informada no cadastro daquela substância; não significa ausência de benefício, necessidade ou condição clínica.</aside><PlatformFooter page="02" /></section>
    {substances.map((substance, index) => <SubstanceDossier substance={substance} number={index + 1} page={String(index + 3).padStart(2, "0")} key={substance.letter} />)}
    <section className="paper-sheet route-sheet" id="roteiro"><header className="document-head"><div><p className="eyebrow">CARTA DO PROTOCOLO · ROTEIRO FINAL</p><h2>Roteiro de <em>sessões</em></h2></div><InternalPadaxorMark /></header><div className="route-layout"><div className="schedule-table"><div className="schedule-row schedule-header"><span>SESSÃO</span><span>DATA</span><span>A · Q10</span><span>B · NADH</span><span>C · BLEND</span><span>STATUS</span></div>{[["01", "12 AGO 2026", "CONCLUÍDA", "—", "CONCLUÍDA", "Registrada"], ["02", "19 AGO 2026", "—", "—", "PROGRAMADA", "Próxima"], ["03", "26 AGO 2026", "PROGRAMADA", "AVALIAÇÃO", "PROGRAMADA", "Prevista"], ["04", "02 SET 2026", "—", "—", "PROGRAMADA", "Prevista"]].map((row) => <div className="schedule-row" key={row[0]}>{row.map((cell, index) => <span key={`${cell}-${index}`}>{cell}</span>)}</div>)}</div><aside className="route-aside"><span>PRÓXIMO MARCO</span><h3>Revisão da equipe</h3><p>O cronograma é consultado como grade: data, substância e situação permanecem na mesma linha de leitura.</p><div className="question-block"><b>Leve estas perguntas</b><ul><li>Qual é o objetivo principal que entendi?</li><li>O que observarei até a próxima sessão?</li><li>Que dúvida ainda quero esclarecer?</li></ul></div></aside></div><PlatformFooter page={String(substances.length + 3).padStart(2, "0")} /></section>
  </main>;
}
