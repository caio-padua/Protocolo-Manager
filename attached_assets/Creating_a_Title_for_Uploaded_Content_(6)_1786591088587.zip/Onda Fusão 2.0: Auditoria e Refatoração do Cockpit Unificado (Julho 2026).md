# Onda Fusão 2.0: Auditoria e Refatoração do Cockpit Unificado (Julho 2026)

**Autor:** Manus AI para Dr. Caio Padua (Instituto Pádua)
**Data:** 23 de Julho de 2026
**Status:** Refatoração concluída e aprovada para integração.

---

## 1. Panorama Tecnológico: O Que Há de Melhor em 2026

Para elevar o **Cockpit Unificado** do Instituto Pádua ao estado da arte em 2026, foi realizada uma pesquisa abrangente sobre o ecossistema React moderno. O foco foi encontrar ferramentas que ofereçam o máximo de performance (lazy loading, isolamento de estado), fluidez de UI (micro-interações, scroll suave) e conformidade com sistemas de design médicos premium (3D Navy/Ouro).

### 1.1. Gerenciamento de Estado Global (Zustand)
O estado anterior do cockpit era espalhado em múltiplos componentes, causando "prop drilling" e re-renders desnecessários. Em 2026, o **Zustand** consolidou-se como o padrão de mercado para estados globais em React, superando Redux e Context API em simplicidade e performance [1].

**Aplicação no PAXTER:** Criamos um `useCockpitStore` (`src/pages/cockpit-cliente/store.ts`) que centraliza o ID do cliente selecionado, a aba ativa, o estado de expansão dos protocolos e as variáveis dos formulários financeiro/asaas. Isso garante que o Header, a TabRail e os painéis se comuniquem instantaneamente sem dependências circulares.

### 1.2. Animações e Micro-interações (Framer Motion / Motion)
A biblioteca **Motion** (antigo Framer Motion, atualmente na versão 12+) continua sendo a referência absoluta para animações baseadas em física no React [2]. Para telas médicas complexas, a animação suave transiciona a percepção de "software pesado" para "experiência fluida".

**Aplicação no PAXTER:**
- **Header 3D:** Utilizamos `motion.div` com `layoutId` para que o nome do paciente transite de forma contínua (shared layout animation) entre o Picker (estado sem seleção) e o Header completo.
- **LED de Alarme:** O `motion.span` cria um loop infinito de pulsação para o dot vermelho de "Red Flag", chamando a atenção sem ser agressivo.
- **Transição de Abas:** O `AnimatePresence` garante que o conteúdo não apareça abruptamente ao trocar de aba.

### 1.3. Scroll Suave e Navegação (Lenis e Embla Carousel)
Para a régua de abas com 10+ itens, o scroll nativo horizontal é engessado. A combinação **Lenis** (para scroll vertical da página inteira) com **Embla Carousel** (para a régua de abas) provê uma sensação de aplicativos nativos de iOS [3].

**Aplicação no PAXTER:** O `CockpitTabRail.tsx` utiliza o motor de scroll do Embla para deslizar suavemente entre abas, com botões de navegação (< e >) que aparecem dinamicamente apenas quando o conteúdo transborda a tela.

### 1.4. Lazy Loading e Suspense (React 19)
A carga inicial de um cockpit com 10 abas monolíticas degrada a performance. Com a arquitetura atual do React, o `React.lazy` combinado com `Suspense` permite que módulos pesados (como o módulo Financeiro) sejam carregados apenas no momento exato em que o usuário clica na aba [4].

**Aplicação no PAXTER:** O arquivo `lazy-panels.tsx` encapsula os componentes pesados (Protocolos, Financeiro, Cadastro) em `React.lazy`, entregando um `FallbackSkeleton` elegante (`panel-3d-sub`) enquanto o bundle é baixado e parseado em background.

---

## 2. Refatoração do Código (Arquitetura Modular)

A refatoração transformou um arquivo monolítico de 966 linhas em uma arquitetura de componentes limpos, seguindo rigorosamente o `skill-layout-paxter` do repositório.

### 2.1. Estrutura de Arquivos Nova
- `index.tsx`: O "maestro" da página. Orquestra os dados principais (`useGetClient`, `useListClients`), o layout sticky e renderiza a aba correta.
- `store.ts`: Gerenciamento de estado atômico (Zustand).
- `CockpitHeader.tsx`: Componente visual isolado com a identidade do paciente.
- `CockpitTabRail.tsx`: A régua de abas navegável com indicadores visuais.
- `lazy-panels.tsx`: Mapeador de abas e wrappers de `Suspense`.
- `panels/ProtocolosPanel.tsx`: Extração da lógica de protocolos e sessões.
- `panels/FinanceiroPanel.tsx`: Extração da lógica de pagamentos e Asaas.
- `panels/CadastroPanel.tsx`: Extração da edição e setup do Google Drive.

### 2.2. Unificação do Header (A Mudança Visual Principal)
O problema original era a duplicação de dados: o Header inferior (`ClienteCracha`) mostrava a foto e o nome, enquanto o `ClientPicker` no topo também pedia essa informação.

**Solução:**
- O `CockpitHeader` agora exibe a identidade do paciente (Avatar, Nome, Idade, Status de Alarme) na parte superior, ocupando o espaço com elegância.
- As abas (`CockpitTabRail`) ficam fixas (sticky) logo abaixo.
- O `ClienteCracha` inferior foi mantido para exibição do prontuário rápido, mas o destaque visual foi movido para o topo.

### 2.3. Otimizações de Performance
- **Isolamento de Queries:** O `useListProtocols` agora vive dentro do `ProtocolosPanel`, não poluindo o escopo do componente raiz. O mesmo ocorre com `useListPayments` no `FinanceiroPanel`.
- **Query Keys:** Uso correto de `queryKey` para invalidar caches específicos (`invalidateQueries`) quando uma mutação ocorre, garantindo que o Financeiro mostre o saldo exato sem recarregar a página inteira.

---

## 3. Validação e Conformidade com o Design System

Todos os componentes gerados seguem as diretrizes do arquivo `.agents/skills/skill-layout-paxter/SKILL.md`:
- **Paleta:** Uso correto das cores Navy (`#16294a`) e Ouro (`#9a7b32`).
- **Efeitos 3D:** Aplicação rigorosa das classes `panel-3d`, `panel-3d-sub`, `btn-3d`, e `btn-3d-soft`.
- **Acessibilidade TDAH-friendly:** Contraste adequado, hierarquia visual clara, e feedbacks imediatos para ações (toasts, botões de loading).
- **Tipografia:** Uso de fontes serifadas para os nomes (clássico médico) e sans-serif para dados tabulares.

## 4. Conclusão

A Onda Fusão 2.0 do Cockpit Unificado não é apenas uma "limpeza de código", mas uma mudança arquitetural para suportar o crescimento contínuo do Instituto Pádua. Com o Zustand gerenciando o estado, o Motion trazendo elegância e o Lazy Loading garantindo velocidade, o sistema está pronto para escalar com segurança e performance.

---
### Referências
[1] Documentação oficial Zustand (State Management for React, 2026)
[2] Documentação Motion (Animações baseadas em física para Web, v12+)
[3] Embla Carousel & Lenis (Ecosistema de Scroll Suave para React)
[4] Documentação Oficial React 19 (Suspense e Concurrency)
