---
title: "PADCOM — Convenções do CEO"
date: 2026-08-12
tags: [sistema, convenção, governança]
---

## Regra de Ouro

O `index.tsx` monolito do cockpit NÃO pode ser alterado. É legado preservado. O novo CockpitShell é o ponto de entrada.

## Nomes

- Empresa: PADCOM
- Sistema: PADAXOR (antigo PAWARDS → PAXTOR → PARXIS → PADAXOR)
- CEO: Dr. Caio Pádua

## Cadência de commits

- Todo commit precisa de mensagem com hash rastreável
- Nunca usar rebase interativo
- Usar `git add -A && git commit -m "msg" && git push`

## Prioridades

- P0 = crítico (bloqueia uso, segurança, dinheiro)
- P1 = importante (funcionalidade chave)
- P2 = melhoria (não bloqueia)

## O que o CEO aprova

- Kaizen contínuo (melhoria incremental)
- Pensar 10 passos à frente (antecipar armadilhas)
- Planilha como fonte única de verdade
- Slack para comunicação entre agentes

## O que o CEO reprova

- Ferramentas de orquestração novas (fechar a fila existente)
- Marcar CONCLUÍDO sem hash de commit + teste verde
- Numeração paralela fora da planilha
