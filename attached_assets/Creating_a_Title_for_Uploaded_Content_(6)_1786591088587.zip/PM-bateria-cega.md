---
title: "Bateria 23/23 verde com defeito crítico vivo"
date: 2026-08-12
classe: [teste-cego, cobertura-insuficiente]
---

## Sintoma

Bateria #81-A passou em 23/23 casos. Dr. Manus reportou "aprovado". Dr. Code respondeu: "a bateria não cobre o cenário OVERDUE + CHARGEBACK no mesmo pedido."

## Causa raiz

A bateria testava idempotência (mesmo evento duas vezes) mas não testava dois eventos legítimos distintos no mesmo pedido. O defeito não era na dedup — era no guard que cortava antes da dedup.

## Como foi detectado

Dr. Code leu o código e percebeu que o guard `jaTemEventoParaSreq()` não recebia desfecho. Perguntou ao Dr. Manus: "mesmo sreq com OVERDUE + CHARGEBACK, o segundo registra?" → Não. → Defeito encontrado.

## Regra nova

Todo item P0/P1 precisa de bateria que cubra: (1) cenário normal, (2) cenário de abuso, (3) cenário de dois eventos legítimos distintos no mesmo recurso. A bateria deve ser desenhada ANTES do código, não depois.

## Onde vai aparecer de novo

Qualquer sistema com fila de eventos, reconciliação, ou múltiplos caminhos para o mesmo fato (webhook + polling, duas APIs, dois frontend).
