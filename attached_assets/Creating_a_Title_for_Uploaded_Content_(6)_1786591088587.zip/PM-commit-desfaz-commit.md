---
title: "Commit de guard backend removeu idempotência sem avisar"
date: 2026-08-12
classe: [commit-desfazendo-commit, visibilidade]
---

## Sintoma

Dr. Manus reportou que a falha crítica (webhook Asaas reenvia = 3 penalidades para 1 cobrança) ainda existia, mesmo com item marcado CONCLUÍDO na planilha.

## Causa raiz

Um commit de funcionalidade nova (guard backend) removeu código de outra funcionalidade (tabela de dedup) sem avisar ninguém, porque os dois agentes operavam o mesmo arquivo sem protocolo de coordenação.

## Como foi detectado

Dr. Manus fez `git diff` entre os commits e viu que a tabela `concierge_webhook_eventos` desapareceu. Não foi teste — foi leitura manual do diff.

## Regra nova

Antes de committar: `git diff HEAD~1 --stat` e verificar que nenhuma linha de funcionalidade alheia foi removida. Se removeu: avisar no Slack antes do push.

## Onde vai aparecer de novo

Qualquer sistema com múltiplos agentes trabalhando no mesmo arquivo. Especialmente crítico quando um agente "limpa" código legado que outro agente escreveu.
