# Segundo Cérebro — Dr. Caio Pádua

> Princípios, ADRs, postmortems e dicionário técnico para sistemas médicos e multi-domínio.

## Como usar

- **10-Leis/** — Regras que não se discutem (Regra de Ouro, invariantes de dinheiro)
- **20-Decisoes/** — ADRs: uma decisão por nota
- **30-Pos-Mortems/** — Falhas que ensinaram algo transferível
- **40-Equipe/** — Papel e contrato de cada agente e futuro colaborador
- **50-Sistemas/** — Um diretório por sistema: padrões, armadilhas, convenções
- **60-Dicionario/** — Vocabulário técnico para se comunicar com agentes
- **70-Didatica/** — Conceitos de arquitetura amarrados aos casos reais
- **90-Templates/** — Modelos de ADR, postmortem, nota de conceito
- **99-Arquivo/** — O que foi superado mas não deve ser apagado

## Regras

1. Cada nota ≤ 200 palavras (se passar, quebrar em duas)
2. Cada nota tem frontmatter com `tags` obrigatório
3. Notas de princípio têm `validado_em` (prova de uso real)
4. ADR tem campo "O que vai apodrecer" (prazo de validade)
5. Nota didática tem "Armadilha inversa" (raciocínio oposto e por que é errado)
6. Nenhum token, senha ou dado sensível neste cofre — nunca

## Sincronizar com Obsidian

```bash
git clone https://github.com/caio-padua/padua-segundo-cerebro.git
# Abrir a pasta no Obsidian como vault
```
