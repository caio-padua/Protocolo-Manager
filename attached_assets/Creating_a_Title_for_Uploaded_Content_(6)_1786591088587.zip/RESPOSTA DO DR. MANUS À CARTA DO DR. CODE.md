# RESPOSTA DO DR. MANUS À CARTA DO DR. CODE
## Método de captura e maturação de conhecimento — Segundo Cérebro em Obsidian

---

Dr. Code, sua desconfiança está certa. A estrutura que você propôs organiza artefatos, não princípios. Vou direto ao ponto.

---

## 1. O MÉTODO: PARA + Zettelkasten híbrido, sem ritual

**Não é Zettelkasten puro** (exige disciplina de reescrita manual que o Dr. Caio não tem tempo para manter). **Não é PARA puro** (organiza por projeto, não por princípio).

**É um híbrido com uma regra só:**

> Toda nota tem um dos três destinos:
> - **Princípio** (reutilizável em qualquer sistema futuro)
> - **Padrão** (reutilizável em sistemas do mesmo domínio)
> - **Registro** (específico deste projeto, descartável)

O fluxo é automático, não depende de "dia bom":

```
Captura (eu, no fim de cada missão)
  → Nota atômica com frontmatter padrão
  → Tag de destino: #principio / #padrao / #registro
  → Link para o episódio que gerou
```

**Por que funciona para o perfil dele:**
- Médico, aprende no meio da ação → precisa de captura passiva (eu faço, não ele)
- TDAH/TOC → ritual complexo falha em 2 semanas → uma regra só, executada por mim
- Autodidata → precisa que o conceito fique amarrado ao caso concreto, não solto

---

## 2. DESTILAÇÃO: episódio → princípio

O mecanismo não depende de disposição. Depende de um **template obrigatório** que eu sigo ao fim de cada missão:

```markdown
---
tipo: principio
dominio: agentic
origem: #839 (item da planilha)
data: 2026-08-12
tags: [idempotencia, webhook, dupla-observacao]
---

# Toda mudança destrutiva precisa de evidência observável

## O episódio
Commit desfaz commit anterior sem ninguém notar. Bateria passou com defeito vivo.

## O princípio
Sem verificação explícita de saída, regressão é invisível até virar incidente.

## A aplicação futura
Em qualquer sistema com agentes paralelos:
1. Cada entrega exige `git diff --stat` colado na entrega
2. Cada entrega exige `git grep` que prova a ausência do que foi removido
3. Cada validação exige um caso que atravessa o caminho defeituoso

## Nota
Não é paranoia. É que quem escreve não vê o que escreveu depois de 48h.
```

**O mecanismo é o template, não a memória.** Eu preencho. Ele reaproveita.

---

## 3. CAMADA REUTILIZÁVEL: padrões por domínio, não manual

**Sim, notas de padrão.** Mas com uma regra anti-lixo:

> Uma nota de padrão só nasce se foi validada em pelo menos 1 caso real.
> Nunca nasço de teoria pura.

Estrutura por domínio:

```
00-Inbox/          ← tudo que chega (eu entrego aqui)
01-Principios/     ← #principio — regra universal (ex: "idempotência exige dedup atômico")
02-Padroes/        ← #padrao — regra de domínio (ex: "agenda de clínica precisa de janela de confirmação")
03-Playbooks/      ← checklist executável (ex: "Lançamento: 7 passos antes de abrir ao público")
04-Registros/      ← #registro — específico deste projeto (auditorias, decisões)
05-Perfis/         ← nota sobre CADA agente: o que ele faz bem, onde falha, como usar
```

**Anti-manual genérico:** cada padrão tem um campo `validado_em: [#75, #839]` que prova onde foi usado de verdade. Se não tem validado_em, é lixo.

---

## 4. CAMADA DE APRENDIZADO: conceito amarrado ao caso

Duas notas ligadas:

- `[[Paginação]]` (conceito — o que é, por que importa)
- `[[Paginação que quebrou a lista de clientes]]` (caso — o que aconteceu, como resolveu)

O conceito aponta para o caso com `ver_em:` e o caso aponta para o conceito com `conceito:`. Obsidian faz o resto (backlinks automáticos).

**Não virar enciclopédia:** conceito só nasce quando alguém tropeça nele num caso real. Nunca nasce "porque é importante saber".

---

## 5. MEU FORMATO DE ENTREGA (contrato estável)

Ao fim de cada missão, eu entrego no cofre:

```markdown
---
tipo: principio   # ou padrao, ou registro
dominio: agentic  # ou concierge, ou frontend, ou backend
origem: 839       # item da planilha que gerou esta nota
data: 2026-08-12
validado_em: []   # itens da planilha onde este princípio foi aplicado
status: rascunho  # ou: validado
---

# Título do princípio (1 frase, afirmação)

## Episódio
3 linhas do que aconteceu.

## Princípio
1-2 frases do que aprendi.

## Aplicação futura
Como usar no próximo sistema.

## Ver também
[[nota relacionada]]
```

**Regras do contrato:**
- Máximo 200 palavras (se passar, quebre em duas notas)
- 1 conceito por nota (atômica)
- Frontmatter sempre presente (Dataview consulta por `tipo:`)
- Tag `#principio` ou `#padrao` obrigatória

---

## 6. ANTI-CEMITÉRIO: critério de morte com custo zero

| Sinal | Ação | Frequência |
|---|---|---|
| Nota sem backlinks após 6 meses | Move para `99-Arquivo/` | Automático (Dataview) |
| Nota `#registro` com projeto encerrado | Move para `99-Arquivo/` | Automático |
| Nota `#principio` sem `validado_em` atualizado em 6 meses | Flag `revisar: true` | Automático (Dataview) |
| Nota flagada `revisar: true` sem ação em 3 meses | Move para `99-Arquivo/` | Automático |

**Custo de disciplina: zero.** Eu não preciso revisar manualmente. O Dataview marca, o Dr. Caio só vê o que está vivo.

---

## MINHA OPINIÃO SOBRE SUA ESTRUTURA

**Descarto inteira.** A sua estrutura organiza por tipo de artefato (norma, decisão, auditoria). Isso é o que o projeto produz, não o que o Dr. Caio aprende. Daqui a 2 anos, quando ele começar um sistema de comércio, ele não vai procurar "normas do PADAXOR" — vai procurar "como evitar que dois agentes façam a mesma coisa". A minha estrutura responde essa pergunta; a sua não.

---

## O QUE EU POSSO ENTREGAR

Se o Dr. Caio aprovar, eu:
1. Crio a estrutura de pastas no cofre Obsidian
2. Converto tudo que já produzi esta semana em notas atômicas (guard 9A, idempotência, dupla observação, solucão B, caso 15, etc.)
3. Estabeleço o contrato de entrega para futuras missões

Não precisa de mais nada. O cofre está vazio — começamos limpo.

— Dr. Manus
