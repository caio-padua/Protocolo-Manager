# Redesign do Protocolo do Paciente — Entrega Final

**Projeto:** Protocolo Manager · Instituto Pádua  
**Objetivo:** Criar um PDF mais didático, visual e compreensível para pacientes leigos, com gráfico radar de parâmetros de saúde e explicação clara das substâncias.  
**Data:** 19–20 de julho de 2026  
**Status:** Especificação funcional + protótipo visual + recomendações de implementação

---

## 1. O que foi entregue

### 1.1 Especificação de arquitetura (`design/arquitetura_novo_pdf.md`)

Documento de 12 seções que define:

- **Princípio:** reordenar o conteúdo existente segundo as perguntas do paciente, não aumentar informação
- **Estrutura do documento:** 11 páginas de guia educativo + anexos clínico-legais
- **Gráfico radar:** nome correto, dois modos (foco do protocolo vs. evolução percebida), escala ordinal, contrato de dados tipado
- **Dimensões recomendadas:** 7 eixos (energia, sono, clareza mental, imunidade, força/mobilidade, metabolismo, qualidade de vida)
- **Ficha de substância:** 3 perguntas primeiro (por que, o que mudar, quando avisar), depois detalhes técnicos
- **Confirmação de entendimento:** técnica *teach-back* antes do TCLE
- **Integração:** preserva fluxo existente de download, Drive, e-mail e assinatura PAdES

### 1.2 Gráfico radar demonstrativo

**Arquivo:** `assets/radar_foco_protocolo.png` e `.svg`

- 7 dimensões derivadas dos maiores escores de "impacto por sistema corporal" do protocolo fornecido
- Escala ordinal: Apoio (1), Foco (2), Foco principal (3)
- Título, subtítulo, rótulos legíveis, ressalva explícita
- Cores redundantes com texto; sem dependência visual única
- Pronto para inserção em PDF ou apresentações

### 1.3 Protótipo visual em PDF

**Arquivo:** `prototype_protocolo_paciente.pdf`

Demonstração compilada em Typst que inclui:

- Capa orientada ao paciente
- Resumo em 1 minuto com 3 métricas principais
- Radar com explicação
- Mapa de contribuição das substâncias (tabela com marcadores)
- 3 fichas de substâncias (PQQ, Metilcobalamina, Vitamina D3)
- Jornada visual com 4 marcos
- Confirmação de entendimento (teach-back)
- Glossário de termos
- Nota de implementação técnica

Anonimizado e baseado exclusivamente na estrutura do protocolo atual.

### 1.4 Pesquisa de base

**Arquivo:** `notes/phase3_research.md`

Referências verificadas de:

- CDC: linguagem simples e comunicação visual em saúde
- AHRQ: gráfico radar, técnica teach-back
- Conselho Federal de Medicina: consentimento compreensível em português
- Estudos científicos sobre efetividade de intervenções visuais

### 1.5 Auditoria do código

**Arquivo:** `notes/phase2_repo_audit.md`

Mapeamento completo do fluxo atual:

- Rota: `GET /api/protocols/:id/document-pdf` em `routes/protocols.ts`
- Gerador: `generateProtocolDocumentPdf()` em `lib/pdf-signer.ts`
- Dados disponíveis: já existem substâncias, benefícios, escores, cronograma, pagamentos
- Dois pontos de entrada: rota administrativa + área do paciente (código duplicado)
- Fábrica de documentos: `specs/fabrica-padrao-documentos.md` já existe

---

## 2. Principais mudanças propostas

### 2.1 Conteúdo

| Aspecto | Antes | Depois |
|---|---|---|
| Ordem | Técnico primeiro | Paciente primeiro |
| Hierarquia | Densa, sem respiração | Títulos, blocos, espaço |
| Linguagem | Técnica, promotora | Simples, equilibrada, verificável |
| Gráfico | Círculos/estrelas sem contexto | Radar com título, escala, ressalva |
| Ficha | Impactos, benefícios, evidência | Por que? O que muda? Quando avisar? |
| Consentimento | Apenas assinatura | Explicação + confirmação + assinatura |

### 2.2 Arquitetura técnica

| Camada | Mudança |
|---|---|
| DTO | Centralizar em serviço compartilhado; adicionar fonte/escala/data aos escores |
| Banco | Tipificar radar: modo, dimensões, valores, origem, data, revisão clínica |
| Renderização | Dividir `generateProtocolDocumentPdf()` em componentes; reutilizar Fábrica |
| Assinatura | Finalizar todas as páginas antes de PAdES; repetir testes de integridade |
| Governança | Adicionar status `draft`, `clinically_reviewed`, `published` para textos educativos |

### 2.3 Segurança comunicacional

- Nenhum círculo, estrela ou percentual é apresentado como eficácia individual
- Cada substância tem motivo, expectativa, janela de reavaliação e alerta
- TCLE usa corpo mínimo 12 pt e tem espaço para dúvidas (CFM)
- Confirmação de entendimento antes da assinatura
- Ressalvas explícitas em gráficos e promessas de benefício

---

## 3. Critérios de aceite

O redesign será considerado bem-sucedido quando:

1. ✓ Paciente identifica objetivo, composição, duração, cuidados e próximo passo nas 2 primeiras páginas
2. ✓ Radar declara modo, fonte, escala, data e significado
3. ✓ Nenhum visual é apresentado como eficácia sem definição
4. ✓ Cada substância tem motivo, expectativa, janela e alerta
5. ✓ TCLE usa 12 pt e tem espaço para dúvidas
6. ✓ Todas as páginas são geradas antes da assinatura PAdES
7. ✓ Rota administrativa e área do paciente exibem o mesmo documento

---

## 4. Próximos passos recomendados

### Fase 1: Validação clínica e editorial (1–2 semanas)

- [ ] Responsável técnico revisa textos educativos e substitui termos promocionais
- [ ] Revisor clínico valida escores, fontes e recomendações
- [ ] Revisor jurídico aprova TCLE e conformidade com CFM/LGPD
- [ ] Testes de compreensão com pacientes reais (opcional, recomendado)

### Fase 2: Implementação técnica (2–3 semanas)

- [ ] Centralizar DTO em serviço compartilhado
- [ ] Adicionar campos tipados de radar ao banco (modo, dimensões, origem, data)
- [ ] Modularizar renderizador em componentes de página
- [ ] Reutilizar tokens da Fábrica (cabeçalho, rodapé, tipografia)
- [ ] Implementar status de revisão clínica para textos

### Fase 3: Testes e segurança (1–2 semanas)

- [ ] Compilar PDF com dados reais
- [ ] Verificar integridade PAdES antes e depois da assinatura
- [ ] Testar fluxo de download, Drive, e-mail
- [ ] Validar legibilidade em diferentes visualizadores
- [ ] Testes de regressão: rota administrativa + área do paciente

### Fase 4: Migração (1 semana)

- [ ] Feature flag para ativar novo renderizador
- [ ] Manter gerador antigo disponível como fallback
- [ ] Monitorar erros e feedback de pacientes
- [ ] Desativar fallback após 2–4 semanas de estabilidade

---

## 5. Arquivos entregues

```
protocolo_pdf_redesign/
├── design/
│   └── arquitetura_novo_pdf.md          # Especificação funcional completa
├── assets/
│   ├── radar_foco_protocolo.png         # Gráfico radar (raster)
│   └── radar_foco_protocolo.svg         # Gráfico radar (vetorial)
├── scripts/
│   └── gerar_radar_foco.py              # Código reprodutível do radar
├── notes/
│   ├── phase1_findings.md               # Achados dos materiais fornecidos
│   ├── phase2_repo_audit.md             # Auditoria do código do Protocolo Manager
│   ├── phase3_research.md               # Pesquisa de base (CDC, AHRQ, CFM)
│   └── phase3_issues.md                 # Problemas identificados no PDF atual
├── prototype/
│   ├── document/
│   │   ├── main.typ                     # Fonte Typst do protótipo
│   │   ├── main.pdf                     # PDF compilado
│   │   ├── report-theme.typ             # Tema adaptado ao português
│   │   ├── preflight.typ                # Teste de preflight
│   │   └── assets/
│   │       ├── radar_foco_protocolo.png
│   │       └── radar_foco_protocolo.svg
│   └── .typst-build-plan.json           # Plano de construção Typst
└── prototype_protocolo_paciente.pdf     # PDF final (cópia para entrega)
```

---

## 6. Notas importantes

### Segurança e conformidade

Este redesign foi desenvolvido com atenção a:

- **Linguagem simples:** CDC guidelines
- **Comunicação visual:** AHRQ radar chart best practices
- **Consentimento:** Recomendação CFM nº 1/2016
- **Privacidade:** LGPD (já presente no TCLE atual)
- **Segurança clínica:** Nenhuma promessa de benefício sem definição; riscos e alternativas sempre presentes

### Dados clínicos

O protótipo usa apenas dados já presentes no protocolo fornecido. Nenhuma informação nova foi inventada. A normalização dos escores para o radar (0–2 = Apoio, 3–4 = Foco, 5 = Foco principal) é apenas para demonstração visual; a versão real deve usar prioridade confirmada pelo profissional.

### Compatibilidade

O fluxo existente de download, Google Drive, e-mail e assinatura PAdES pode ser preservado. A mudança ocorre apenas no renderizador e no DTO, não no fluxo de distribuição.

---

## 7. Referências

[1] CDC — Plain Language Materials & Resources  
[2] CDC — Visual Communication Resources  
[3] AHRQ — Radar Chart  
[4] AHRQ — Use the Teach-Back Method: Tool 5  
[5] Conselho Federal de Medicina — Recomendação CFM nº 1/2016  
[6] Galmarini, Marciano, Schulz — Visual-based interventions on health literacy (2024)

---

**Fim da entrega.**

Para dúvidas técnicas, consulte `design/arquitetura_novo_pdf.md` e `notes/phase2_repo_audit.md`.  
Para validação clínica, consulte `notes/phase3_research.md`.
