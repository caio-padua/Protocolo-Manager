# Achados — prévia PDF A4 do dossiê ampliado

**Fonte:** `/home/ubuntu/webdev-static-assets/dossie-clinico-a4-previsualizacao.pdf` gerado via Chromium headless em 12/08/2026.

## Evidências objetivas

| Evidência | Observação |
|---|---|
| Total de páginas | **14 páginas A4** |
| Tamanho físico | **A4** (`594.96 x 841.92 pts`) |
| Página 1–2 | A capa foi quebrada em duas páginas; a segunda ficou com grande área em branco |
| Página 3–4 | O mapa de ênfases também foi quebrado em duas páginas; a quarta ficou quase vazia |

## Leitura diagnóstica inicial

1. A paginação física **não está aceitável** ainda para impressão final.
2. O layout em tela está correto, mas o modo de impressão está desperdiçando páginas.
3. Há indício de que a combinação de `min-height` de folha + blocos internos + rodapé + cabeçalho do navegador esteja empurrando o conteúdo para páginas extras.
4. O PDF gerado pelo Chromium adicionou cabeçalho/rodapé automáticos do navegador (data, título, URL e contador), o que também precisa ser considerado na validação.

## Consequência para a próxima iteração

- Ajustar CSS de impressão para reduzir altura efetiva e evitar quebra da capa e do mapa.
- Validar se cada `paper-sheet` cabe fisicamente em **uma página A4 real**.
- Regerar a prévia PDF após o ajuste antes de apresentar como versão pronta.
