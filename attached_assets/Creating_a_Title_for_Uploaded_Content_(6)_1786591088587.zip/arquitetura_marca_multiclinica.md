# Arquitetura de Marca — Carta de Tratamento Multiclínica

## Hierarquia institucional

| Camada | Papel no documento | Dados / ativo |
|---|---|---|
| **Clínica emissora** | Autoria clínica e relação direta com paciente/médico | `clinicName`, `clinicLogoUrl`, `clinicUnit` — configuração do tenant |
| **PADAXOR** | Sistema que organiza o protocolo e o dossiê clínico | Wordmark oficial `padaxor-wordmark-nobg.png`; subtítulo fixo **Clinical Intelligence System** |
| **PADCON** | Grupo/plataforma mantenedora, em crédito discreto | `padcon-platform-line.png` |

## Regra de composição

1. O canto superior esquerdo é sempre o **bloco variável da clínica**. Quando o tenant ainda não fornecer logo e nome, o preview apresenta uma reserva neutra, sem simular uma clínica real.
2. O canto superior direito traz a assinatura PADAXOR em menor escala: o produto explica a infraestrutura, sem disputar o papel clínico da instituição emissora.
3. O rodapé consolida a frase de procedência e a assinatura PADCON, ambos menores que a marca da clínica.
4. Na impressão monocromática, as marcas preservam proporção e contraste por contorno/texto; nenhum significado depende de cor.

> O protocolo é emitido pela clínica configurada no tenant. O PADAXOR organiza a apresentação clínica; o PADCON mantém a plataforma. As três camadas não são intercambiáveis.
