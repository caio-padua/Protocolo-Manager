# Arquitetura do Ecossistema Padcon / IHE

Esta referência detalha a anatomia dos repositórios do Dr. Caio (Clínica Pádua) para garantir que qualquer engenheiro autônomo (como Manus) consiga navegar, auditar e expandir o sistema sem quebrar o ecossistema.

## 1. Os Dois Corações do Sistema

O ecossistema opera no modelo de "Sistemas Primos Independentes".

### 1.1. Protocolo-Manager (Padcon Conect)
- **O que é:** O Motor Clínico de Alta Precisão (agora renomeado para PAXTER).
- **Ponto Forte:** Prescrição real (fórmulas ICP-Brasil, injetáveis, RAS evolutivo).
- **Estrutura Chave:** `motor_regras`, `catalogo_injetaveis`, `catalogo_formulas`.
- **Rotas:** 18 rotas altamente especializadas no ato médico.
- **Frontend:** `artifacts/padcom`

### 1.2. Integrative-Health-Engine (IHE)
- **O que é:** SaaS de Gestão e Comercial (Multi-Tenant).
- **Ponto Forte:** Governança, feature flags (módulos contratados), agentes virtuais e monitoramento remoto.
- **Estrutura Chave:** `modulos_sistema`, `contrato_clinica`, `monitoramento_sinais_vitais`, `catalogo_agentes`.
- **Rotas:** 102 rotas abrangentes.
- **Frontend:** `artifacts/clinica-motor`

## 2. A Stack Tecnológica (A mesma para ambos)
- **Gerenciador de Pacotes:** pnpm workspaces (monorepo)
- **Backend:** Express 5 + TypeScript (porta 8080)
- **Banco de Dados:** PostgreSQL + Drizzle ORM
- **Validação:** Zod v4 + drizzle-zod
- **Frontend:** React 18/19 + Vite + TailwindCSS + shadcn/ui

## 3. O Fluxo de Transplante (Integração)

Sempre que o Dr. Caio pedir uma feature, **nunca construa do zero se já existir no IHE**. O fluxo correto é:
1. Audite o IHE (`lib/db/src/schema/`).
2. Se existir, crie uma spec de "Transplante" (importação de schema e rotas para o Manager).
3. Se não existir (ex: Motor Nutricional), crie a spec de construção do zero no Manager.

## 4. A Arquitetura do Cérebro (Motor Clínico)
O Cérebro opera por **Sinapses**. A anamnese gera respostas -> O Motor calcula o Escore de Gravidade por Bloco (Soma de Pesos * Intensidade) -> A patologia dispara vias (Axônios) -> As vias geram indicações nas filas de validação (Exames, Fórmulas, Injetáveis, Implantes, Dieta, Treino). A UI do Cérebro é a **Craniotomia Viva** (modo Simular, sinapses animadas, edição in situ).

## 5. Mensageria Inteligente (A Beatriz Romanov)
Todo ato de prescrição gera gatilhos no motor de Mensageria (WhatsApp/Twilio). Lembretes de fórmulas (baseados em 9 períodos do dia), alertas de exames e check-ins de treino são agendados automaticamente via CRON.

## 6. O Cockpit da Consulta (A Filosofia de UI)

A dor principal do médico é "trocar de abas". Toda nova interface médica deve seguir o padrão do **Cockpit (GAP-04)**:
- **Coluna Esquerda:** O Passado (Histórico, Monitoramento Remoto, Alertas).
- **Coluna Central:** O Presente (Evolução Clínica do dia).
- **Coluna Direita:** O Futuro (Motor de Prescrição: Fórmulas, Exames, Injetáveis, Dieta).
- **Ação:** Um único botão "Finalizar e Emitir Tudo" que emite todas as receitas, gera orçamentos e notifica o paciente em paralelo (`Promise.all`).

## 7. A Marca PAXTER (Skeuomorfismo 3D)
Todas as novas telas devem ter design 3D (saliente/côncavo), cantos radius 6-8, cor NAVY (#16284a) + OURO.
A logo PAXTER (com brilho em alto-relevo) deve estar SEMPRE no canto superior direito do sistema.
O nome da clínica (ex: Instituto Pádua) aparece apenas no canto superior esquerdo dos PDFs gerados.
TDAH-Friendly: Campos vazios nunca somem, mostram "—". Alinhamento estrito em grade imaginária.
