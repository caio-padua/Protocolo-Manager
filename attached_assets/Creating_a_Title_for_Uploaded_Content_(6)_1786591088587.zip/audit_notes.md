# Notas de Auditoria — Cockpit Unificado

## Estrutura Atual do Cockpit

### Header Sticky (linhas 300-360)
- Fundo: gradiente navy (#1e3668 → #16294a → #0f1e3a)
- Esquerda: "Padcon Conect" (subtítulo repetido da sidebar) + "Cockpit da Consulta" (título dourado)
- Direita: 3 botões de ação (Editar, Drive, Protocolo) + ClientPicker
- Problema: quando não há cliente, os botões somem e fica só o picker solto

### Barra de Abas (linhas 362-398)
- 10 abas em flex com overflow-x-auto (scroll horizontal oculto)
- Aba ativa: fundo claro creme, borda dourada no topo, translateY(-2px)
- Abas inativas: fundo semi-transparente, texto slate-400
- Problema: transbordam em telas menores, scroll não é óbvio

### Conteúdo (linhas 403-965)
- Crachá do cliente (ClienteCracha) abaixo do header
- 10 abas com renderização condicional ({aba === "x" && <Component />})
- Cada aba renderiza componentes específicos

## Problemas Identificados

### 1. Identidade Duplicada
- Picker mostra nome do cliente no header
- Crachá mostra nome, foto e dados do cliente abaixo
- Duplicação visual e cognitiva

### 2. Header Inconsistente
- Sem cliente: picker solto sem contexto
- Com cliente: 3 botões flutuam sem contexto de identidade

### 3. Scroll Oculto nas Abas
- overflow-x-auto com scrollbarWidth: none
- Usuário não percebe que pode scrollar
- Abas "Documentos", "Anamnese", "Protocolos", "Financeiro", "Cadastro" ficam escondidas

### 4. Subtítulo Redundante
- "Padcon Conect" repete a marca da sidebar
- Ocupa espaço vertical precioso

### 5. Estado Vazio Sem Guia
- Quando cliente não selecionado, mostra panel central mas sem ligação visual ao picker

## Design System (Skill Layout Paxter)
- Navy/Ouro = chrome de marca (não mais verde-petroleo/ciano)
- Classes 3D sagradas: panel-3d, bevel-3d, concave-3d, btn-3d
- TDAH-friendly: uppercase, tracking expandido, alto contraste
- Cantos quadrados (6-8px), nunca pill/arredondado
- Cormorant Garamond para destaque/nomes/financeiro
- Inter/sans para UI funcional
