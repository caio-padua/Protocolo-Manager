# Auditoria de Fiação — Dossiê por Substância

**Data:** 12/08/2026  
**Escopo:** converter o cadastro rico de `substances` em um dossiê paciente multípágina, sem fabricar informação clínica.

## Diagnóstico honesto

O cadastro de substâncias já contém conteúdo suficiente para uma ficha extensa. O PDF atual consome uma parte clínica relevante, mas deixa fora da rota e da interface do gerador os campos de **composição, posologia, concentração, volume de ampola, medidores de resultado, categoria operacional, notas e identificação interna**. Portanto, o ganho pretendido não exige nova tabela: exige ampliar o contrato `ProtocolDocSubstance`, o mapeamento em `GET /protocols/:id/document-pdf` e o desenho do PDF.

## Campo a campo: origem e destino proposto

| Bloco do cadastro | Campos reais | PDF atual | Dossiê clássico proposto |
|---|---|---|---|
| Identificação | `name`, `color`, `category`, `categoryType`, `codigoPadcom`, `subCategoria`, `tags`, `areaSemantica`, `grau`, `viaUso` | Parcial: nome, cor, `categoryType`, via | Cabeçalho, classificação e referência clínica; `codigoPadcom` fica opcional/técnico, não é destaque ao paciente |
| Plano prescrito | `protocol_items.dose`, `totalSessions`, `completedSessions`, `intervalDays`, `startDate`, `frequency`, `unitPrice` | Parcial: dose, sessões, intervalo, início, preço | Faixa de administração + mini-roteiro de sessão; não confundir a dose do protocolo com a dose padrão do catálogo |
| Posologia e logística | `defaultDose`, `posologia`, `posologiaEstruturada`, `concentrationMg`, `volumeAmpola`, `durationMinutes`, `frequenciaBase`, `maxSessionsPerWeek`, `timeToEffect`, `procedureType` | Parcial: procedimento e tempo até efeito | Quadro "Como será administrado" com dose, via, concentração, volume, duração, intervalo e horizonte de percepção, quando preenchidos |
| Composição | `composicao` | Ausente | Lista de ativos e dosagens; parser existente separa cada componente sem inventar concentração |
| Mapa corporal | `bodySystemEffects` (0–5) | Sim, em barras horizontais | **Gráfico radar 0–5** + **barras verticais** por sistema, mantendo os valores originais e a escala explicitada |
| Medidores de resultado | `categoryMeters` (0–5) | Ausente | Segundo radar/colunas verticais: Emagrecimento, Hipertrofia, Recuperação Muscular e Neurocognição; só itens preenchidos e > 0 |
| Descrição clínica | `description`, `mainFunction`, `perceivedEffects` | Sim | Leitura em três blocos curtos: "O que é", "Função no seu plano" e "O que pode ser percebido" |
| Benefícios por área | 10 textos: longevidade, qualidade de vida, sono, energia, libido, performance, força, clareza, pele/cabelo/unhas, imunidade | Sim | Grade editorial de até 10 tópicos; somente campos preenchidos; texto integral, sem reduzir a um ponto binário |
| Segurança e ciência | `contraindications`, `scientificEvidence`, `exigeValidacaoHumana` | Parcial: contraindicações e evidência | Rodapé de segurança e base científica; validação humana, se verdadeira, deve sinalizar revisão clínica — não ser exibida como risco ao paciente |
| Operação interna | `stockQuantity`, `stockUnit`, `disponivel`, `unidadeId`, `notes`, `blocoId`, `createdAt` | Ausente | Não exibir estoque, notas internas, bloco ou IDs; são operacionais e não acrescentam entendimento ao paciente |

## Lacuna de fiação comprovada

Hoje `GET /protocols/:id/document-pdf` envia **23 atributos** por substância para `generateProtocolDocumentPdf`. O banco disponibiliza os atributos acima, mas a rota não encaminha `category`, `subCategoria`, `composicao`, `posologia`, `posologiaEstruturada`, `defaultDose`, `concentrationMg`, `volumeAmpola`, `durationMinutes`, `frequenciaBase`, `maxSessionsPerWeek`, `categoryMeters`, `tags`, `areaSemantica`, `grau` e `viaUso`.

> Consequência: o novo dossiê tem duas camadas. A camada visual pode ser validada já no mockup; a camada de produção requer que o executor amplie o payload, sem alterar banco nem criar dados novos.

## Regras clínicas e visuais

1. Cada número 0–5 vem diretamente dos JSONs `bodySystemEffects` ou `categoryMeters`; o gráfico não calcula eficácia nem faz previsão individual.
2. Um campo ausente não recebe texto automático. A célula fica fora do dossiê ou aparece como `—`, conforme a importância estrutural.
3. Cada substância recebe uma área modular mínima de meia página A4; conteúdo longo pode continuar na página seguinte com o mesmo cabeçalho.
4. A paginação é por substância e não por quantidade: seis substâncias resultam em seis módulos independentes, mais capa, mapa geral, cronograma e consentimento.
5. O modo de impressão usa preto, navy e cinza; ouro e cor da substância atuam apenas como marcadores de baixa cobertura.

## Referências internas auditadas

- `lib/db/src/schema/substances.ts` — armazenamento real.
- `artifacts/padcom/src/pages/substances/SubstanceEditForm.tsx` — semântica da tela de cadastro apresentada pelo Dr. Caio.
- `artifacts/padcom/src/pages/substances/shared.tsx` — taxonomia oficial de sistemas, composição e medidores.
- `artifacts/api-server/src/routes/protocols.ts` — payload atual do PDF.
- `artifacts/api-server/src/lib/pdf-signer.ts` — interface e desenho vigente do documento.
