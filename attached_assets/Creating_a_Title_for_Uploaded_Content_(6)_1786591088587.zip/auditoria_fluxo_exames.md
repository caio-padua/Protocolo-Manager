# Auditoria do Fluxo Upload -> Drive -> Gemini -> Cockpit

## BUGS CRITICOS IDENTIFICADOS

### 1. drive-watcher.ts — source_pdf_drive_id NUNCA é salvo
- Linhas 399-410: O doc é inserido em exam_documents SEM sourcePdfDriveId
- O campo não é preenchido em nenhum momento do fluxo drive-watcher
- Consequência: se o doc entrar por este canal, source_pdf_drive_id = NULL (mesmo bug do doc 632)

### 2. drive-watcher.ts — Signature mismatch com ensureClientFolderStructure
- Linha 447: `ensureClientFolderStructure(clientId)` — passa um NUMBER
- A assinatura real é: `ensureClientFolderStructure(clientName: string, cpf: string)`
- Consequência: o upload ao Drive do paciente SEMPRE falha neste caminho

### 3. drive-watcher.ts — Signature mismatch com uploadFileToDrive
- Linha 453-459: `uploadFileToDrive(buffer, newName, "application/pdf", targetFolder, { allowDuplicates: false })`
- A assinatura real é: `uploadFileToDrive(folderId, fileName, mimeType, fileBuffer, allowDuplicates=false)`
- Ordem dos argumentos ERRADA (buffer em vez de folderId como primeiro arg)
- Consequência: upload ao Drive SEMPRE falha neste caminho

### 4. exames-lab.ts — source_pdf_drive_id salvo DEPOIS da extração
- Linhas 135-172: O sourcePdfDriveId só é salvo DEPOIS de extractExamFromText() e persistExtractedResults()
- Se a extração falhar, markDocumentError() é chamado mas sourcePdfDriveId fica NULL
- A correção prometida na Carta 04 NÃO foi implementada no startExamIngestion
- Linhas 240-249: startExamIngestion cria o doc com status='processando' mas NÃO salva sourcePdfDriveId

### 5. exames-lab.ts — startExamIngestion não salva source_pdf_drive_id no insert
- Linhas 240-249: O INSERT em exam_documents NÃO inclui sourcePdfDriveId
- O campo só é salvo depois, dentro de processExamDocument(), linhas 167-172
- Se processExamDocument falhar ANTES de chegar lá (ex: PDF escaneado sem OCR), o campo fica NULL

### 6. client-portal.ts — Fluxo corretamente passa sourcePdfDriveId
- Linhas 179-185: O portal CORRETAMENTE passa `sourcePdfDriveId: result.fileId` ao startExamIngestion
- Mas startExamIngestion NÃO salva isso no INSERT inicial (bug #5)

### 7. Portal UI — Sem status ao vivo (Tarefa 4 da Carta 04)
- area.tsx: O portal é fire-and-forget. Upload retorna sucesso mas não mostra status de processamento
- Não há polling para /exames-lab/documentos ou endpoint de status

### 8. drive-watcher — ensureClientFolderStructure com arg errado
- Linha 447: passa `clientId` (number) quando a função espera `(clientName, cpf)` (strings)
- Isso causa falha silenciosa no upload ao Drive do paciente

## RESOLUÇÃO DO DOC 632

O doc 632 (client_id=44, status=erro, source_pdf_drive_id=NULL) precisa de:
- OPCAO A: Re-upload via portal (Dr. Caio faz upload novamente)
- OPCAO B: Importar via /importar-drive se arquivo ainda está no Drive
- OPCAO C: Nova rota POST /exames-lab/reprocessar/:docId com body { driveFileId: "..." }

## MELHORIAS NECESSÁRIAS

1. startExamIngestion deve SALVAR sourcePdfDriveId no INSERT inicial
2. drive-watcher deve corrigir signatures de ensureClientFolderStructure e uploadFileToDrive
3. Adicionar rota de reprocessamento com driveFileId explícito
4. Portal deve ter status ao vivo (polling de status do documento)
5. Adicionar notificação quando extracao concluir (já existe no processExamDocument mas precisa validação)
