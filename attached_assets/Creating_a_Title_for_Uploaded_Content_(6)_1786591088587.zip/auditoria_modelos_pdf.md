# Auditoria Visual — Modelos de Protocolo Enviados

**Fontes examinadas:** `PROTOCOLOMODELO.pdf` (13 páginas; amostra visual das páginas 1–5) e `prototype_protocolo_paciente(1).pdf` (2 páginas).  
**Data:** 12/08/2026.  
**Objetivo:** preservar a fiação e a informação útil, substituindo uma leitura linear por uma matriz de leitura rápida, sóbria e imprimível.

| Elemento | O que o material já resolve | Problema para a nova direção | Decisão para o novo modelo |
|---|---|---|---|
| Capa | Junta identificação, objetivo, profissional, sessões e valor. | Fundo verde sólido consome tinta; composição é longa e pouco escaneável. | Capa marfim, assinatura discreta, matriz de metadados em colunas e uma única linha de acento. |
| Mapa por substância | Mostra substâncias versus dimensões do cuidado. | Marcadores circulares e estrelas dependem de cor e não permitem comparar intensidade de imediato. | Matriz com **barras verticais graduadas** por célula, legenda textual e eixo explícito. |
| Radar | Comunica áreas de foco e inclui ressalva adequada. | Leitura radial é menos imediata para comparação; é a linguagem que o CEO quer substituir. | Trocar por painel cartesiano: X = áreas/objetivos, Y = nível de foco, com barras verticais. |
| Ficha da substância | Reúne via, dose, intervalo, descrição, sistemas, benefícios e contraindicações. | Exige leitura corrida e muitas linhas horizontais de texto. | Ficha em quatro quadrantes alinhados: por que / sistemas em foco / administração / pontos de atenção. |
| Protótipo breve | Usa linguagem simples, jornada e teach-back; diferencia escopo educativo. | O mapa de contribuição em caracteres não é visualmente operável; tipografia é genérica. | Manter a ordem paciente-primeiro, mas substituir o mapa por quadro tipográfico de alta densidade e impressão nítida. |

## Decisões de leitura

O modelo novo deve ter uma **grade invisível rigorosa**, composta por eixos verticais de metadados e linhas horizontais finas de separação. A leitura prioritária será por varredura: título, objetivo, áreas de foco, substâncias e próximo passo, nesta ordem. Nenhum gráfico representará resultado individual, eficácia ou gravidade. A matriz mostrará exclusivamente a **prioridade/participação no plano**, acompanhada de rótulo e escala ordinal.

## Regra de impressão

O documento deve permanecer legível em escala de cinza. Navy, ouro e verde não podem ser a única forma de codificar informação; barras, rótulos, espessura e padrões de preenchimento devem preservar o sentido sem cor. Fundos extensos, sombras e imagens decorativas serão retirados da versão de impressão.
