# Avaliação Dr. Manus — Carta Técnica Dr. Replit (Trava de Escassez Concierge)

## Data: 12/08/2026

## Verificação de commits — TODOS EXISTEM no origin/main

| Commit | Mensagem | Status |
|---|---|---|
| 9bed3c5 | Painel CEO de penalidades + listagem + reset manual | OK |
| 312f507 | Testes automatizados da trava de escassez (stateful) | OK |
| 92421b2 | Modal sem prompt(), CPF pré-preenchido | OK |
| 75a0469 | Reset atômico: SELECT FOR UPDATE + audit log | OK |
| 9305755 | Testes ciclo completo (lib + HTTP routes) | OK |
| ee99e88 | Cenário 10: CHARGEBACK_REQUESTED aciona penalidade | OK |
| b05883f | Webhook Asaas: OVERDUE e DELETED penalizam | OK |
| 41ffc36 | Cartas para Dr. Code e Dr. Manus | OK |

## Verificação de código — CONFORME

| Verificação | Resultado |
|---|---|
| `concierge-penalidade.ts` existe com lógica de 0→7→30→∞ | OK |
| Rota `GET /scheduling/concierge-offer` com penalidade aplicada | OK |
| Webhook Asaas com hooks em OVERDUE, DELETED, REFUNDED, CHARGEBACK | OK |
| Tabela `concierge_penalidades` criada lazy (CREATE TABLE IF NOT EXISTS) | OK |
| CPF < 11 dígitos ignorado | OK |
| Frontend `ConciergePenalidades.tsx` existe com painel CEO | OK |

## LACUNAS E RISCOS IDENTIFICADOS

### RISCO CRÍTICO — #158 (Idempotência do webhook Asaas)
O Dr. Replit reconhece corretamente: sem coluna `penalidade_registrada` em `scheduling_requests`, um reenvio do Asaas pode incrementar a penalidade 2-3 vezes. **Deve ser resolvido antes de qualquer webhook real em produção.**

### RISCO CRÍTICO — #159 (Guard no backend)
O `GET /scheduling/concierge-offer` retorna `blocked: true` quando bloqueado, mas o `POST /scheduling/requests` NÃO tem guard de penalidade no início. Um cliente bloqueado pode ir direto na API (bypass do frontend) e criar uma `sreq`. Hoje o bloqueio só funciona no frontend.

### OBSERVAÇÃO — Item #37 (Auditoria de rotas)
Este trabalho NÃO resolve o item #37 da planilha (auditoria de rotas sem filtro de empresa). São domínios diferentes — penalidade ≠ isolamento entre empresas.

## CONFORMIDADE COM REGRAS DO CEO

| Regra | Status |
|---|---|
| NUNCA DROP TABLE | OK — usa CREATE TABLE IF NOT EXISTS |
| Nunca apagar arquivo | OK — nada foi deletado |
| Tabela criada lazy fora do Drizzle | OK — conforme |
| Penalidade permanente (pagar não zera) | OK — não há lógica de reset automático |
| Toda coluna nova = ADD COLUMN | OK — nada foi dropado |
| BRT centralizado (brtNow) | Não verificado diretamente, mas código usa TIMESTAMPTZ |
| createClientSafe() | Não verificável nesta auditoria |

## CONCLUSÃO

O trabalho é sólido e bem testado (4 arquivos de teste). Os 8 commits estão no repo e funcionam como descrito. Porém há 2 riscos críticos em aberto (#158 e #159) que precisam ser resolvidos antes de produção real. A entrega atual é funcional no frontend mas vulnerável no backend (bypass via API direta).

**APROVO COM RESSALVAS:** O trabalho está correto para o estado atual, mas #159 (guard backend) deve ser tratado como P0 e resolvido antes de aceitar webhook Asaas real em produção.
