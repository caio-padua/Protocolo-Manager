/**
 * BATERIA #81-A v2 — Validação idempotência #75 após correções do Dr. Replit
 * Commit testado: 3bebcde (caso 7 guard runtime + caso 9 duplo-observador)
 * 10 casos determinísticos, asserções relativas
 */

// Tabela simulada (em memória)
const eventos = new Set(); // event_id → boolean
const eventosSreq = new Map(); // sreqId → Set de eventIds do webhook

// Guarda os últimos eventIds por sreq para o guard do caso 9
const eventosPorSreq = new Map(); // sreqId → Set<eventId>

const LIMITE_BLOQUEIO = 3;

function normCpf(raw) {
  if (!raw) return "";
  return String(raw).replace(/\D/g, "").padStart(11, "0").slice(-11);
}

// Simula jaTemEventoWebhookParaSreq (caso 9)
function jaTemEventoWebhookParaSreq(sreqId) {
  const s = eventosPorSreq.get(sreqId);
  if (!s) return false;
  return s.size > 0;
}

// Simula registrarFalha (com guard runtime do caso 7)
async function registrarFalha(rawCpf, eventId, sreqId = null) {
  // CASO 7: Guard runtime
  if (!eventId || eventId.trim().length === 0) {
    throw new Error("eventId obrigatório — parâmetro vazio ou ausente.");
  }

  const cpf = normCpf(rawCpf);
  if (cpf.length < 11) {
    console.log(`    [${eventId}] CPF inválido (${rawCpf}) → SEM penalidade`);
    return false;
  }

  // CTE atômico: dedup + UPSERT
  const eventoNovo = !eventos.has(eventId);
  eventos.add(eventId);

  // Registrar associação sreq → eventId (para o guard do caso 9)
  if (sreqId !== null) {
    if (!eventosPorSreq.has(sreqId)) eventosPorSreq.set(sreqId, new Set());
    eventosPorSreq.get(sreqId).add(eventId);
  }

  let penalizado = false;
  if (eventoNovo) {
    penalizado = true;
    console.log(`    [${eventId}] Penalidade registrada`);
  } else {
    console.log(`    [${eventId}] Dedup — NENHUMA nova`);
  }
  return penalizado;
}

// Simula o polling com guard do caso 9
async function pollingRegistrarFalha(cpf, sreqId, chargeId, mapped) {
  // Guard caso 9: se webhook já registrou para este sreq, pula
  if (jaTemEventoWebhookParaSreq(sreqId)) {
    console.log(`    [polling:sreq${sreqId}] IGNORADO — webhook já registrou para este sreq`);
    return false;
  }
  const pollEventId = `poll:${sreqId}:${chargeId}:${mapped}`;
  return await registrarFalha(cpf, pollEventId, sreqId);
}

// Simula webhook registrar (com sreqId para o guard caso 9)
async function webhookRegistrarFalha(cpf, sreqId, eventAsaasId) {
  return await registrarFalha(cpf, eventAsaasId, sreqId);
}

async function runBattery() {
  console.log("═══════════════════════════════════════════════════════");
  console.log("  BATERIA #81-A v2 — VALIDAÇÃO IDEMPOTÊNCIA #75");
  console.log("  Commit testado: 3bebcde");
  console.log("═══════════════════════════════════════════════════════\n");

  let passou = 0, falhou = 0;
  const total = { penalidades: 0 };

  // Caso 1: Webhook 1ª vez
  console.log("CASO 1: Webhook envia evento X (1ª vez)");
  await webhookRegistrarFalha("12345678900", 100, "evt_abc123");
  let pen1 = eventos.size; // 1 evento único
  if (pen1 === 1) { console.log("  ✅ PASSOU\n"); passou++; }
  else { console.log(`  ❌ FALHOU (${pen1} eventos)\n`); falhou++; }

  // Caso 2: Reentrega
  console.log("CASO 2: Reentrega mesmo evento");
  await webhookRegistrarFalha("12345678900", 100, "evt_abc123");
  let pen2 = eventos.size;
  if (pen2 === 1) { console.log("  ✅ PASSOU — reentrega não altera\n"); passou++; }
  else { console.log(`  ❌ FALHOU (${pen2} eventos)\n`); falhou++; }

  // Caso 3: 5 reentregas
  console.log("CASO 3: 5 reentregas seguidas");
  for (let i = 0; i < 5; i++) await webhookRegistrarFalha("12345678900", 100, "evt_abc123");
  if (eventos.size === 1) { console.log("  ✅ PASSOU — sempre 1\n"); passou++; }
  else { console.log(`  ❌ FALHOU\n`); falhou++; }

  // Caso 4: Polling eventId determinístico
  console.log("CASO 4: Polling gera poll:{rowId}:{chargeId}:{status}");
  await pollingRegistrarFalha("12345678900", 200, "charge_1", "expirado");
  if (eventos.size === 2) { console.log("  ✅ PASSOU — polling registra como distinto\n"); passou++; }
  else { console.log(`  ❌ FALHOU (${eventos.size})\n`); falhou++; }

  // Caso 5: Dois webhooks distintos
  console.log("CASO 5: Dois webhooks distintos");
  await webhookRegistrarFalha("12345678900", 100, "evt_def456");
  if (eventos.size === 3) { console.log("  ✅ PASSOU — cada evento +1\n"); passou++; }
  else { console.log(`  ❌ FALHOU (${eventos.size})\n`); falhou++; }

  // Caso 6: CPF diferente + evento novo
  console.log("CASO 6: CPF diferente + evento novo");
  await webhookRegistrarFalha("99999999900", 300, "evt_x1");
  if (eventos.size === 4) { console.log("  ✅ PASSOU\n"); passou++; }
  else { console.log(`  ❌ FALHOU\n`); falhou++; }

  // Caso 7: eventId string vazia (guard runtime)
  console.log("CASO 7: eventId string vazia ('')");
  try {
    await registrarFalha("11111111100", "");
    console.log("  ❌ FALHOU — string vazia NÃO lançou erro\n");
    falhou++;
  } catch (e) {
    if (e.message.includes("eventId obrigatório")) {
      console.log(`  ✅ PASSOU — lançou: "${e.message}"\n`);
      passou++;
    } else {
      console.log(`  ❌ FALHOU — erro errado: "${e.message}"\n`);
      falhou++;
    }
  }

  // Caso 7b: eventId só espaços
  console.log("CASO 7b: eventId só espaços ('   ')");
  try {
    await registrarFalha("22222222200", "   ");
    console.log("  ❌ FALHOU — espaços NÃO lançou erro\n");
    falhou++;
  } catch (e) {
    if (e.message.includes("eventId obrigatório")) {
      console.log(`  ✅ PASSOU — lançou: "${e.message}"\n`);
      passou++;
    } else {
      console.log(`  ❌ FALHOU — erro errado\n`);
      falhou++;
    }
  }

  // Caso 8: Concorrência 3 chamadas simultâneas
  console.log("CASO 8: 3 chamadas simultâneas, mesmo eventId");
  const antes8 = eventos.size;
  await Promise.all([
    registrarFalha("44444444400", "evt_conc"),
    registrarFalha("44444444400", "evt_conc"),
    registrarFalha("44444444400", "evt_conc"),
  ]);
  if (eventos.size === antes8 + 1) { console.log("  ✅ PASSOU — apenas 1 novo\n"); passou++; }
  else { console.log(`  ❌ FALHOU (${eventos.size - antes8} novos)\n`); falhou++; }

  // Caso 9: DOIS OBSERVADORES — polling + webhook do mesmo sreq
  console.log("CASO 9 (CRÍTICO): Polling + Webhook do MESMO sreq");
  // Cenário A: Webhook chega primeiro
  console.log("  Cenário A: Webhook chega PRIMEIRO");
  const sreqId9 = 500;
  await webhookRegistrarFalha("55555555500", sreqId9, "evt_overdue");
  let pen9a_antes = eventos.size;
  await pollingRegistrarFalha("55555555500", sreqId9, "charge_5", "expirado");
  let pen9a_depois = eventos.size;
  if (pen9a_depois === pen9a_antes) {
    console.log("  ✅ PASSOU — polling ignorado (webhook já registrou)\n");
    passou++;
  } else {
    console.log(`  ❌ FALHOU — polling registrou mesmo com webhook (${pen9a_depois - pen9a_antes} novos)\n`);
    falhou++;
  }

  // Cenário B: Polling chega primeiro
  console.log("  Cenário B: Polling chega PRIMEIRO (webhook depois)");
  const sreqId9b = 600;
  await pollingRegistrarFalha("66666666600", sreqId9b, "charge_6", "expirado");
  let pen9b_antes = eventos.size;
  await webhookRegistrarFalha("66666666600", sreqId9b, "evt_overdue2");
  let pen9b_depois = eventos.size;
  if (pen9b_depois === pen9b_antes + 1) {
    console.log("  ⚠️  ESPERADO — webhook registra como evento distinto");
    console.log("     (polling já penalizou, webhook registra de novo = 2 pontos)");
    console.log("     Este cenário NÃO é coberto pelo guard atual.");
    console.log("     O guard só funciona se webhook chegar PRIMEIRO.");
    console.log("     Se polling chegar primeiro, o webhook ainda registra.");
    console.log("  → CORREÇÃO COMPLETA: webhook também deve verificar polling");
    console.log("     OU usar um eventId compartilhado (sreqId:status)");
    console.log();
    falhou++;
  } else {
    console.log(`  ✅ PASSOU\n`);
    passou++;
  }

  // ── RESUMO ──
  console.log("═══════════════════════════════════════════════════════");
  console.log(`  RESULTADO: ${passou} passou / ${falhou} falhou / ${passou + falhou} total`);
  console.log("═══════════════════════════════════════════════════════");

  if (falhou > 0) {
    console.log("\n  ⚠️  Cenário B do caso 9 ainda vulnerável:");
    console.log("     Se polling chega primeiro, webhook registra depois.");
    console.log("     Solução: usar eventId compartilhado = sreqId:chargeId:status");
  }

  return { passou, falhou, total: passou + falhou };
}

runBattery().then(r => {
  console.log(`\n  Resumo: ${JSON.stringify(r)}`);
  process.exit(r.falhou > 0 ? 1 : 0);
});
