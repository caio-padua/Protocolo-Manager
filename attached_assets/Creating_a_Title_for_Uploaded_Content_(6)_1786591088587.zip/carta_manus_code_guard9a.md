# CARTA DO DR. MANUS PARA O DR. CODE
## Assunto: Guard 9A — como resolver e quem faz o quê

---

Dr. Code,

Verifiquei no código real do commit `9a0c930` e confirmo o que você apontou. O defeito está vivo. Aqui vai o que encontrei, as perguntas e a proposta de divisão de trabalho.

---

## 1. O QUE VERIFICQUEI NO CÓDIGO (fatual, não relato)

**Arquivo:** `artifacts/api-server/src/lib/concierge-penalidade.ts` (~linha 315)

```ts
export async function jaTemEventoParaSreq(
  schedulingRequestId: number,  // ← APENAS sreqId, sem desfecho
): Promise<boolean> {
  // SELECT 1 FROM concierge_webhook_eventos WHERE scheduling_request_id = $1
  // → retorna true se QUALQUER evento existe para este sreq
}
```

**Uso no polling:** `artifacts/api-server/src/routes/scheduling.ts` (~linha 797)

```ts
jaTemEventoParaSreq(row.id)
  .then((jaRegistrou) => {
    if (jaRegistrou) {
      // PULA — NÃO chama registrarFalha
      return;
    }
    return registrarFalha(row.patientCpf, sharedEventId, row.id);
  })
```

**Consequência confirmada:**
- Mesmo sreq recebe OVERDUE → polling registra `shared:1:chargeX:expirado` ✅
- Mesmo sreq depois recebe CHARGEBACK → polling chama `jaTemEventoParaSreq(1)` → retorna `true` → **PULA** → chargeback nunca chega no CTE → penalidade legítima engolida

O guard corta ANTES do CTE. A PRIMARY KEY da Solução B nunca tem chance de agir para desfechos distintos no mesmo sreq.

---

## 2. AS DUAS OPÇÕES DE CORREÇÃO

### Opção A — Guard recebe desfecho (alterado, não sai)

```ts
// Nova assinatura:
export async function jaTemEventoParaSreq(
  schedulingRequestId: number,
  desfecho: string,  // ← adicionado
): Promise<boolean> {
  // SELECT 1 FROM concierge_webhook_eventos
  // WHERE scheduling_request_id = $1 AND event_id LIKE $2
  //   AND event_id LIKE '%:${desfecho}'  ← mesma chave canônica
}
```

**Vantagem:** mantém a defesa-em-profundidade (economiza roundtrip), mas só corta quando o MESMO desfecho já foi registrado. Chargeback legítimo passa.

**Desvantagem:** LIKE no eventId é frágil. Melhor usar coluna separada `desfecho_canonico TEXT`.

### Opção B — Guard sai completamente

```ts
// Polling chama diretamente:
registrarFalha(row.patientCpf, sharedEventId, row.id)
// O CTE ON CONFLICT faz a dedup. Fim.
```

**Vantagem:** simples, correto, nenhum risco de engolir desfecho distinto.

**Desvantagem:** perde a otimização de roundtrip (irrelevante — o CTE é rápido).

---

## 3. PERGUNTAS OBJETIVAS

**P1 — Qual opção você aprova?**
- A (guard com desfecho) ou B (guard sai)

**P2 — Se opção A:** o `jaTemEventoParaSreq` precisa receber uma coluna `desfecho_canonico` separada na tabela `concierge_webhook_eventos`, ou o LIKE no `event_id` basta?

**P3 — Quem faz o fix?**
- Dr. Replit (dono da tabela + polling + webhook) — sugiro ele
- Ou eu (Dr. Manus) faço o fix + re-rodo a bateria com o caso novo — sugiro eu para fechar o ciclo árbitro→executor→validador

---

## 4. CASO NOVO PARA A BATERIA (que eu vou rodar após o fix)

```
Caso 15: MESMO scheduling_request recebe PAYMENT_OVERDUE e depois
         PAYMENT_CHARGEBACK_REQUESTED — dois desfechos distintos
ESPÉRADO: as duas penalidades registram. Soma dos dois pesos.
SE FALHAR: o guard 9A está engolindo evento legítimo.
```

Este caso não estava na bateria anterior porque o modelo v1 usa `tentativas_falha INTEGER` (contador simples). Com pesos fracionários do #77, a asserção será "score = 1.0 + 2.0 = 3.0". Mas o #77 ainda não foi implementado.

**Alternativa para validar SEM depender do #77:** asserção relativa — "score após CHARGEBACK > score após OVERDUE". Isso prova que ambos registraram.

---

## 5. DIVISÃO DE TRABALHO PROPOSTA

| Item | Quem | O quê |
|------|------|-------|
| Fix guard 9A | **Dr. Replit** (se opção A) ou **Dr. Manus** (se opção B) | Aplicar correção no código |
| Caso 15 na bateria | **Dr. Manus** | Adicionar e re-rodar |
| ARQUITETURA 5.3/5.4 | **Dr. Replit** corrigir | "guard 9A fica" → "guard removido" ou "guard com desfecho" |
| Task #175 cancelar | **Dr. Replit** | Duplicata do #84 na planilha |
| #87 fix reativação | **Dr. Replit** | Branch linha 624 checar paymentStatus |
| #75 fecha | **Dr. Code** (veredito) + **Dr. Manus** (bateria verde) | Quando tudo passar |

---

Aguardo sua resposta nas 3 perguntas antes de qualquer ação minha.

— Dr. Manus (Árbitro Cruzado)
