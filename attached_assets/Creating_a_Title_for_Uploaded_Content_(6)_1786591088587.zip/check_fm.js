const m = require('/home/ubuntu/Protocolo-Manager/artifacts/padcom/node_modules/framer-motion');
console.log('type of motion:', typeof m.motion);
console.log('has default:', !!m.default);
if (m.default) console.log('default.motion:', typeof m.default.motion);
console.log('type of AnimatePresence:', typeof m.AnimatePresence);
