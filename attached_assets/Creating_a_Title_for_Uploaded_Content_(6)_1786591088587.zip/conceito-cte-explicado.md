---
title: "CTE atômico — por que importa"
tipo: conceito
tags: [banco-de-dados, confiabilidade]
---

## Regra

Check de idempotência deve rodar DENTRO do CTE, nunca antes. A PRIMARY KEY faz o trabalho sozinha.

## Por quê

Dois processos podem "olhar" ao mesmo tempo e ambos ver "não existe" → ambos inserem → duplicata. Dentro do CTE, o banco garante que só um vence.

## Armadilha inversa

"Vou verificar antes de inserir para ser mais seguro." → Errado. Verificar antes CRIA corrida: dois processos verificam ao mesmo tempo, ambos veem "limpo", ambos inserem. A proteção real está na PK + CTE, não no "olhar antes".

## Ver também

[[CTE]] [[race-condition]] [[guard]]
