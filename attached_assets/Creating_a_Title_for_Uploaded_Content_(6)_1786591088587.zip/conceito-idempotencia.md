---
title: "Idempotência — a vacina contra reenvio"
tipo: conceito
tags: [backend, confiabilidade]
---

## Regra

Todo endpoint que recebe dado externo (webhook, fila, retry) deve ser idempotente.

## Por quê

Sistemas externos reenviam. O Asaas reentrega webhooks. O Telegram resende mensagens. Sem idempotência, cada reenvio = duplicação silenciosa.

## Armadilha inversa

"O chamador é responsável por chamar apenas uma vez." → Errado. Você não controla o chamador externo. A idempotência precisa estar DENTRO do seu sistema, não na confiança de que ninguém vai chamar duas vezes.

## Ver também

[[idempotencia]] [[CTE]] [[ON CONFLICT]]
