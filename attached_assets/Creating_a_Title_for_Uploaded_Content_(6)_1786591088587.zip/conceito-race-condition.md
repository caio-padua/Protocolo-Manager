---
title: "Race condition — o problema dos dois observadores"
tipo: conceito
tags: [concorrência, design]
---

## Regra

Se dois caminhos podem enxergar o mesmo fato, eles precisam usar o mesmo identificador.

## Por quê

No PADAXOR: polling e webhook são dois "olhos" que veem a mesma cobrança vencida. Se cada um usa ID diferente → 2 penalidades por 1 abandono → paciente bloqueado injustamente.

## Armadilha inversa

"Vou fazer o polling verificar se o webhook já registrou." → Só funciona se o webhook chegar primeiro. Se o polling chegar primeiro, o webhook registra depois → mesma corrida. A solução real: mesmo eventId nos dois caminhos.

## Ver também

[[race-condition]] [[dedup]] [[polling]] [[webhook]]
