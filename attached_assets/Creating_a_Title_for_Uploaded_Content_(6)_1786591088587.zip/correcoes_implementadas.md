# Correções Implementadas — Fluxo Upload -> Drive -> Gemini -> Cockpit

## Correções de Código Aplicadas

### 1. exames-lab.ts — startExamIngestion (linhas 240-252)
- ANTES: INSERT não incluía sourcePdfDriveId → ficava NULL se processamento falhasse
- DEPOIS: INSERT inclui `sourcePdfDriveId` quando fornecido no params
- Impacto: Documentos do portal agora sempre mantêm o link com o PDF no Drive

### 2. drive-watcher.ts — processWatchedFolders (linhas 445-498)
- ANTES: `ensureClientFolderStructure(clientId)` — arg errado (number vs string,string)
- ANTES: `uploadFileToDrive(buffer, newName, ...)` — args na ordem errada
- DEPOIS: Busca clientName e cpf do banco, chama com args corretos
- DEPOIS: UploadFileToDrive com args na ordem correta (folderId, fileName, mimeType, buffer, allowDuplicates)
- DEPOIS: Vincula sourcePdfDriveId ao documento após upload

### 3. exames-lab.ts — Nova rota POST /exames-lab/reprocessar/:id (linhas 2176-2285)
- Recebe documentId na URL e opcionalmente driveFileId no body
- Vincula sourcePdfDriveId se fornecido e não existir
- Reseta status para "recebido" e limpa resultados antigos
- Baixa PDF do Drive e reprocessa em background
- Permite recuperar doc 632 com: `POST /exames-lab/reprocessar/632 { "driveFileId": "..." }`

## Melhorias Pendentes (Tarefa 4 da Carta 04)
- Status ao vivo no Portal do Cliente (polling após upload)
- A implementação do EnviarTab precisa de polling para mostrar status de processamento
- O backend já tem GET /exames-lab/documentos?clientId= que retorna status

## Validação do Cockpit (Tarefa 5)
- ExamesEnviadosPanel já consome GET /exames-lab/documentos?clientId=
- EvolucaoExamesPanel já consome GET /exames-lab/evolucao/:clientId
- Ambos estão corretos e funcionando
