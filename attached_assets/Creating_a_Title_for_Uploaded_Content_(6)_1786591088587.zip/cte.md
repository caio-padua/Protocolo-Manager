---
title: "CTE (Common Table Expression)"
tipo: dicionario
tags: [banco-de-dados, SQL]
---

## Definição

Uma consulta SQL que faz várias operações de uma vez, de forma atômica — ou tudo acontece ou nada acontece.

## Quando aparece

Quando precisa deduplicar + inserir + atualizar em uma única operação, sem risco de corrida.

## Pergunta que você pode fazer

"Você está fazendo a dedup e o INSERT em operações separadas ou em um CTE atômico?"

## Exemplo real no PADAXOR

O fix do item #75 usa CTE: verifica se o evento já existe (ON CONFLICT DO NOTHING) e só insere a penalidade se o evento for novo — tudo em um único SQL, sem corrida.
