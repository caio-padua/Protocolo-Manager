---
title: "Dedup (Deduplicação)"
tipo: dicionario
tags: [backend, idempotencia]
---

## Definição

Mecanismo que impede que o mesmo evento seja processado duas vezes. Usa um identificador único para "marcar" o que já foi feito.

## Quando aparece

Webhook reenviado, fila de mensagens, reconciliação entre sistemas.

## Pergunta que você pode fazer

"Qual é a chave de dedup? Se dois caminhos enxergam o mesmo fato, eles usam o mesmo identificador?"

## Exemplo real no PADAXOR

Tabela `concierge_webhook_eventos` com `event_id` como PRIMARY KEY. Formato compartilhado: `shared:{pedidoId}:{cobrancaId}:{desfecho}`. Se o mesmo evento chegar por polling e webhook, a PK conflita e o segundo é ignorado.
