---
title: "Desfecho Canônico"
tipo: dicionario
tags: [design, domínio]
---

## Definição

Traduzir códigos brutos de um sistema externo (ex: `PAYMENT_OVERDUE`, `CHARGE_EXPIRED`) para vocabulário próprio e estável (ex: `expirado`, `cancelado`, `chargeback`).

## Quando aparece

Quando seu sistema depende de provedores externos que podem mudar os códigos a qualquer momento.

## Pergunta que você pode fazer

"Se o Asaas mudar o código do evento de 'expirado' para algo diferente, seu sistema quebra? Como você isola isso?"

## Exemplo real no PADAXOR

O eventId usa desfecho canônico: `shared:{pedido}:{cobranca}:{expirado}`. Mesmo que o Asaas mude de `PAYMENT_OVERDUE` para `CHARGE_EXPIRED`, o sistema interno continua usando `expirado`. O mapeamento acontece em UM lugar só.
