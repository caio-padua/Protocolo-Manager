# Especificação — Protocolo do Paciente: matriz clássica de ênfases

| Campo | Definição |
|---|---|
| **Data** | 12/08/2026 |
| **Autor** | Dr. Manus |
| **Estado** | Protótipo em revisão pelo CEO |
| **Documento-alvo** | Protocolo Médico Personalizado, emitido por **Instituto Pádua · PADAXOR** |
| **Regra principal** | Reorganizar a fiação atual. Não criar dados clínicos, resultados, metas, prescrições ou escalas novas. |

## 1. Laudo honesto

O sistema já tem uma fiação suficientemente rica para uma apresentação superior: cada item do protocolo carrega substância, dose, via, sessões, frequência, data de início, textos educativos e um objeto JSON de impacto por sistema corporal. A fragilidade não é ausência de dados; é a forma de visualizá-los. A matriz atual usa pontos e estrelas, enquanto o gráfico radial é menos compatível com a preferência do CEO por leitura ortogonal, alinhada e imediata.

> **Decisão:** trocar o radar e os pontos coloridos por uma **matriz cartesiana de colunas verticais**. Ela organiza os valores 0–5 já cadastrados em `bodySystemEffects`, sem tratá-los como diagnóstico, garantia de benefício ou eficácia individual.

## 2. Contrato de dados: o que entra e o que não entra

| Zona visual | Campo real usado | Regra de uso |
|---|---|---|
| Cabeçalho | `protocolTitle`, `clientName`, `professionalName`, `professionalCrm`, `unit`, `startDate`, `endDate` | Identificação objetiva; CPF, telefone e e-mail ficam fora da capa do paciente por privacidade e excesso visual. |
| Resumo quantitativo | `substances.length`, `sessions.length`, `startDate`, `endDate` | Cartões de leitura rápida: componentes, sessões, início e horizonte. |
| **Barras verticais** | `substances[].bodySystemEffects` | Altura ordinal 0–5; chave sem valor não vira zero, vira **não informado**. |
| Eixo X | Chaves de `bodySystemEffects` com rótulo em `SYSTEM_LABELS` | Exibir no máximo sete eixos por página; ordenar pela maior ênfase do protocolo e preservar desempates pela ordem institucional. |
| Séries | `substances[].name`, `substances[].color` | Uma coluna/padrão por substância. Cor é auxiliar digital; impressão usa hachuras e legenda A/B/C. |
| Leitura humana | `mainFunction`, `description`, `perceivedEffects`, `timeToEffect` | Texto em tópicos, nunca convertidos arbitrariamente em números. |
| Segurança | `contraindications`, `scientificEvidence` | Bloco “Pontos de atenção / evidência cadastrada”; ausência aparece como “não informado no catálogo”. |
| Técnica | `dose`, `procedureType`, `totalSessions`, `intervalDays`, `startDate` | Quadro técnico conciso, separado da narrativa. |
| Jornada | `sessions[].scheduledDate`, `sessions[].status`, `substanceStatuses` | Grade de sessões por data e por componente. |
| Financeiro | `totalValue`, `payments`, `unitPrice` | Página apartada; não concorre com o conteúdo clínico. |

### Exclusões deliberadas

`starRating` não entra na leitura do paciente: é uma classificação de catálogo sem semântica clínica explícita. Os campos textuais de benefício (`energyBenefit`, `sleepBenefit`, etc.) aparecem como **frases curtas cadastradas**, jamais como altura de barra. Valores não preenchidos não podem ser inferidos como “sem efeito”.

## 3. Componente central: Matriz de Ênfases do Protocolo

### Título e legenda fixa

> **MAPA DE ÊNFASES DO PROTOCOLO**  
> *As colunas organizam a intensidade cadastrada para cada componente em áreas do corpo. Elas mostram como o plano foi estruturado, não medem a sua saúde, gravidade, diagnóstico ou resultado individual.*

| Elemento | Especificação |
|---|---|
| **Eixo Y** | 0 a 5, com linhas-guia horizontais em cinza quente. Textos: `5 · ênfase máxima`, `4 · alta`, `3 · moderada`, `2 · leve`, `1 · baixa`, `0 · sem marcação`. |
| **Eixo X** | Sistemas corporais reais e legíveis: por exemplo, Cardiovascular, Neurocognição, Metabolismo, Imunológico, Muscular, Ossos e Articulações, Longevidade. O conjunto é dinâmico, derivado do protocolo. |
| **Coluna** | Uma barra vertical por substância dentro de cada eixo. Limite de cinco substâncias por matriz. Acima disso, criar continuação em outra página com a mesma escala, sem apertar o gráfico. |
| **Dados ausentes** | Marcar `—`; não desenhar barra de altura zero. A legenda deve explicar: “— não informado no catálogo”. |
| **Codificação dupla** | Digital: navy, cinza e um ouro apenas para foco de navegação. Impressão: hachuras graduais e letras A/B/C junto das colunas. Não depender da cor. |
| **Leitura TDAH-friendly** | Grade vertical e horizontal regular; todos os rótulos alinhados à mesma linha-base; legenda na margem direita; resumo de no máximo três pontos logo abaixo. |

### Regra de seleção e transformação

1. Ler cada chave presente em `bodySystemEffects` e converter número/string pela função já existente `impactNum()`.
2. Descobrir os sistemas informados e calcular, para cada sistema, a maior intensidade entre as substâncias do protocolo.
3. Ordenar sistemas por intensidade máxima decrescente; para empate, usar a ordem de `SYSTEM_LABELS`.
4. Mostrar os sete primeiros. Se houver mais, criar um bloco complementar “Outras áreas cadastradas”, em tabela textual de uma linha por item; nunca comprimir os eixos.
5. Exibir uma coluna somente para valor `> 0`. Valores nulos/ausentes permanecem `—`, sem falsa precisão.
6. Mostrar abaixo do gráfico uma lista “A · [substância]”, “B · [substância]” etc. para reduzir ambiguidade quando a impressão for em escala de cinza.

### Leitura em uma olhada

| Olhar do paciente | Onde encontra | Resposta |
|---|---|---|
| Superior esquerdo | Faixa-resumo | Qual é meu plano, quando começa e quantas sessões há? |
| Centro | Matriz cartesiana | Em quais áreas cada componente foi cadastrado para atuar? |
| Inferior esquerdo | Três tópicos de síntese | Quais são os maiores focos registrados? |
| Inferior direito | Chave A/B/C + nota | Qual barra é qual e como interpretar ausência de marcação? |

## 4. Arquitetura das páginas

| Página | Nome editorial | Composição | Fiação |
|---:|---|---|---|
| 1 | **Carta do seu protocolo** | Marca discreta, paciente, profissional, início, cartões de sessões/componentes, objetivo do documento. | `protocol`, `client`, `professional`, contagens. |
| 2 | **Mapa de ênfases** | Matriz de barras verticais, três tópicos derivados dos maiores eixos, chave A/B/C. | `bodySystemEffects`, `name`. |
| 3…N | **Caderno de componentes** | Uma substância por página, em matriz 2×2: função, o que pode ser percebido, quando reavaliar, pontos de atenção. Faixa técnica lateral. | Todos os campos narrativos e técnicos da substância. |
| N+1 | **Roteiro de sessões** | Grade de datas × componentes, com marcação textual de status. | `sessions`, `substanceStatuses`. |
| N+2 | **Investimento e acompanhamento** | Itemização simples, valor total e situação documentada. | `payments`, `unitPrice`, `totalValue`. |

## 5. Linguagem visual: Toscana clínica

| Camada | Escolha | Regra para impressão |
|---|---|---|
| Fundo | Marfim `#FAF9F6` | Fundo branco ou marfim muito leve; sem blocos escuros de página inteira. |
| Texto | Navy `#0B1D3A` | Preto/navy sólido, mínimo 12 pt no conteúdo jurídico e 10,5–11 pt no guia clínico. |
| Destaque | Ouro seco `#D4AF37` | Linhas finas, números de capítulo e seção. Nunca usado para parágrafos ou barras essenciais. |
| Tipografia editorial | **Cormorant Garamond** ou **EB Garamond** | Títulos de seção em caixa alta espaçada; não ultrapassar duas famílias. |
| Tipografia informacional | **Archivo** | Rótulos, dados e tabelas com alinhamento tabular. |
| Estrutura | Grade de 12 colunas / margens generosas | Tudo se alinha a uma malha; divisões com linhas de 0,5 pt e muito espaço em branco. |

### Fonte: regra de implementação

O frontend já carrega as famílias no `artifacts/padcom/index.html`. O gerador `pdf-signer.ts`, porém, hoje incorpora Helvetica. Para o PDF final receber a tipografia clássica, o executor deve baixar os arquivos TTF regulares/semi-bold licenciados pelo **Google Fonts** para Cormorant Garamond (ou EB Garamond) e Archivo, incluir esses arquivos como asset do `api-server` e incorporá-los com `pdfDoc.embedFont()`. Não usar URL de CSS do navegador dentro de `pdf-lib`; ela não é fonte incorporável em PDF.

## 6. Linhas vermelhas clínicas e de impressão

- Não escrever “vai melhorar”; usar “foi incluída para apoiar / foi cadastrada com ênfase em”.
- Não converter texto de benefício ou estrela em escore clínico.
- Não levar CPF, telefone ou e-mail para a capa visível quando o documento for circular impresso.
- Não usar fundo navy integral fora de uma capa opcional digital; para impressão padrão, usar papel marfim com marca em navy.
- Não repetir grandes parágrafos. Cada bloco deve caber em três tópicos ou uma frase de apoio.
- Não desenhar qualquer elemento depois da assinatura PAdES; manter o fluxo existente de composição → cabeçalho/rodapé → assinatura.

## 7. Critérios de aceite da revisão

1. Em dez segundos, o paciente encontra protocolo, início, número de sessões e componentes.
2. Em vinte segundos, identifica as áreas cadastradas de maior ênfase, a substância correspondente e a escala 0–5 sem precisar de cor.
3. Cada página individual responde em tópicos: por que entrou, o que pode ser percebido, quando a equipe reavalia e quando falar com a equipe.
4. O documento mantém leitura clara em impressão A4 colorida e monocromática.
5. Toda informação exibida possui origem em `ProtocolDocumentData`, `ProtocolDocSubstance`, `ProtocolDocSession` ou `ProtocolDocPayment` existentes.
