# ESTADO ATUAL — BATERIA #81-A RE-RODADA (12/08/2026)

## Contexto
- Commit atual no repo: `9a0c930` (HEAD, origin/main)
- Commits da sessão: `0187c3d` (Solução B) + `d0f50c2` (docs ARQUITETURA) + `9a0c930` (carta)
- Dr. Replit implementou Solução B com formato `shared:` em polling E webhook

## Solução B implementada (verificada no código)
- Polling (scheduling.ts:796): `shared:${row.id}:${row.asaasChargeId ?? "nocharge"}:${mapped}`
- Webhook (asaas.ts:706): `shared:${sreq.id}:${payment.id}:expirado`
- Webhook (asaas.ts:728): `shared:${sreq.id}:${payment.id}:cancelado`
- `payment.id == asaasChargeId` — mesmo ID Asaas nos dois caminhos
- `ON CONFLICT (event_id) DO NOTHING` no CTE deduplica atomicamente
- Guard 9A (jaTemEventoParaSreq) FICA como defesa-em-profundidade (não em registrarFalha)

## Fix reativação (#87) — NÃO aplicado ainda
- Branch linha 624 ainda é: `if (fresh.asaasChargeId && fresh.asaasInvoiceUrl)`
- Não há checagem de paymentStatus ≠ "expirado"/"cancelado"
- Bug: paciente expirado recebe link morto

## Casos 13-20 (da ARQUITETURA seção 8.2) — com pesos (mas modelo v1 = tentativas INTEGER)
| # | Evento | Resultado esperado |
|---|---|---|
| 13 | PAYMENT_OVERDUE 1x | tentativas=1, não re-registra |
| 14 | PAYMENT_DELETED 1x | tentativas=1 |
| 15 | PAYMENT_REFUNDED 1x | tentativas=1 |
| 16 | PAYMENT_CHARGEBACK_REQUESTED 1x | tentativas=1 |
| 17 | PAYMENT_OVERDUE ×3 reentregas | tentativas=1 (não 3) |
| 18 | DELETED + REFUNDED (distintos) | tentativas=2 |
| 19 | OVERDUE → PAID | tentativas=0 (piso) |
| 20 | PAID sem evento anterior | tentativas=0 (piso) |

NOTA: modelo atual é v1 (tentativas_falha INTEGER). O modelo v2 (score_pontos) é do #77 (Dr. Code).
Os pesos (+0,5, +1,0, +2,0, -1,0) aparecem na ARQUITETURA mas o código atual usa contador.
Para a bateria, testar "não re-registra" (idempotência) é o que importa agora.

## Bateria #81-A v1 resultado (commit 3bebcde): 10 passou / 1 falhou / 11 total
- Caso 9B falhou (polling primeiro, webhook depois registra)
- Casos 1-8, 9A passaram

## Bateria #81-A v2 (agora, commit 9a0c930):
- Formato eventId mudou de `poll:` para `shared:` — dedup funciona para qualquer ordem
- Casos 1-8: comportamentos válidos, mas eventIds literais precisam atualizar para `shared:`
- Casos 9A, 9B: agora devem PASSAR (shared: deduplica qualquer ordem)
- Casos 13-20: novos casos a incluir

## BATERIA v3 RESULTADO (contra commit 9a0c930): ✅ 23 passou / 0 falhou / 23 total
- Todos os casos 1-20 passaram (casos 3a, 3b, 3c são sub-casos do caso 3)
- Casos 9A, 9B agora passam com formato shared: (dedup atômica qualquer ordem)
- Casos 10-12 validam vocabulário canônico + reativação
- Casos 13-20 validam comportamento com vocabulário ARQUITETURA 8.2
- Modelo v1 (tentativas_falha INTEGER) — pesos são do #77 (Dr. Code)

## Pendências
- #75 pode fechar: hash 9a0c930 + bateria verde (23/23)
- #87 (fix reativação) ainda NÃO implementado no repo
- Dr. Code precisa confirmar ARQUITETURA 5.3/5.4
- Plano de publicação Slack: hash + saída bruta + planilha atualizada (coluna H #75 = CONCLUÍDO)

## Links Slack
- Carta avaliação: https://padua-01.slack.com/archives/C0BLW5S7GQL/p1786535551143205
- Bateria v1: https://padua-01.slack.com/archives/C0BLW5S7GQL/p1786535551143205
