# ESTADO ATUAL — TRAVA CONCIERGE (12/08/2026, 23:21)

## SLACK — MENSAGENS POSTADAS (Dr. Manus)
1. Avaliação do árbitro: https://padua-01.slack.com/archives/C0BLW5S7GQL/p1786499797173799
2. Handoff para equipe: https://padua-01.slack.com/archives/C0BLW5S7GQL/p1786499903599551
3. Carta regressão #75: https://padua-01.slack.com/archives/C0BLW5S7GQL/p1786500103474494
4. Resposta ao Dr. Code: https://padua-01.slack.com/archives/C0BLW5S7GQL/p1786500504816522

## PLANILHA — ESTADO ATUAL (corrigida)
| # | Item | Responsável | Status | Prioridade | Depende |
|---|---|---|---|---|---|
| 74 | Trava escassez Concierge (base) | Dr. Replit | CONCLUÍDO | P0 | — |
| 75 | Idempotência webhook Asaas | Dr. Replit | A FAZER - REGRESSAO | P0 | — |
| 76 | Guard backend concierge-request | Dr. Replit | CONCLUÍDO | P0 | — |
| 77 | Peso por desfecho + pontuação | Dr. Code | A FAZER | P1 | 75 |
| 78 | Janela + decaimento 90d + suspensão 180d | Dr. Code | A FAZER | P1 | 77 |
| 79 | Verificação por código no canal | Dr. Code | A FAZER | P1 | 75 |
| 80 | Fricção por dispositivo (SINAL, fricção crescente) | Dr. Manus | A FAZER | P1 | 79 |
| 81 | Bateria de 20 casos (pesos fracionários) | Dr. Manus | A FAZER | P1 | 75,77,78,79 |
| 82 | Migrar tabela para Drizzle | Dr. Code | A FAZER | P2 | 77 |
| 83 | Tela Inteligência Comercial | Dr. Manus | A FAZER | P2 | 77,78,79 |
| 84 | Frontend trata throttled | Dr. Replit | A FAZER | P1 | 80 |
| 85 | Teste: fingerprint ausente + CGNAT | Dr. Manus | A FAZER | P1 | 80 |
| 86 | Revisão semântica da mensagem | Dr. Manus | A FAZER | P2 | 84 |

## CORREÇÕES ACEITAS DO DR. CODE
1. #80 = sinal não chave (fricção crescente, não recusa binária)
2. Fingerprint nunca limitar por IP isolado (CGNAT)
3. Limite alto 50/dia só contra automação
4. DDL: UNIQUE(device_fingerprint, dia_brt) + dia_brt DATE
5. Tabela no schema Drizzle
6. #81 depende de #75, #77, #78, #79 (pesos fracionários)
7. Fonte única: docs/concierge/ARQUITETURA.md (Dr. Code vai escrever)

## REGRA NOVA (Dr. Caio aprovou)
"O concierge não recebe paciente real antes do #79 estar no ar."

## PRÓXIMOS PASSOS
- Dr. Code: escrever docs/concierge/ARQUITETURA.md (fonte única)
- Dr. Replit: refazer #75 (idempotência sem remover guard backend)
- Dr. Code: #77, #78, #79 (quando #75 refeito)
- Dr. Manus: #80, #81 (quando #79 pronto)

## DOCUMENTOS SALVOS
- /home/ubuntu/especificacao_dr_manus_concierge.md (original, desatualizada)
- /home/ubuntu/carta_manus_regressao_75.md (carta formal da regressão)
- /home/ubuntu/estado_atual_concierge.md (estado anterior)
- /home/ubuntu/estado_atual_final.md (este arquivo)

## REGRAS DO CEO
- Numeração única da planilha
- Item só fecha com hash de commit + caso testado
- brtNow() para datas BRT
- NUNCA DROP TABLE/COLUMN sem ordem escrita dupla
- Toda coluna nova = ADD COLUMN
- Não atribuir ao CEO confirmações que ele não deu
