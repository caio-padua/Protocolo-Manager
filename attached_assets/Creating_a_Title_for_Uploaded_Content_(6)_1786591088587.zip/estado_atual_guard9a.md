# ESTADO ATUAL — PROBLEMA GUARD 9A (12/08/2026)

## Carta do Dr. Code (pasted_content_14.txt)
- Dr. Code apontou que "guard 9A fica" contradiz a decisão do árbitro (Dr. Manus)
- A decisão era: Guard 9A SAI (substituído pela Solução B)
- Motivo: sem desfecho, engole chargeback legítimo
- Dr. Code pediu: "PARE antes de re-rodar a bateria"
- Dr. Code pediu: acrescentar caso 15 — mesmo sreq com OVERDUE + CHARGEBACK → 2 penalidades devem registrar

## Verificação no código (commit 9a0c930) — CONFIRMADO: DEFEITO VIVO
- `jaTemEventoParaSreq(sreqId)` — recebe APENAS sreqId, sem desfecho
- Localização: `artifacts/api-server/src/lib/concierge-penalidade.ts` linha ~315
- Uso no polling: `artifacts/api-server/src/routes/scheduling.ts` linha ~797
  - Polling chama `jaTemEventoParaSreq(row.id)` ANTES de chamar `registrarFalha()`
  - Se retornar true → PULA (não chama registrarFalha) → CTE nunca chega
- Consequência: mesmo sreq com OVERDUE + CHARGEBACK = 2 penalidades NÃO registram
  - Guard corta chargeback legítimo (defeito exato que decidimos eliminar)

## Task #175 — NÃO existe na planilha
- Dr. Replit criou Task #175 como "frontend agendar.tsx trata throttled + requiresVerification"
- Isso JÁ É o item #84 na planilha (linha 81): "Frontend agendar.tsx trata resposta throttled..."
- Dr. Replit = mesmo dono, mesma descrição, mesma dependência (#80)
- 5ª ocorrência de numeração paralela

## Planilha atual (últimos itens):
- #74: Trava escassez Concierge (base) — CONCLUÍDO
- #75: Idempotência — AGUARDANDO #81-A
- #76: Guard backend — CONCLUÍDO
- #77-#79: Peso/decaimento/verificação — A FAZER (Dr. Code)
- #80-#83: Fricção/bateria/tela IC — A FAZER (Dr. Manus)
- #84: Frontend throttled — A FAZER (Dr. Replit)
- #85: Caso fingerprint ausente — A FAZER (Dr. Manus)
- #86: Revisão texto fricção — A FAZER (Dr. Manus)
- #87: Fix reativação — A FAZER (Dr. Replit)

## O que fazer agora:
1. Escrever carta ao Dr. Replit: guard 9A precisa SAIR (ou receber desfecho)
2. Adicionar caso novo na bateria: OVERDUE + CHARGEBACK mesmo sreq → 2 penalidades
3. NÃO re-rodar a bateria até guard ser corrigido
4. Atualizar planilha #75 (continua AGUARDANDO)
5. Postar no Slack

## Dr. Caio pediu:
- "AUTORIZADO" — para eu agir sem pedir permissão
- "AUTONOMIA TOTAL" — não perguntar antes de executar
