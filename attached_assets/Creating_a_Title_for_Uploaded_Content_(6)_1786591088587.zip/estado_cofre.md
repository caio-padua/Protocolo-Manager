# ESTADO — Cofre Obsidian (padua-segundo-cerebro)
## 12/08/2026

### Repo criado: https://github.com/caio-padua/padua-segundo-cerebro (privado)
### Local: /home/ubuntu/padua-segundo-cerebro/

### Estrutura criada:
- 00-Inbox/
- 10-Leis/
- 20-Decisoes/
- 30-Pos-Mortems/
- 40-Equipe/
- 50-Sistemas/
- 60-Dicionario/
- 70-Didatica/
- 90-Templates/
- 99-Arquivo/
- README.md ✅

### Falta criar:
- Templates (90-Templates/): ADR, postmortem, nota de conceito, nota dicionário
- Notas atômicas reais desta semana
- Commit + push

### Notas que preciso criar (baseadas no trabalho desta semana):

**10-Leis/**:
- lei-001-numeracao-unica-planilha.md
- lei-002-item-so-fecha-com-hash.md

**20-Decisoes/**:
- ADR-guard-cte.md (guard 9A removido)
- ADR-eventId-compartilhado.md (Solução B)

**30-Pos-Mortems/**:
- PM-commit-desfaz-commit.md (regressão #75)
- PM-bateria-cega.md (23/23 com defeito vivo)

**60-Dicionario/**:
- idempotencia.md
- CTE.md
- race-condition.md
- guard.md
- dedup.md
- webhook.md
- polling.md
- PRIMARY-KEY.md
- ON-CONFLICT.md

**70-Didatica/**:
- conceito-cte-explicado.md
- conceito-race-condition.md
- conceito-idempotencia.md

### Perfil do Dr. Caio:
- Médico, TDAH, TOC, Asperger grau 1
- Autodidata, aprende no meio da ação
- Quer repertório para se comunicar com agentes (Replit, Code, Lovable, Claude, Manus)
- Está criando sistemas médicos + outros domínios
- Precisa de notas curtas, diretas, sem ritual
- Tags: #principio #padrao #registro
- Anti-cemitério: Dataview (mas pode ser manual simples)

### Template ADR (4 campos do Replit + validado_em do Manus):
```markdown
---
title: <verbo + substantivo>
date: AAAA-MM-DD
status: accepted | superseded
tags: [domínio]
systems: [PADCOM]
validado_em: []
---
## O que decidimos
## Por quê
## O que vigora
## O que vai apodrecer
```

### Template Postmortem:
```markdown
---
title: <O que quebrou>
date: AAAA-MM-DD
classe: [classe do erro]
---
## Sintoma
## Causa raiz
## Como foi detectado
## Regra nova
## Onde vai aparecer de novo
```

### Template Nota de Conceito (Didática):
```markdown
---
title: <conceito>
tipo: conceito
tags: [área]
---
## Regra
## Por quê
## Armadilha inversa
## Ver também
```
