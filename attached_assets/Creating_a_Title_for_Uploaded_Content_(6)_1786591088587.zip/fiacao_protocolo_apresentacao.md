# Fiação Real — Protocolo de Apresentação ao Paciente (Inventário para Redesign Premium)

Data: 12/08/2026 · Dr. Manus (árbitro) · Repo: Protocolo-Manager @ `9ef26d7`

## O que o paciente VÊ (tela `/area` → tab PROTOCOLOS)

Rota: `GET /api/area-paciente/protocolos` (auth bearer do paciente).
Frontend: `artifacts/padcom/src/pages/area.tsx` — componente `ProtocolCard` (linhas 1135-1220).

### Payload do backend por protocolo
| Campo | Origem | Observação |
|---|---|---|
| title, status, startDate, endDate, unit, serviceType, totalSessions, completedSessions, totalValue | `protocols` | status ∈ active/completed/cancelled; serviceType ∈ clinic/domiciliar/online |
| items[] (substâncias) | `protocol_items` JOIN `substances` | |
| items.substanceName, color, procedureType, mainFunction | `substances` | |
| items.dose, totalSessions, completedSessions, intervalDays, startDate, frequency | `protocol_items` | frequency ∈ weekly etc. |

### Hoje NÃO chega ao paciente (mas EXISTE na tabela `substances`)
- description, perceivedEffects, timeToEffect, starRating
- bodySystemEffects (jsonb), categoryMeters (jsonb)
- longevityBenefit, qualityOfLifeImpact, sleepBenefit, energyBenefit, libidoBenefit, physicalPerformance, muscleStrength, mentalClarity, skinHairNails, immuneSupport
- contraindications, scientificEvidence
- composition/composicao (blend)

### Hoje chega ao paciente: apenas nome, cor, tipo, dose, sessões, intervalo, função principal.

## Fiação da tabela `substances` (DB: lib/db/src/schema/substances.ts)
Campos-chave para apresentação:
- Identificação: name, category, color, starRating, categoryType, procedureType, codigoPadcom
- Posologia: defaultDose, intervalDays, durationMinutes, maxSessionsPerWeek, concentrationMg, volumeAmpola, frequencyBase
- Custo/logística: pricePerUnit, stockQuantity
- Clínico: description, mainFunction, perceivedEffects, timeToEffect, contraindications, scientificEvidence
- JSONB: bodySystemEffects {sistema: 0-5}, categoryMeters {emagrecimento|hipertrofia|recuperacao_muscular|neurocognicao: 0-5}
- Benefícios por área (10 campos text): longevityBenefit, qualityOfLifeImpact, sleepBenefit, energyBenefit, libidoBenefit, physicalPerformance, muscleStrength, mentalClarity, skinHairNails, immuneSupport
- Composição blend: composicao (texto, parseado por regex em shared.tsx)

## Componentes existentes (shared.tsx da página /substances)
- BODY_SYSTEM_LABELS: 20 sistemas corporais com ícone + cor
- BAR_COLORS: 5 cores para score 1-5 (red-200 → emerald-500)
- CategoryMetersShowcase: card "ouro e diamante" com legendas
- BlendComposition: parse da composicao
- getProcedureLabel: im/implant/iv
- getCategoryStyle: por categoria (antioxidante, vitamina, mineral, etc.)

## Admin (tela /substances) — SubstanceEditForm, 8 blocos:
1. Identificação (nome, cor, categoria, categoryType, procedimento, estrelas)
2. Posologia & Logística (concentrationMg, volumeAmpola, dosePadrao, intervalo, duracao, tempoResultado)
3. Composição do Blend (composicao)
4. Impacto nos Sistemas Corporais (bodySystemEffects)
5. Medidores de Resultado (categoryMeters)
6. Descrição Clínica (description, mainFunction, perceivedEffects)
7. Benefícios por Área (10 campos)
8. Segurança & Evidência (contraindications, scientificEvidence)

## Design system atual do paciente (area.tsx)
- Paxter 3D: panel-3d, concave-3d, bevel-3d, login-card-topbar
- Fonte paciente: Lora (.leva-q), "reservada ao paciente"
- Tabs: INÍCIO, PROTOCOLOS, AGENDA, DOCUMENTOS, ENVIAR, EVOLUÇÃO
- Cores: navy dourado (design PADAXOR: Navy #16294a / Ouro #9a7b32)

## Frontend admin atual de /substances (index.tsx)
- Card expansível com grade 5 colunas: valor, dose, intervalo, duração, estoque
- Detalhes: CategoryMetersShowcase, BlendComposition, função principal, barras de sistemas corporais, 10 benefícios, contraindicações, evidência
- ESTILO: "painel-3d" concave/convex com muitos tons pastéis — fonte do descontentamento do CEO (visual pouco premium, parece formulário)
