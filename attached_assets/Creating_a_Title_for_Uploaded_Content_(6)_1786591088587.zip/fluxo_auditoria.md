# Fluxo de Auditoria e Escrita de Specs (Método Manus-Padcon)

Este documento define o processo exato que o agente deve seguir quando o Dr. Caio solicitar a criação de uma nova funcionalidade, a integração de sistemas ou a auditoria de um repositório.

## Fase 1: Diagnóstico e Mapeamento
1. **Clonar/Acessar o Repositório:** Sempre comece mapeando a estrutura raiz (`ls -la`, `find`).
2. **Ler a "Bíblia":** Procure e leia os arquivos `replit.md`, `HANDOFF_MANUS.md` ou `DIRETRIZES_CENTRAIS_E_PRE_REQUISITOS_CEO_DR_CAIO*.md`. Eles contêm as regras de negócio e a história do projeto.
3. **Auditar o Banco de Dados (Drizzle):** O coração do Padcon está em `lib/db/src/schema/`. Analise as tabelas existentes usando `cat` e `grep` antes de propor qualquer nova tabela.
4. **Auditar as Rotas (API):** Verifique `artifacts/api-server/src/routes/` para entender como o frontend se comunica com o banco.

## Fase 2: Comunicação Visual
Antes de escrever código ou laudos longos, crie diagramas Mermaid (.mmd) para ilustrar a arquitetura, o fluxo de transplante ou o organograma da equipe. Renderize-os para PNG usando `manus-render-diagram`.

## Fase 3: O Laudo Honesto
O Dr. Caio valoriza a sinceridade brutal. O laudo deve conter:
- O que o sistema **já tem** de bom (valorize o trabalho do Dr. Replit Paxter e do Dr. Claude).
- Os **Gaps** (o que falta para resolver a dor atual).
- Se houver comparação entre repositórios (ex: Manager vs IHE), faça uma tabela de prós e contras e recomende o que deve ser importado (Transplante).

## Fase 4: A Escrita da Spec Técnica
Toda spec gerada para o Padcon deve seguir um formato rigoroso para que o Dr. Replit Paxter possa codificar sem ambiguidades.

**Estrutura Obrigatória da Spec:**
1. **Cabeçalho:** Data, Autor (Dr. Manus), Status (Aprovada pelo CEO).
2. **A Dor Atual:** Descrição clara do problema (ex: "O médico age como digitador de abas").
3. **A Solução:** Visão geral da arquitetura ou UI proposta.
4. **Banco de Dados (Drizzle):** Definição exata das tabelas, colunas (com tipos `pg-core`) e relações.
5. **API / Rotas:** Endpoints necessários (`GET`, `POST`) e o que eles fazem.
6. **UI / UX:** Comportamento esperado no frontend (ex: "Acordeão na coluna direita", "Botão fica cinza se faltar exame").

## Fase 5: O Fluxo de Diagnóstico e Tréplica (Novo Padrão)

Before writing massive specs for existing systems, **always ask for the real state first**.

1. **Carta de Diagnóstico Funcional:** Write a letter to the Executor asking for the real code of specific areas (e.g., Menu, Cockpit, Cartório). Do not guess.
2. **Read the Response:** The Executor will send the real state (often proving your initial assumptions wrong).
3. **Tréplica Funcional:** Write the response acknowledging the real state, correcting your mental map, and proposing the architectural improvements (e.g., RBAC, Event Bus).
4. **Then write the Spec:** Only write the final spec after this handshake is complete.

## Fase 6: O Master Loop e a Carta-Missão
Se a solução envolver múltiplas specs ou frentes de trabalho, crie uma spec `MASTER-LOOP-PAXTER.md` que agrupe tudo em "Ondas" sequenciais, exigindo Kaizen (melhorias contínuas) e autonomia total do Executor.

Em seguida, escreva a **Carta-Missão** para o Executor em formato **Densidade B**:
- Sem acentos (evita problemas de encoding).
- Texto puro.
- Estruturado em tabelas.
- Regras de Ouro claras (autonomia, Kaizen, linhas vermelhas).
- Um "Resumo em 1 linha" no final.

## Fase 7: O Commit
Após escrever a spec, faça o commit localmente no repositório com uma mensagem semântica clara (ex: `feat(specs): add GAP-04 — Cockpit da Consulta`). O Dr. Replit Paxter fará o push/pull posteriormente.
