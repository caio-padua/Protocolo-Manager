---
title: "Guard (Guarda/Proteção)"
tipo: dicionario
tags: [backend, segurança]
---

## Definição

Verificação que bloqueia uma ação antes que ela aconteça. "Se condição X, não deixe passar."

## Quando aparece

Bloquear paciente bloqueado, impedir cobrança duplicada, limitar tentativas.

## Pergunta que você pode fazer

"Onde está o guard? Ele roda antes ou depois da operação? Ele é atômico com a operação?"

## Exemplo real no PADAXOR

Guard `jaTemEventoParaSreq()` verificava se o pedido já tinha evento ANTES de registrar penalidade. Problema: rodava fora do CTE, cortava eventos legítimos distintos (expirado + chargeback), e criava corrida. Foi removido — a PK do CTE faz o trabalho sozinha.
