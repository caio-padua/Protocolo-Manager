# Direção de Design — Protocolo Premium do Instituto Pádua

## Três caminhos explorados

### Tema: Carta de Tratamento
**Introdução breve:** Um documento clínico pessoal, em navy profundo e marfim, que transforma o protocolo em uma jornada de cuidado legível e serena. A sensação é de uma carta de uma clínica de alta precisão, não de um formulário ou painel administrativo.
**Probabilidade:** 0.07

### Tema: Galeria Biofílica
**Introdução breve:** Uma experiência clara e leve, inspirada em uma galeria de saúde preventiva, com materiais orgânicos e muito espaço respirável. O resultado seria caloroso e contemplativo, com menos ênfase institucional.
**Probabilidade:** 0.04

### Tema: Atlas Clínico Noturno
**Introdução breve:** Um ambiente escuro, técnico e imersivo, com mapas corporais e brilhos discretos em ouro. Seria mais próximo a um laboratório de performance de ponta do que a uma carta clínica.
**Probabilidade:** 0.09

---

## Caminho escolhido: Carta de Tratamento

### Movimento de design
**Editorial médico contemporâneo**, combinando a sobriedade de uma publicação clínica de luxo com a clareza de um dashboard de acompanhamento. O paciente deve sentir que recebeu um plano cuidadosamente composto pelo **Instituto Pádua**.

### Princípios centrais
1. **Acompanhamento antes de catálogo:** cada bloco responde a uma pergunta real do paciente: onde estou, o que vem agora e por que esta substância está aqui.
2. **Hierarquia por silêncio:** poucas linhas, grandes áreas de respiro e agrupamentos claros; bordas existem só quando adicionam significado.
3. **Precisão com acolhimento:** dados técnicos são traduzidos em linguagem humana sem ocultar dose, intervalo ou o estágio do tratamento.
4. **Transparência elegante:** contraindicações, expectativa de resultado e detalhes clínicos ficam disponíveis no dossier, sem alarmismo e sem serem escondidos.

### Filosofia de cor
O **navy #16294A** sustenta confiança, permanência e precisão clínica. O **ouro #9A7B32** aparece como assinatura — marca o progresso, a orientação médica e elementos de alta importância; nunca como decoração indiscriminada. Marfim mineral e cinzas azulados criam um campo de leitura cálido, evitando o branco hospitalar e o preto tecnológico agressivo.

### Paradigma de layout
Uma **coluna documental assimétrica**. O cabeçalho funciona como folha de rosto; em seguida o progresso é uma peça isolada, quase um selo. As substâncias surgem como capítulos de uma composição editorial, com uma coluna lateral para sinais de dose/ritmo e uma área principal para intenção terapêutica. Não há grade de KPIs repetitiva ou uma parede de cartões idênticos.

### Elementos de assinatura
1. **Selo de progresso radial** em ouro fosco com sessões concluídas no centro.
2. **Linha de assinatura dourada** curta sob os títulos, inspirada em documentos clínicos de arquivo.
3. **Dossier de substância** que se abre em uma lâmina interna de marfim, revelando efeitos, sistemas corporais e segurança.

### Filosofia de interação
O paciente vê o essencial sem tocar em nada. Os detalhes existem como camadas voluntárias: abrir o dossier é uma decisão consciente e sempre reversível. A experiência não pede que o paciente “aprenda o sistema”; ela acompanha a leitura natural de uma carta.

### Animação
Entrada discreta em cascata: o cabeçalho aparece primeiro, o selo de progresso em seguida e as substâncias por último, com intervalos de 50 ms e duração máxima de 240 ms. O dossier abre por opacidade e pequena translação vertical — sem expansões elásticas. Barras e o anel de progresso são desenhados uma vez, em 650 ms, apenas quando entram no viewport. Toda animação respeita `prefers-reduced-motion`.

### Sistema tipográfico
- **Cormorant Garamond** para o título do protocolo, o nome de substâncias e frases clínicas importantes — tom editorial, humano e distinto.
- **Manrope** para dados, rótulos, dose, intervalo e navegação — precisão contemporânea e excelente leitura em tela.
- Hierarquia: títulos em serif 34–44 px; texto clínico 16–18 px; rótulos em sans 10–11 px, espaçados e em caixa alta. Nunca usar Inter.

### Essência da marca
**Um plano de cuidado médico visualmente inteligível, para pacientes que querem acompanhar o próprio tratamento com clareza e confiança.**

Personalidade: **precisa, humana, serena**.

### Voz da marca
As manchetes devem ser calmas e afirmativas; CTAs descrevem uma ação concreta; microcopy explica sem infantilizar.

Exemplos:
- “Seu tratamento, organizado para o próximo passo.”
- “Ver dossier clínico desta substância.”

### Wordmark e logo
O símbolo é um monograma geométrico **P** com um traço ascendente inspirado em uma ampola, desenhado em ouro fosco dentro de uma moldura quadrada navy. Sem texto dentro do símbolo; o wordmark “Instituto Pádua” fica ao lado, em serifada editorial, quando houver espaço.

### Cor de assinatura
**Ouro Pádua — #9A7B32.** Um ouro queimado, clínico e sóbrio, não metálico brilhante.

## Style Decisions

- **Decisão do CEO — 12/08/2026:** na Carta de Tratamento multiclínica, **PADAXOR Clinical Intelligent System** é a identidade visual principal. A clínica é emissora variável e ocupa uma área reservada, sem competir com o produto na capa.
- A capa usa exclusivamente o ativo oficial de símbolo com vidro e brilho sobre navy. O símbolo é herança visual do sistema; não é redesenhado nem replicado como ornamento nas páginas internas.
- O selo radial Ouro Pádua é a peça de assinatura do resumo: representa a relação entre sessões registradas e previstas usando a fiação `sessions`, não uma métrica clínica nova.
- Cada substância é um capítulo editorial de folha inteira: intenção terapêutica e papel no plano estabelecem a leitura; dose, ritmo, mapas e medidores são camadas de dossier amplas, laterais e estáveis — não microcards equivalentes.
- A composição privilegia frases clínicas calmas em Cormorant e metadados objetivos em Manrope. Não há jargão de plataforma desnecessário na leitura do paciente.
- Ouro Pádua marca somente orientação, progresso, numeração-chave e linhas de assinatura. Não há estrelas, badges decorativos ou linguagem de catálogo.
- PADCON é indicada exclusivamente como proveniência tecnológica discreta no rodapé. Navy, marfim e linhas de arquivo carregam a maior parte da arquitetura visual.
