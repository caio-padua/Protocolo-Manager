---
title: "Idempotência"
tipo: dicionario
tags: [backend, confiabilidade]
---

## Definição

Fazer a mesma coisa duas vezes tem o mesmo resultado que fazer uma vez. O sistema não "duplica" o efeito.

## Quando aparece

Webhook que chega duas vezes, botão clicado duas vezes, cobrança que expira e é recriada.

## Pergunta que você pode fazer

"Se o Asaas reenviar o mesmo webhook duas vezes, o paciente leva duas penalidades ou uma?"

## Exemplo real no PADAXOR

O Asaas reentrega webhooks. Sem idempotência, 1 cobrança vencida virava 3 penalidades → paciente bloqueado permanentemente sem ter abandonado nada.
