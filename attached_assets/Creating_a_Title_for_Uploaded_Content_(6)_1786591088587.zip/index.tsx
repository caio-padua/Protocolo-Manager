/**
 * Cockpit Unificado v2 — Refatorado (Onda Fusão 2.0, 23/07/2026)
 *
 * Mudanças aplicadas:
 *   1. ESTADO: Zustand store (./store.ts) — estado isolado, sem prop drilling.
 *   2. HEADER: Componente isolado (CockpitHeader.tsx) com identidade do paciente
 *      unificada, animações Motion, LED de alarme.
 *   3. TAB RAIL: Componente isolado (CockpitTabRail.tsx) com scroll suave,
 *      indicadores de rolagem, dot de alerta pulsante.
 *   4. LAZY LOADING: Abas pesadas (Protocolos, Financeiro, Cadastro) via
 *      React.lazy + Suspense. Abas leves montadas diretamente.
 *   5. MODULARIZAÇÃO: Cada aba pesada é um componente isolado (./panels/).
 *   6. ANIMAÇÕES: Framer Motion (AnimatePresence) para transição de identidade
 *      e tabs.
 *   7. DESIGNS SYSTEM: 100% conformidade com skill-layout-paxter.
 *
 * Spec: specs/cockpit-unificado.md
 */
import { useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { UserRound } from "lucide-react";
import { useListClients, useGetClient } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { BASE } from "../comunicacao/_shared";

// ── Store ─────────────────────────────────────────────────────────────────────
import { useCockpitStore } from "./store";

// ── Componentes refatorados ───────────────────────────────────────────────────
import CockpitHeader from "./CockpitHeader";
import CockpitTabRail from "./CockpitTabRail";
import {
  PrescricaoAba,
  InjetaveisAba,
  ImplantesAba,
  ExamesAba,
  EvolucaoAba,
  AnamneseAba,
  DocumentosAba,
  ProtocolosAba,
  FinanceiroAba,
  CadastroAba,
} from "./lazy-panels";
import ClienteCracha from "./panels/ClienteCracha";
import AcompanhamentoDiarioPanel from "./panels/AcompanhamentoDiarioPanel";

// ── Constantes visuais ────────────────────────────────────────────────────────
const CREAM = "hsl(40 33% 96%)";

// ── Componente principal ─────────────────────────────────────────────────────

export default function CockpitCliente() {
  const { toast } = useToast();

  // Estado do store
  const clienteId = useCockpitStore((s) => s.clienteId);
  const aba = useCockpitStore((s) => s.aba);
  const setClienteId = useCockpitStore((s) => s.setClienteId);
  const setAba = useCockpitStore((s) => s.setAba);

  // ── Dados ─────────────────────────────────────────────────────────────────
  const { data: clients } = useListClients();
  const opcoes = useMemo(
    () => (clients ?? []).map((c) => ({ id: c.id, name: c.name, cpf: c.cpf })),
    [clients],
  );

  const { data: client } = useGetClient(clienteId ?? 0, {
    query: { enabled: !!clienteId },
  });

  // Red flag (para LED no header)
  const { data: cockpitData } = useQuery<{ presente?: { redFlag?: boolean } }>({
    queryKey: ["cracha-cockpit", clienteId],
    queryFn: async () => {
      if (!clienteId) return { presente: { redFlag: false } };
      const r = await fetch(`${BASE}/api/cockpit/${clienteId}`);
      if (!r.ok) throw new Error("Falha ao carregar consulta");
      return r.json();
    },
    enabled: !!clienteId,
  });
  const hasRedFlag = Boolean(cockpitData?.presente?.redFlag);

  // ── Drive setup ───────────────────────────────────────────────────────────
  const handleDriveSetup = async () => {
    if (!clienteId) return;
    const apiBase = import.meta.env.VITE_API_URL || "/api";
    try {
      const res = await fetch(`${apiBase}/google-drive/setup-client/${clienteId}`, { method: "POST" });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      toast({ title: "Google Drive", description: data.message || "Pastas criadas com sucesso!" });
    } catch (err: any) {
      toast({ title: "Erro", description: err.message, variant: "destructive" });
    }
  };

  // ── Limpa seleção se o cliente saiu do banco ──────────────────────────────
  useEffect(() => {
    if (clienteId != null && clients && !clients.some((c) => c.id === clienteId)) {
      setClienteId(null);
    }
  }, [clients, clienteId, setClienteId]);

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen w-full font-sans" style={{ background: CREAM }}>

      {/* ── BLOCO STICKY: header + régua de abas ── */}
      <div className="sticky top-0 z-50 shadow-lg">
        <CockpitHeader
          opcoes={opcoes}
          client={client}
          onDriveSetup={handleDriveSetup}
          drivePending={false}
          hasRedFlag={hasRedFlag}
        />
        <CockpitTabRail
          aba={aba}
          onAbaChange={setAba}
          alertAba={hasRedFlag ? "protocolos" : null}
          disabled={clienteId == null}
        />
      </div>
      {/* ── FIM STICKY ── */}

      {/* ── Conteúdo claro ── */}
      <main className="px-4 py-6">
        {clienteId == null ? (
          <div className="panel-3d mx-auto mt-10 max-w-xl p-8 text-center">
            <UserRound className="mx-auto mb-3 h-8 w-8" style={{ color: "#9a7b32" }} />
            <div className="text-[15px] font-bold uppercase tracking-[0.12em]" style={{ color: "#16294a" }}>
              Selecione o cliente
            </div>
            <p className="mt-2 text-sm text-[#647c97]">
              Escolha o cliente na faixa superior. Todas as ferramentas da consulta — prescrição,
              injetáveis, implantes, exames, evolução, anamnese, protocolos, financeiro e cadastro
              — ficam nesta tela sem trocar de página.
            </p>
          </div>
        ) : (
          <div key={clienteId} className="space-y-4">
            {/* Crachá clínico + acompanhamento diário */}
            <ClienteCracha clientId={clienteId} />
            <AcompanhamentoDiarioPanel clientId={clienteId} />

            {/* ── Abas ── */}
            {aba === "prescricao" && <PrescricaoAba clientId={clienteId} />}
            {aba === "injetaveis" && <InjetaveisAba clientId={clienteId} />}
            {aba === "implantes" && <ImplantesAba clientId={clienteId} />}
            {aba === "exames" && <ExamesAba clientId={clienteId} />}
            {aba === "evolucao" && <EvolucaoAba clientId={clienteId} />}
            {aba === "anamnese" && <AnamneseAba clientId={clienteId} />}
            {aba === "documentos" && <DocumentosAba clientId={clienteId} />}
            {aba === "protocolos" && <ProtocolosAba clientId={clienteId} />}
            {aba === "financeiro" && <FinanceiroAba clientId={clienteId} />}
            {aba === "cadastro" && <CadastroAba clientId={clienteId} />}
          </div>
        )}
      </main>
    </div>
  );
}
