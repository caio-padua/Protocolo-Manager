/**
 * Lazy-loaded panel wrappers (Onda Fusão 2.0, 23/07/2026)
 *
 * Cada aba pesada (Protocolos, Financeiro, Cadastro) é carregada via React.lazy.
 * As abas leves (Prescrição, Injetáveis, Implantes, Exames, Evolução, Anamnese,
 * Documentos) já são componentes próprios e podem ser montados diretamente.
 *
 * Regra: React.lazy + Suspense com fallback consistente (Skeleton panel-3d).
 */
import { lazy, Suspense } from "react";
import { Skeleton } from "@/components/ui/skeleton";

// ─── Painéis leves (já importados no original) ──────────────────────────────

import PrescricaoPage from "@/pages/prescricao";
import NovoProtocolo from "@/pages/protocols/new";
import Injetaveis from "@/pages/cockpit/panels/Injetaveis";
import ExamesPage from "@/pages/exames";
import EvolucaoExamesPanel from "@/pages/cockpit/panels/EvolucaoExamesPanel";
import DocumentosPanel from "./panels/DocumentosPanel";
import AvisoSemAnamnese from "./panels/AvisoSemAnamnese";
import AnamnesePreviaPanel from "./panels/AnamnesePreviaPanel";
import ExamesEnviadosPanel from "./panels/ExamesEnviadosPanel";
import ContratosTimelineInline from "./panels/ContratosTimelineInline";

// ─── FallbackSkeleton ────────────────────────────────────────────────────────

function FallbackSkeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-4">
      {[...Array(rows)].map((_, i) => (
        <Skeleton key={i} className="h-32 rounded-lg panel-3d-sub border-none" />
      ))}
    </div>
  );
}

// ─── Painéis lazy-loaded ─────────────────────────────────────────────────────
//
// Protocolos, Financeiro e Cadastro eram INLINE no monólito de 966 linhas.
// Agora são extraídos para seus próprios componentes e lazy-loaded.

const ProtocolosPanelLazy = lazy(() => import("./panels/ProtocolosPanel").then(m => ({ default: m.default })));
const FinanceiroPanelLazy = lazy(() => import("./panels/FinanceiroPanel").then(m => ({ default: m.default })));
const CadastroPanelLazy = lazy(() => import("./panels/CadastroPanel").then(m => ({ default: m.default })));

// ─── Abas originais (montagem direta) ────────────────────────────────────────

export function PrescricaoAba({ clientId }: { clientId: number }) {
  return <PrescricaoPage clientId={clientId} embedded />;
}

export function InjetaveisAba({ clientId }: { clientId: number }) {
  return (
    <div className="space-y-6">
      <NovoProtocolo clientId={clientId} embedded />
      <Injetaveis clientId={clientId} filtroProcedimento="injetavel" ocultarBotaoNovo />
    </div>
  );
}

export function ImplantesAba({ clientId }: { clientId: number }) {
  return (
    <div className="space-y-6">
      <NovoProtocolo clientId={clientId} embedded />
      <Injetaveis clientId={clientId} filtroProcedimento="implante" ocultarBotaoNovo />
    </div>
  );
}

export function ExamesAba({ clientId }: { clientId: number }) {
  return (
    <div className="space-y-4">
      <AvisoSemAnamnese clientId={clientId} />
      <ExamesPage clientId={clientId} embedded />
      <ExamesEnviadosPanel clientId={clientId} />
    </div>
  );
}

export function EvolucaoAba({ clientId }: { clientId: number }) {
  return <EvolucaoExamesPanel clientId={clientId} />;
}

export function AnamneseAba({ clientId }: { clientId: number }) {
  return <AnamnesePreviaPanel clientId={clientId} />;
}

export function DocumentosAba({ clientId }: { clientId: number }) {
  return (
    <div className="space-y-6">
      <DocumentosPanel clientId={clientId} />
      <ContratosTimelineInline clientId={clientId} />
    </div>
  );
}

// ─── Abas lazy-loaded ────────────────────────────────────────────────────────

export function ProtocolosAba({ clientId }: { clientId: number }) {
  return (
    <Suspense fallback={<FallbackSkeleton rows={3} />}>
      <ProtocolosPanelLazy clientId={clientId} />
    </Suspense>
  );
}

export function FinanceiroAba({ clientId }: { clientId: number }) {
  return (
    <Suspense fallback={<FallbackSkeleton rows={4} />}>
      <FinanceiroPanelLazy clientId={clientId} />
    </Suspense>
  );
}

export function CadastroAba({ clientId }: { clientId: number }) {
  return (
    <Suspense fallback={<FallbackSkeleton rows={3} />}>
      <CadastroPanelLazy clientId={clientId} />
    </Suspense>
  );
}
