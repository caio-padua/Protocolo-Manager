---
title: "Toda tarefa vive na planilha com número único"
date: 2026-08-12
status: accepted
tags: [governança, coordenação]
systems: [PADCOM]
validado_em: [Protocolo-Manager, Slack #padaxor-projeto]
---

## O que decidimos

Toda tarefa tem um número único na planilha Google Sheets. Nenhuma numeração paralela (task interna de agente, ticket de outra ferramenta) substitui esse número.

## Por quê

**Armadilha que gerou o problema:** cada agente criou numeração própria (Task #124, Task #144, Task #175). Resultado: Dr. Manus e Dr. Code trabalharam às cegas — não sabiam que um item novo existia, e a planilha parou no #73 enquanto agentes operavam itens "invisíveis" #144-#167.

## O que vigora

Antes de codar: registrar na planilha. Depois de codar: atualizar status com hash de commit. Se o agente usa numeração interna, mapear para o número da planilha.

## O que vai apodrecer

Nunca. É a fundação da coordenação multi-agente.
