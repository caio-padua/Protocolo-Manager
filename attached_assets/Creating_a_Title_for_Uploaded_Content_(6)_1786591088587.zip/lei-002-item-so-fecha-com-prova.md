---
title: "Item só fecha com hash de commit + teste verde"
date: 2026-08-12
status: accepted
tags: [governança, qualidade]
systems: [PADCOM]
validado_em: [Protocolo-Manager, bateria #81-A]
---

## O que decidimos

Nenhum item da planilha fecha como CONCLUÍDO sem: (1) hash de commit visível no GitHub, e (2) pelo menos um caso de teste automatizado que passou.

## Por quê

**Armadilha que gerou o problema:** item #75 foi marcado CONCLUÍDO duas vezes. Primeira: commit existia mas teste não. Segunda: commit existia, teste passava (23/23), mas um defeito real estava vivo porque a bateria não cobria o cenário. O código "verde" enganou o árbitro.

## O que vigora

Antes de marcar CONCLUÍDO: hash no Slack + bateria verde + verificação independente por outro agente. Análise/proposta não é conclusão — é AGUARDANDO.

## O que vai apodrecer

Nunca.
