# Modelo V2 — Dossiê Clínico por Substância

**Status:** especificação visual para o item #88  
**Princípio:** uma substância ocupa **no mínimo meia página A4 útil**, sem sacrificar conteúdo; a continuação conserva o mesmo cabeçalho quando textos clínicos excederem o espaço.

## Regra de paginação

| Cenário | Organização do documento |
|---|---|
| 1–2 substâncias | Capa + mapa geral + 1 folha com duas fichas (meia página por ficha) + cronograma |
| 3–6 substâncias | Capa + mapa geral + 2–3 folhas de fichas emparelhadas + cronograma |
| 7+ substâncias | Mesmo módulo repetível; pares de fichas seguem o fluxo e não comprimem a tipografia |
| Texto muito extenso | A ficha abre uma página de continuação com título, referência e bloco narrativo restante |

## Anatomia da ficha (metade A4)

```text
┌─ 01 / Dossiê de substância ───────────────────────────────────────────────┐
│ [cor] NOME DA SUBSTÂNCIA                 Categoria · Via · Avaliação      │
│       Função no seu protocolo (mainFunction)                               │
├─ Administração ─────────────┬─ Mapa de atuação ────────────────────────────┤
│ dose prescrita               │ radar 0–5: bodySystemEffects                │
│ sessões / intervalo / início │ colunas verticais: todos os eixos preenchidos│
│ via / duração / efeito       │ medidores de resultado: categoryMeters        │
├─ Composição e contexto ──────┼─ Benefícios por área ────────────────────────┤
│ descrição + composição       │ grade de textos existentes e preenchidos      │
│ concentração / volume        │ (energia, sono, mente, imunidade etc.)        │
├─ O que pode ser percebido ───┴─ Segurança e evidência ──────────────────────┤
│ perceivedEffects                    contraindications · scientificEvidence  │
└────────────────────────────────────────────────────────────────────────────┘
```

## Elementos e data bindings

| Área visível ao paciente | Dados reais | Regra de apresentação |
|---|---|---|
| Tarja de identidade | `name`, `color`, `category`, `categoryType`, `subCategoria`, `procedureType`, `starRating` | Título em serif; valores técnicos em sans; cor apenas como fio de 3 mm |
| Administração | `protocol_items.dose`, `totalSessions`, `completedSessions`, `intervalDays`, `startDate`, `frequency`, `defaultDose`, `posologia`, `posologiaEstruturada`, `concentrationMg`, `volumeAmpola`, `durationMinutes`, `frequenciaBase`, `maxSessionsPerWeek`, `timeToEffect` | Prioridade para a prescrição do protocolo; campos do catálogo complementam, nunca substituem a prescrição |
| Composição | `composicao` | Parser existente divide por vírgula/ponto e vírgula em ativo + dose; sem preencher o que não veio do cadastro |
| Mapa de atuação | `bodySystemEffects` | Radar com os eixos preenchidos; colunas verticais 0–5 mantêm a leitura imediata e preservam todos os valores não nulos |
| Medidores de resultado | `categoryMeters` | Radar menor e colunas verticais para os quatro medidores oficiais: Emagrecimento, Hipertrofia, Recuperação Muscular e Neurocognição |
| Valor clínico | `description`, `mainFunction`, `perceivedEffects` | Blocos curtos, com subtítulos fixos para leitura por varredura visual |
| Benefícios detalhados | 10 campos de benefício existentes | Grade de tópicos; apenas células preenchidas; não reduzir texto a indicador binário |
| Segurança | `contraindications`, `scientificEvidence`, `exigeValidacaoHumana` | Caixa de baixo contraste; a validação humana é tratada como controle interno no motor, não como alarme ao paciente |

## Gráficos: regras de honestidade

> Os gráficos são um **mapa de cadastro clínico**, não uma promessa de resultado individual.

1. As escalas `0–5` são lidas diretamente dos JSONs existentes; não há cálculo novo, IA, média ou recomendação automática.
2. O radar apenas desenha valores preenchidos em `bodySystemEffects`; eixos ausentes não recebem valor zero ocultamente.
3. As colunas verticais exibem todos os sistemas com valor maior que zero, em ordem decrescente. Se excederem oito, o bloco continua em coluna adjacente ou em continuação — nunca vira microtexto.
4. Os medidores `categoryMeters` têm legenda fixa, em tom clínico-neutro, e aparecem somente se houver pontuação.
5. Em impressão monocromática, as diferenças de altura, hachura e rótulo numérico preservam o significado sem depender de cor.

## O que exige somente ampliação de fiação

Não há banco novo. O executor precisa incluir no `ProtocolDocSubstance` e no objeto montado em `GET /protocols/:id/document-pdf` os campos já existentes abaixo:

`category`, `subCategoria`, `composicao`, `posologia`, `posologiaEstruturada`, `defaultDose`, `concentrationMg`, `volumeAmpola`, `durationMinutes`, `frequenciaBase`, `maxSessionsPerWeek`, `categoryMeters`, `tags`, `areaSemantica`, `grau`, `viaUso`, `completedSessions`, `frequency` e `exigeValidacaoHumana`.

Itens como estoque, disponibilidade, notas internas, IDs e custo unitário ficam fora do dossiê de encantamento por serem operacionais ou comerciais.
