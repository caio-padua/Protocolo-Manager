---
title: "ON CONFLICT (Upsert)"
tipo: dicionario
tags: [banco-de-dados, SQL]
---

## Definição

"Se a chave já existe, não insira de novo — ou atualize o existente." É o mecanismo SQL que torna operações idempotentes.

## Quando aparece

Junto com PRIMARY KEY. Quando precisa "insira se não existir, ignore se existir."

## Pergunta que você pode fazer

"O INSERT tem ON CONFLICT? O que acontece quando conflita: ignora ou atualiza?"

## Exemplo real no PADAXOR

```sql
INSERT INTO concierge_webhook_eventos (event_id, ...)
VALUES ('shared:123:abc:expirado', ...)
ON CONFLICT (event_id) DO NOTHING
```
Se o evento já foi processado → ignora. Se é novo → insere. Atômico, sem corrida.
