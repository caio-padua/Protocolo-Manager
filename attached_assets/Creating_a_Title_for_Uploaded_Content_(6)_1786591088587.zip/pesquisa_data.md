# Pesquisa Consolidada - Ferramentas Modernas para Cockpit Unificado (Julho 2026)

## 1. STATE MANAGEMENT

### Zustand
- 26K+ estrelas GitHub, ~7M downloads/semana npm
- API mais simples, bundle minúsculo (~1KB gzipped)
- Ideal para: estado de UI, estado compartilhado entre componentes
- Padrão 2026: Zustand + TanStack Query (server state)
- Recursos: persist middleware, shallow selectors (useShallow), devtools

### Jotai
- Criado pela mesma equipe do Zustand (pmndrs)
- Modelo atômico: estado dividido em "átomos" independentes
- Ideal para: estado derivado complexo, formulários, planilhas
- Inferência automática de tipo

### TanStack Query (React Query)
- Estado de servidor: fetching, caching, sync, retries
- ~7.2M downloads/semana npm
- Padrão 2026: TanStack Query para dados do servidor + Zustand para estado de cliente

### TanStack Store
- Nova entrada (2025-2026)
- Store framework-agnostic (funciona com React, Vue, Solid, Svelte)
- Baseado em signals/observables

### Redux Toolkit
- Ainda relevante para apps enterprise com estado complexo
- Bundle 7x maior que Zustand
- RTK Query para server state

## 2. ANIMAÇÕES

### Motion (ex-Framer Motion) v12
- Mais popular para React: 2.2M downloads/semana, 19.6K estrelas
- API declarativa: motion.div, AnimatePresence, layoutId
- Gestures, scroll hooks, exit animations
- ~30KB gzipped (bundle mais pesado da lista)
- LazyMotion para tree-shaking
- Melhores features: layout animations, shared layout (layoutId), gestures
- Padrão 2026: Motion para UI animations + CSS/Tailwind para simples

### React Spring
- Física de springs para animações naturais
- Hooks: useSpring, useTrail, useTransition
- 762K downloads/semana, 26.1K estrelas
- Curva de aprendizado mais íngreme

### GSAP (GreenSock)
- Powerhouse para timelines complexas, scroll-driven narratives, SVG morphing
- ScrollSmoother (alternativa ao Lenis)
- Licença paga para alguns plugins comerciais

### Lenis
- Smooth scroll library, ~3KB gzipped
- Normaliza input, mantém APIs nativas
- Sem transforms (usa scrollTo)
- Integração perfeita com GSAP e Motion
- Padrão 2026: Lenis para smooth scroll em telas premium

### Tailwind CSS + animate
- Animate-spin, animate-pulse, animate-bounce
- Custom keyframes via tailwind.config
- CSS linear() easing nativo (2026) para spring physics sem JS

## 3. COMPONENTES HEADLESS

### shadcn/ui (v4)
- 113.6K estrelas GitHub (maior de todas)
- CLI copia código-fonte no seu repo (você é dono)
- Base UI como primitivo (desde 2025), Radix como padrão
- 50+ componentes configuráveis
- Padrão 2026: shadcn/ui é a forma mais comum de consumir primitivos

### Base UI (MUI)
- Mais ativamente mantido que Radix em 2026
- ~9.5K estrelas, ~3.7M downloads/semana
- Aceita className diretamente nos parts (sem asChild)
- Ideal para greenfield

### Radix UI
- Pioneiro dos headless primitives
- ~18.8K estrelas, ~4.4M downloads/semana
- Adquirido pela WorkOS, velocidade de updates diminuiu
- asChild prop para composition
- 30+ componentes

### React Aria (Adobe)
- Mais rigoroso em acessibilidade (WAI-ARIA)
- Modelo hooks-first: useButton, useDialog, useTabs
- 4.47M downloads/semana
- Ideal para government/enterprise com WAI-ARIA obrigatório
- Mais verboso que Radix/Base UI

### Ark UI (Chakra)
- Cross-framework: React, Vue, Solid
- State machines (XState) para comportamento previsível
- ~5.2K estrelas, ~634.7K downloads/semana
- Ideal para multi-framework design systems

### Headless UI (Tailwind Labs)
- ~10 componentes, API mais amigável
- ~28.6K estrelas, ~5.49M downloads/semana
- Limitado para casos complexos

### Embla Carousel
- Lightweight, fluid motion, swipe precision
- dragFree option para scroll contínuo (similar a nativo)
- SSR-friendly
- Ideal para carousels/carrosséis, NÃO para tabs scrollable
