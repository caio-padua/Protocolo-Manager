# Pesquisa Tecnológica Consolidada — Julho 2026

## 1. GERENCIAMENTO DE ESTADO

### Zustand (recomendação principal para UI state)
- 57.1k estrelas, 72.9M downloads/mês (fev 2026)
- Bundle: ~1.2KB gzipped
- Zero boilerplate, API baseada em hooks
- Perfeito para: estado de UI do cockpit (aba ativa, clienteId, formulários)
- 50% dos devs React usam (State of React 2025)
- Menos de 5 issues abertas — código extremamente estável

### Jotai (alternativa atômica)
- 21.0k estrelas, 9-10M downloads/mês
- Bundle: ~2.5KB gzipped
- Abordagem atômica: cada valor = um "atom" independente
- Re-renders ultra-finos (só o componente que depende do atom)
- Ideal para: estado derivado (KPIs calculados a partir de pagamentos)

### TanStack Query v5 (server state — JÁ em uso no PAXTER)
- A biblioteca padrão para server state em 2026
- Caching, refetching, mutations, optimistic updates
- Já integrado no cockpit-cliente atual

## 2. COMPONENTES HEADLESS / PRIMITIVOS

### shadcn/ui (camada atual do PAXTER)
- 113.6k estrelas — maior de todas as libs
- Copia código para seu repo (você é dono do código)
- Já usa Radix UI por baixo dos panos
- Suporta Base UI como alternativa desde 2025
- Em fev 2026: unificou pacote radix-ui

### Base UI (MUI Team)
- v1.0 estável lançado em 2026
- 9.5k estrelas, 3.7M downloads/mês
- Mais ativamente mantido que Radix
- Primitivos de ultra-baixo nível, máximo controle DOM
- API: Dialog.Root > Dialog.Popup (não Dialog.Content)
- Recomendado para: novas implementações onde Radix tem lacunas

### Radix UI (atual do PAXTER)
- 18.8k estrelas, 4.4M downloads/mês
- Aquisição pela WorkOS desacelerou updates
- Ainda funciona perfeitamente com shadcn/ui
- Tabs: Tabs.List + Tabs.Content (vertical/horizontal)

### Ark UI (multi-framework)
- React + Vue + Solid (mesmo componente)
- 35+ componentes, state machines (XState)
- Melhor para: se o PAXTER expandir para Vue/Solid

### Headless UI (Tailwind Labs)
- ~10 componentes, API mais simples
- Oficial Tailwind, mas componente set limitado

## 3. ANIMAÇÕES E MICRO-INTERAÇÕES

### Motion (ex-Framer Motion) — RECOMENDAÇÃO PRINCIPAL
- 30.7k estrelas, 3.6M downloads/mês
- Renomeado de "Framer Motion" para "Motion" em 2025
- Import: `import { motion } from "motion/react"`
- Funcionalidades: whileHover, whileTap, whileInView, whileDrag
- AnimatePresence: animações de saída (exit)
- Keyframes: arrays de valores animados
- CSS variables animáveis
- Scroll-triggered animations
- Gesture support completo
- LazyMotion para reduzir bundle

### GSAP (GreenSock)
- Para animações complexas/imperativas
- ScrollTrigger para parallax/scroll-based
- Mais power, mais curva de aprendizado
- Ideal para: efeitos de entrada sofisticados no cockpit

### Lenis (smooth scroll)
- Biblioteca de smooth scroll leve e performática
- Wrap do scroll nativo do browser
- Compatível com position: sticky (CRUCIAL para o cockpit!)
- GitHub: darkroomengineering/lenis

## 4. SCROLL E CAROUSEL

### Embla Carousel — RECOMENDAÇÃO para barra de abas
- ~7KB gzipped, dependency-free
- Mobile-first, acessível
- Melhor carousel/carrossel em 2026
- API: plugin system (autoScroll, wheelGestures, fade)
- Ideal para: barra de abas com scroll horizontal suave + indicadores fade

### TanStack Virtual
- Virtualização de listas longas
- Ideal para: listas de pagamentos, sessões, exames quando muito extensas

## 5. NOVAS APIS E PADRÕES REACT 2026

### React 19 Hooks
- useOptimistic: updates otimistas antes da confirmação do servidor
- useActionState: gerenciamento de estado de formulários async
- useFormStatus: status de submissão de formulários
- Server Components: componentes renderizados no servidor (RSC)

### CSS View Transitions API
- Transições nativas do browser entre views
- Hardware-accelerated, zero-overhead
- Suportado em Chromium + Safari 18.2+ (julho 2026)
- Firefox em progresso
- Ideal para: transições suaves entre abas do cockpit

### Tailwind CSS v4
- Engine Oxide (Rust-based, 100x mais rápido)
- Novo sistema de CSS-first configuration
- CSS nesting nativo
- Container queries built-in
- Cascade layers

## 6. PERFORMANCE

### React.lazy + Suspense (padrão 2026)
- Code splitting por aba
- Cada aba carrega sob demanda
- Skeleton placeholders durante carregamento

### TanStack Query caching
- Data caching inteligente
- Background refetching
- Stale-while-revalidate

### Virtualização (TanStack Virtual)
- Para listas >100 itens
- Renderiza apenas itens visíveis na viewport

## RESUMO DO ARSENAL RECOMENDADO PARA O COCKPIT:

| Camada | Biblioteca | Por que |
|--------|-----------|---------|
| Primitivos UI | shadcn/ui + Radix/Base UI | Já em uso, copy-paste ownership |
| Estado UI | Zustand | 1.2KB, zero boilerplate, perfeito para cockpit state |
| Server State | TanStack Query v5 | Já em uso, caching perfeito |
| Animações | Motion (ex-Framer Motion) | whileHover, AnimatePresence, scroll-triggered |
| Scroll suave | Lenis | Compatível com sticky, leve |
| Abas scrolláveis | Embla Carousel | 7KB, mobile-first, indicadores fade |
| Virtualização | TanStack Virtual | Para listas longas (pagamentos, exames) |
| View Transitions | CSS View Transitions API | Transições nativas entre abas |
| Tailwind | v4 | Engine Oxide, 100x mais rápido |
| React | 19 | useOptimistic, useActionState, RSC |
