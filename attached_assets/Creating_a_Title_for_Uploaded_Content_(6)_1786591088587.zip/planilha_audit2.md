# Auditoria Planilha - Tela 2

Rolando para baixo, a planilha mostra que:
- Linha 1: headers (Nº, DATA, HORA, Item, Responsável, Est, Prioridade, Depende de)
- Linhas 2-18: itens 1-17 (já mapeados)
- Linhas 28+: vazias (celulas com números de linha 28-43 visíveis mas sem conteúdo)
- A planilha parece terminar no item 17 na seção visível

NÃO consigo ver itens 43 ou 60-63. Preciso navegar usando a caixa de nome ou encontrar os itens de outra forma.
