# Auditoria Planilha - Navegação

A planilha tem colunas que vão de A até AX (ou além). A coluna N contém o Nº do item.
As linhas visíveis agora mostram: linha 43 (célula N43 visível), linha 44, linha 45.
A planilha parece ter os itens em linhas 1-44 (linha 1 = header, linhas 2-44 = itens 1-43?).

Preciso verificar: a coluna N é o Nº do item? Ou é a coluna A?
Na primeira tela, a coluna A tinha os números 1, 2, 3... 17.
Agora vejo que a coluna N tem cabeçalho "Nº" - então os números de item estão na coluna N.

Preciso navegar para a coluna N e descer para encontrar o item 43.
