# Planilha PADAXOR — LINHA DE PRODUCAO (completa)

## Abas visíveis
1. PLANILHA PRODUCAO
2. DICIONARIO

## Colunas
- A: Nº
- B: Item
- C: Responsável
- D: Estado
- E: Prioridade
- F: Depende de
- G: Em linguagem de leigo

## Itens visíveis (1-17):
| Nº | Item | Responsável | Estado | Prioridade | Depende |
|---|---|---|---|---|---|
| 1 | Banco em producao com dados reais | Dr. Replit | CONCLUIDO | P0 crítico | — |
| 2 | Backup do Postgres | Dr. Caio | CONCLUIDO | P0 crítico | — |
| 3 | api-server no ar com domínio e CORS | Dr. Code | CONCLUIDO | P0 crítico | — |
| 4 | Login do CEO funcionando | Dr. Code | CONCLUIDO | P0 crítico | 3 |
| 5 | Token de colaborador vale no perimetro | Dr. Code | CONCLUIDO | P0 crítico | 4 |
| 6 | Site publicado com as 6 correcoes | Dr. Lovable | CONCLUIDO | P1 alto | — |
| 7 | Captacao de interessados empresajd na tabela profissionais | Dr. Replit | CONCLUIDO | P1 alto | 3 |
| 8 | Isolamento entre clinicas no banco (RLS) | Dr. Code | A FAZER | P0 crítico | — |
| 9 | Marca distinta nos dois esquemas de senha | Dr. Code | CONCLUIDO | P0 crítico | — |
| 10 | Marca distinta nos dois esquemas de senha | Dr. Code | CONCLUIDO | P0 crítico | — |
| 11 | Tela de login dentro do padaxor | Dr. Replit | CONCLUIDO | P1 alto | 5 |
| 12 | Site vira botao, nao segundo login | Dr. Lovable | A FAZER | P1 alto | 11 |
| 13 | DNS do padaxor.com.br no Cloudflare | Dr. Caio | A FAZER | P1 alto | — |
| 14 | Dominio proprio apontando para o sistema | Dr. Code | AGUARDANDO | P1 alto | 13 |
| 15 | Marca PAXTER para PADAXOR no painel | Dr. Replit | CONCLUIDO | P1 alto | — |
| 16 | Porta da area do paciente | Dr. Lovable | A FAZER | P1 alto | — |
| 17 | Indice unico em lower(login, username) | Dr. Code | A FAZER | P1 alto | 8 |

Nota: Preciso scrollar para ver itens 18-56+
