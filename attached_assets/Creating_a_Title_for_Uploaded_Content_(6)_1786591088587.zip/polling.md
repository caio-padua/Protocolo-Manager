---
title: "Polling"
tipo: dicionario
tags: [integração, backend]
---

## Definição

Seu sistema pergunta periodicamente a outro sistema "mudou algo?" — em vez de esperar ser avisado (webhook).

## Quando aparece

Quando o webhook falha ou não chega. Polling é o plano B.

## Pergunta que você pode fazer

"O polling e o webhook podem registrar o mesmo evento? Como vocês evitam dupla contagem?"

## Exemplo real no PADAXOR

O PADAXOR faz polling no Asaas para verificar se uma cobrança mudou de status. Se o webhook não chegou, o polling detecta e registra a penalidade. Risco: se webhook E polling rodarem, mesma cobrança = 2 penalidades.
