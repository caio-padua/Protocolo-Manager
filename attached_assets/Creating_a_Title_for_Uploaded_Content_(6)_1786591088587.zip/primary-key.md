---
title: "PRIMARY KEY (Chave Primária)"
tipo: dicionario
tags: [banco-de-dados]
---

## Definição

Coluna (ou conjunto de colunas) que identifica cada linha de forma única. O banco não permite dois registros com a mesma chave.

## Quando aparece

Em toda tabela. É a garantia de que não existe duplicata.

## Pergunta que você pode fazer

"Qual é a PRIMARY KEY dessa tabela? Ela é suficiente para garantir que o mesmo fato não seja registrado duas vezes?"

## Exemplo real no PADAXOR

Tabela `concierge_webhook_eventos` tem `event_id` como PK. Se dois processos tentarem inserir o mesmo `shared:{pedido}:{cobranca}:{desfecho}`, o segundo falha silenciosamente (ON CONFLICT DO NOTHING) — exatamente o comportamento desejado.
