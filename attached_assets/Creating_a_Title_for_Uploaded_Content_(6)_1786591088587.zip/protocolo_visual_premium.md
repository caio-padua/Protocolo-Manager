# Protocolo Visual Premium — Apresentação de Protocolos & Substâncias ao Paciente

Data: 12/08/2026 · Dr. Manus · Autorizado pelo CEO
Objetivo: transformar a apresentação do protocolo ao paciente (tela /area → tab PROTOCOLOS) de "painel de dados" para "carta de tratamento premium", usando 100% a fiação existente.

## 1. Referência de mercado estudada

- Menus IV Therapy de med-spas de elite: tipografia serifada espaçada, ingredientes em lista editorial, preço discreto, muito respiro vertical.
- Dashboards médicos dark premium: cartões escuros navy com acentos dourados, anéis de progresso, KPIs grandes e isolados (número grande + rótulo pequeno).
- Padrão convergente: menos caixas/bordas, mais respiro; hierarquia emocional (o que o paciente sente primeiro) antes do detalhe técnico.

## 2. Direção: "Carta de Tratamento" (não painel administrativo)

O paciente não recebe um card de dados — recebe uma CARTA de tratamento personalizada do Instituto Pádua. Design system do paciente (area.tsx) já tem: Lora (.leva-q), Paxter 3D, navy/dourado. O redesenho mantém isso e troca a gramática: de "campos concave" para "documento editorial".

### Estrutura do novo ProtocolCard (payload de HOJE, sem mudar backend)

| Bloco | Conteúdo | Campos usados (payload atual) |
|---|---|---|
| Hero da carta | Título serifado grande + sublinha dourada; selo de status (Ativo/Concluído) como etiqueta dourada discreta | title, status |
| Linha de contexto | Data de início, local, tipo de atendimento em 1 linha fina | startDate, unit, serviceType |
| Anel de progresso | Ring SVG dourado com pct central + "X/Y sessões" — no lugar da barra segmentada | totalSessions, completedSessions |
| Seção "Seu protocolo contém" | Cada substância = 1 item editorial: cor (ponto dourado), nome, tipo (IM/IV/Implante), dose, intervalo, sessões próprias | items[]: substanceName, color, procedureType, dose, intervalDays, totalSessions, completedSessions |
| Função principal | Citação editorial em itálico Lora para cada substância (o que o paciente vai sentir) | items[].mainFunction |

## 3. O salto maior: enriquecer SEM novos campos (fase 2, backend mínimo)

Hoje o backend manda só 6 campos da substância. A tabela `substances` TEM descrição, efeitos percebidos, tempo p/ resultado, sistemas corporais, medidores, benefícios. O ganho premium máximo = backend devolver esses campos já existentes (1 linha no select). Plano:

| Fase | Escopo | Benefício |
|---|---|---|
| Fase A (frontend puro) | Redesenho do card com payload atual | Carta de tratamento visual premium |
| Fase B (1 linha backend) | GET /area-paciente/protocolos inclui da `substances`: description, perceivedEffects, timeToEffect, starRating, bodySystemEffects, categoryMeters, benefits (10 campos), contraindications, composicao | Detalhe da substância: o que é, o que sinto, quando sinto, prova social (estrelas), sistemas impactados (barras), medidores (ouro), contraindicações (segurança) |

Na Fase B, cada substância ganha um "drawer de dossier":
- Dossier (expansível por substância): descrição → "O que você vai sentir" (perceivedEffects) → "Quando você percebe" (timeToEffect) → Estrelas (starRating) → Impacto nos sistemas (bodySystemEffects como barras douradas) → Medidores de Resultado (categoryMeters no card ouro "Resultados que você vai sentir") → Contraindicações (aviso sóbrio, sem alarme) → Blend (composicao)

## 4. Regras TDAH-friendly mantidas
- Um protocolo = uma carta; nunca mais de 2 níveis de expansão.
- KPIs grandes (sessões, %), leitura < 30s do essencial.
- Contraindicações sempre visíveis no dossier (transparência premium).

## 5. Não fazemos (linhas vermelhas)
- Não criar tabela nova, não alterar contrato do protocolo.
- Não mudar fonte/dark do restante da área do paciente.
- Não usar campos que não existem na tabela substances.
