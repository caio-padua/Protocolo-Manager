---
title: "Race Condition (Condição de Corrida)"
tipo: dicionario
tags: [concorrência, backend]
---

## Definição

Dois processos tentam fazer a mesma coisa ao mesmo tempo e o resultado depende de quem chegou primeiro — de forma imprevisível.

## Quando aparece

Webhook + polling processando o mesmo evento. Dois usuários clicando ao mesmo tempo. Fila de mensagens.

## Pergunta que você pode fazer

"Se o webhook e o polling rodarem ao mesmo tempo, o que acontece?"

## Exemplo real no PADAXOR

Polling usa eventId `poll:{id}:{chargeId}:{status}` e webhook usa `event.id` do Asaas. São IDs diferentes para o mesmo fato → se ambos rodarem, paciente leva 2 penalidades por 1 abandono.
