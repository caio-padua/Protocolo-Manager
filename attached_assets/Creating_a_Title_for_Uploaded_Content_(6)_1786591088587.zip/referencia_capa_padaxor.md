# Referência de Capa — PADAXOR Clinical Intelligent System

## Ativo oficial selecionado

| Elemento | Fonte oficial no repositório | Uso na nova capa |
|---|---|---|
| Símbolo com vidro, ouro e brilho | `paxter-pack/skills/skill-layout-paxter/references/marca/03-loginho-vidro-sistema.png` | Peça central em grande escala, sobre fundo navy. É o símbolo legado visualmente reconhecido como o “X” do sistema. |
| Regra de marca | `paxter-pack/skills/skill-layout-paxter/references/marca/marca.md` | A peça 03 é a versão com vidro para fundo navy; não redesenhar o símbolo. |
| Fonte de strings | `artifacts/padcom/src/lib/brand.ts` | O produto é o sistema clínico; a empresa tecnológica é PADCON; a clínica é uma emissora variável. |

## Tradução para o documento multiclínica

O nome comercial que aparece na capa será **PADAXOR Clinical Intelligent System**. O símbolo dourado legado do ativo Paxter será preservado como continuidade visual do produto, sem afirmar que a clínica emissora é PADCON ou uma clínica específica. A clínica permanece em área própria na carta interna. PADCON aparece apenas como proveniência tecnológica secundária.

## Regra de escala e contraste

> A capa é um momento de assinatura institucional: fundo navy integral, símbolo com brilho quente em escala ampla, wordmark PADAXOR legível à distância e uma única linha explicativa. O brilho é reservado ao ativo oficial, não espalhado pelo documento.
