# Referências e restrições — revisão clássica do protocolo

**Fontes examinadas**  
`PROTOCOLOMODELO.pdf`; `prototype_protocolo_paciente(1).pdf`; `Apresentacao_Luxuosa_Substancias(1).pdf`; `arquitetura_novo_pdf.md`; `pasted_content_23.txt`; `origin/main:docs/briefing-manus-protocolo-pdf.md`; `artifacts/padcom/index.html`.

## Fiação e limite editorial

O gerador real do documento do paciente continua sendo `artifacts/api-server/src/lib/pdf-signer.ts`, alimentado por `ProtocolDocumentData` e `ProtocolDocSubstance`, com campos vindos de `protocols`, `clients`, `professionals`, `protocol_items`, `substances`, `sessions`, `substance_applications` e `payments`. O novo desenho não deve inventar desfechos, indicadores laboratoriais ou prioridades clínicas fora desses campos. O pedido do CEO é reorganizar a apresentação, não aumentar a ontologia de dados.

## Fontes tipográficas já carregadas pelo sistema

No `artifacts/padcom/index.html`, o sistema já carrega `Archivo`, `Inter`, `Cormorant Garamond`, `Playfair Display`, `EB Garamond`, `Lora`, `Marcellus` e `Michroma`. Para a revisão clássica/toscana, as famílias mais coerentes com o ecossistema existente são **Cormorant Garamond / EB Garamond / Playfair Display** para assinatura editorial e **Archivo** para dados tabulares e rótulos curtos. Isso evita introduzir uma família externa sem necessidade.

## O que cada anexo ensinou

| Fonte | Valor real para a nova versão | Excesso ou problema a evitar |
|---|---|---|
| `PROTOCOLOMODELO.pdf` | Mostra a fiação real do PDF em produção: capa, matriz, radar, fichas, calendário, financeiro. | Capa escura gasta tinta; radar/rótulos ainda dependem de leitura linear; estrelas e dots dependem de cor. |
| `prototype_protocolo_paciente(1).pdf` | Reforça a necessidade de explicar o documento e a jornada do paciente. | O radar continua radial; o mapa textual em caracteres não é elegante nem escaneável. |
| `Apresentacao_Luxuosa_Substancias(1).pdf` | Boa atmosfera clássica: marfim, navy, ouro seco, serifas, cabeçalhos institucionais, avisos destacados. | Páginas ainda muito corridas; alguns blocos dependem de leitura de parágrafo; luxo demais para impressão longa se repetido sem síntese. |
| `briefing-manus-protocolo-pdf.md` | Define com precisão a fiação, o arquivo mestre, os pontos de melhoria e o rebrand PADAXOR. | Ainda propõe radar como centro da leitura; o CEO agora prefere matriz por eixos com barras verticais. |
| `arquitetura_novo_pdf.md` | Traz boas regras de linguagem simples, confirmação de entendimento e separação entre camadas. | Parte do contrato de dados propõe campos novos; para esta rodada, usar apenas a fiação atual. |

## Requisitos do CEO para esta iteração

O documento precisa ser **sóbrio, elegante, clássico/toscano, TDAH-friendly sem excesso de cor, alinhado por grade invisível, não linear e orientado por tópicos**. O CEO prefere comparação por **eixos X/Y e barras verticais**, não por grandes manchas radiais. Como haverá impressão frequente, a informação deve sobreviver em escala de cinza, com contraste estrutural, linhas finas e padrões de preenchimento discretos.

## Decisão provisória de direção

O novo modelo será uma **carta clínica modular**, com capa marfim, assinatura institucional forte do **Instituto Pádua** e leitura por colunas. A página-resumo central trocará o radar por uma **matriz cartesiana**: no eixo horizontal, as dimensões do cuidado já deriváveis da fiação; no eixo vertical, uma escala curta e ordinal; em cada coluna, barras verticais discretas por substância ou por objetivo agregado. A ficha individual deixará de ser narrativa longa e passará a quatro zonas: identificação técnica, motivo de entrada no protocolo, eixo de contribuição e pontos de atenção.
