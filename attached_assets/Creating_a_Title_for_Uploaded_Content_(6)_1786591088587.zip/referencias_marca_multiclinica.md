# Referências oficiais de marca — Documento Multiclínica

## Fonte verificada

Repositório oficial: `caio-padua/Protocolo-Manager`, branch `main`, árvore consultada em 13/08/2026 por GitHub CLI.

| Papel no documento | Caminho oficial no repositório | Ativo publicado no mockup |
|---|---|---|
| Assinatura de sistema | `artifacts/padcom/public/brand/padaxor-wordmark-nobg.png` | `/manus-storage/padaxor-wordmark-nobg_ffc66c25.png` |
| Assinatura do grupo/plataforma | `artifacts/padcom/public/brand/padcon-platform-line.png` | `/manus-storage/padcon-platform-line_56cf7b2a.png` |

## Regra de co-branding aplicada

A marca da clínica emissora continua variável e ocupa o bloco superior esquerdo; o local é um componente de marca injetável, não uma clínica fixa. PADAXOR aparece como a camada de Clinical Intelligent System que organiza o protocolo. PADCON aparece como grupo/plataforma mantenedora, em assinatura institucional de menor hierarquia.

O arquivo não deve fixar "Instituto Pádua" como emissor. Os dados de clínica (nome, logotipo e unidade) devem chegar via configuração da clínica/tenant no gerador, preservando no documento somente placeholders de preview.
