# Regras de Formato Slack PADAXOR

## Formato do Monitor Horário (usado pelo Dr. Replit)
- Emoji: 🧠 PADAXOR — Monitor Horário
- Data/hora: 📅 dd/mm/2026, HH:MM:SS (BRT)
- Última entrada: ✍️ Última entrada: #XX "Nome" · _Agente_
- Seção CONCLUÍDOS: ✅ CONCLUÍDOS — Planilha de Produção (N itens)
- Tabela emoldurada com caracteres Unicode box-drawing:
  ╔══════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
  ║ Nº   │ Item                             │ Agente       │ Solicitado por                ║
  ╠══════╪══════════════════════════════════╪══════════════╪═══════════════════════════════╣
  ║ XX   │ item description                 │ Dr. Agent    │ quem pediu                    ║
  ╚══════╧══════════════════════════════════╧══════════════╧═══════════════════════════════╝
- Seção Handoffs: 🔄 Handoffs entre agentes
- Formato: *#XX* "Nome" ← _Agente A → Agente B: descrição_
- Seção Planilha: 📋 Planilha: N itens
- Seção Técnico: 🤖 TÉCNICO — IA (última Xh)
  Chamadas: N | Custo: U$ X.XXXX
- Seção Divergências: ⚠️ Divergências
- Seção Tradução para CEO: ┌─────────────────────────────┐
                             │  📖 TRADUÇÃO PARA O CEO   │
                             └─────────────────────────────┘

## Formato de Relatório de LLMs
- 🧠 PADAXOR — Relatório de LLMs
- Gerado em: timestamp UTC
- Seção técnico com tabela de provider/tipo/chamadas/in-tok/out-tok/custo
- 📋 Specs ativas (N): lista de specs .md
- ⚠️ Divergências detectadas

## Caracteres Box-Drawing Usados
- ╔ ╗ ╚ ╝ (cantos)
- ╠ ╣ ╦ ╩ ╬ (junções)
- ═ (horizontal)
- ║ (vertical)
- │ (separador de coluna interno)
- ─ (alternativo)
- ┌ ┐ └ ┘ (caixa simples)
