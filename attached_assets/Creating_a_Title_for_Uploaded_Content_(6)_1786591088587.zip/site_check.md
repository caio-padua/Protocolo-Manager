# Check do Site PADAXOR

## paxter.com.br — É o site de marketing da empresa Paxter (VendeIA)
- NÃO é o sistema PADAXOR
- É um site de vendas/marketing com produtos: VendeIA, Diagnóstico, PaxCore
- Não tem login/painel visível
- É um site institucional, não o SaaS médico

## Onde está o sistema PADAXOR?
- O repositório tem REPLIT_DEV_DOMAIN como variável de ambiente
- O sistema está provavelmente deployado no Replit
- Não encontrei railway.toml nem Dockerfile
- O item #14 da planilha diz "Dominio proprio apontando para o sistema" — ainda AGUARDANDO
- O item #13 diz "DNS do padaxor.com.br no Cloudflare" — ainda A FAZER
- Conclusão: O sistema PADAXOR provavelmente está em https://{REPLIT_DEV_DOMAIN} (domínio temporário do Replit)

## Itens da planilha relacionados ao acesso:
- #12: Site vira botao, nao segundo login — A FAZER
- #14: Dominio proprio apontando para o sistema — AGUARDANDO (depende do #13)
- #16: Porta da area do paciente — A FAZER
- #41: Rota de upload na area do paciente — A FAZER
