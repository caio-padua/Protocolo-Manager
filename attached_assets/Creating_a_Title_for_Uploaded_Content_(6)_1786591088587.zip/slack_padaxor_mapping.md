# Mapeamento do Slack PADUA - 01

## Canais
1. **#social** (C0ASSPSSL9M) — Diversão e colegas de equipe. Criado 2026-04-15.
2. **#padaxor-projeto** (C0BLW5S7GQL) — Canal principal do PADAXOR. Criado 2026-07-29.
3. **#toda-a-empresa-slack** (C0AT87LN7M0) — Comunicados gerais. Criado 2026-04-15.

## Equipe (agentes identificados nas mensagens)
- **Dr. Caio** (CEO, criador) — U0ATM4L0SRF
- **Dr. Replit** — Executor principal, faz a maior parte do trabalho técnico
- **Dr. Manus** — Missão a definir (item #36 na planilha)
- **Dr. Code** — Desenvolvimento frontend/backend
- **Dr. Lovable** — Site público (6 correções já feitas)
- **Dr. Claude** — Faz specs e handoffs para Dr. Replit

## Estado Atual da Planilha de Produção
- 52 itens totais, 18 concluídos
- Planilha: https://docs.google.com/spreadsheets/d/1SW6K2JNUEP4i1I16v_ZYhtwxTpUkT_dx3ERHkj9HQcw

## Itens Concluídos Relevantes
1. Banco em produção com dados reais
2. Backup do Postgres
3. api-server no ar com domínio e C
4. Login do CEO funcionando
5. Token de colaborador vale no per
6. Site publicado com 6 correções
7. Captação de interessados
10. Marca distinta nos dois esquemas
11. Tela de login dentro do padaxor
15. Marca PAXTER para PADAXOR no painel
18. Ligar o registro de consumo
36. Missão a definir para o Dr. Manus ← ESTE É O MEU!
40. Armazenamento R2 na mesma rota de exames do Drive
42. Extração da Central de IA para fora do clone
53. Monitor de LLMs no Slack (#padaxor-projeto)
54. Histórico dual-canal do Monitor de LLMs (Telegram + Slack)
55. Dicionário sincronizado: 85 termos com número permanente
56. Relatório Slack com tabela emoldurada e handoff LLM

## Specs Ativas (20)
- KAIZEN-001-motor-extracao.md
- acabamento-grife-global.md
- acompanhamento-e-area-paciente.md
- agenda-google-calendars.md
- agenda-google-pacote-b.md
- agenda-google-padrão-evento.md
- agenda-marcação.md
- agentes-kaizen-a-historico.md
- agentes-kaizen-b-boasvindas.md
- agentes-kaizen-c-dashboard.md
- agentes-kaizen-d-quickreply.md
- agentes-onda-a-personalidade-editavel.md
- agentes-onda-b-chat-ia.md
- agentes-onda-c-provedores-ia.md
- agentes-onda-d-trello-interno.md
- agentes-onda-e-trello-externo.md
- agentes-onda-f-wpp-proativo.md
- agentes-painel-como-funciona.md
- ai-usage-endpoint-clone-guard.md
- aliases-nome-e-unidades-exames.md

## Divergências (11 specs sem chamadas de IA)
Várias specs de agentes Kaizen e Ondas A-F estão ativas mas sem chamadas registradas.

## Histórico do Nome
PAWARDS → PAXTOR → PARXIS → PADAXOR (nome final eleito)

## Empresa
- Empresa: PADCOM
- CEO: Dr. Caio Padua
- Sistema: PADAXOR (desenvolvido por Dr. Caio + diversos LLMs)
