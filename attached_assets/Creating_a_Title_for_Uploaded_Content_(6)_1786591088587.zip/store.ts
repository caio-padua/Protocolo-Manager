/**
 * Cockpit Unificado — Zustand Store (Onda Fusão 2.0, 23/07/2026)
 *
 * Centraliza TODO o estado local do Cockpit da Consulta:
 *   - clienteId / aba ativa (persistidos em URL + localStorage)
 *   - formulário financeiro (pagamento manual + Asaas)
 *   - protocolo expandido no accordion
 *
 * Design: "thin store" — apenas state + setters. Derivations vivem nos componentes
 * (useMemo). Anti-pattern: NUNCA guardar dados de servidor aqui (TanStack Query já cuida).
 */
import { create } from "zustand";
import { persist } from "zustand/middleware";

// ─── Tipos ───────────────────────────────────────────────────────────────────

export type AbaId =
  | "prescricao"
  | "injetaveis"
  | "implantes"
  | "exames"
  | "evolucao"
  | "documentos"
  | "anamnese"
  | "protocolos"
  | "financeiro"
  | "cadastro";

export type PayMethod = "pix" | "credit" | "debit" | "boleto" | "cash";

// ─── Store interface ─────────────────────────────────────────────────────────

interface CockpitState {
  // ── Seleção ─────────────────────────────────────────────────────────────
  clienteId: number | null;
  aba: AbaId;

  // ── Accordion protocolos ────────────────────────────────────────────────
  expandedProtocolId: number | null;

  // ── Formulário pagamento manual ─────────────────────────────────────────
  showPaymentForm: boolean;
  payMethod: PayMethod;
  payAmount: string;
  payDate: string;
  payInstallments: string;
  payCardLabel: string;
  payDescription: string;

  // ── Formulário Asaas ────────────────────────────────────────────────────
  showAsaasForm: boolean;
  asaasAmount: string;
  asaasDesc: string;
  asaasDate: string;

  // ── Actions: Seleção ────────────────────────────────────────────────────
  setClienteId: (id: number | null) => void;
  setAba: (aba: AbaId) => void;

  // ── Actions: Protocolo accordion ────────────────────────────────────────
  setExpandedProtocol: (id: number | null) => void;
  toggleExpandedProtocol: (id: number) => void;

  // ── Actions: Pagamento manual ───────────────────────────────────────────
  openPaymentForm: () => void;
  closePaymentForm: () => void;
  setPayMethod: (m: PayMethod) => void;
  setPayAmount: (v: string) => void;
  setPayDate: (v: string) => void;
  setPayInstallments: (v: string) => void;
  setPayCardLabel: (v: string) => void;
  setPayDescription: (v: string) => void;
  resetPaymentForm: () => void;

  // ── Actions: Asaas ──────────────────────────────────────────────────────
  openAsaasForm: () => void;
  closeAsaasForm: () => void;
  setAsaasAmount: (v: string) => void;
  setAsaasDesc: (v: string) => void;
  setAsaasDate: (v: string) => void;
  resetAsaasForm: () => void;

  // ── Actions: Reset total ────────────────────────────────────────────────
  resetAll: () => void;
}

// ─── Helpers de persistência ─────────────────────────────────────────────────

const LS_CLIENTE = "cockpit.clienteId";
const LS_ABA = "cockpit.aba";

function lerClienteInicial(): number | null {
  try {
    const q = new URLSearchParams(window.location.search).get("cliente");
    if (q && /^\d+$/.test(q)) return Number(q);
    const ls = localStorage.getItem(LS_CLIENTE);
    if (ls && /^\d+$/.test(ls)) return Number(ls);
  } catch { /* sem localStorage */ }
  return null;
}

function lerAbaInicial(): AbaId {
  const ABAS: AbaId[] = [
    "prescricao", "injetaveis", "implantes", "exames", "evolucao",
    "documentos", "anamnese", "protocolos", "financeiro", "cadastro",
  ];
  try {
    const q = new URLSearchParams(window.location.search).get("aba");
    if (q && ABAS.includes(q as AbaId)) return q as AbaId;
    const s = localStorage.getItem(LS_ABA);
    if (s && ABAS.includes(s as AbaId)) return s as AbaId;
  } catch { /* ignore */ }
  return "prescricao";
}

// ─── Store ───────────────────────────────────────────────────────────────────

export const useCockpitStore = create<CockpitState>()(
  persist(
    (set, get) => ({
      // ── Estado inicial ──────────────────────────────────────────────────
      clienteId: lerClienteInicial(),
      aba: lerAbaInicial(),
      expandedProtocolId: null,

      showPaymentForm: false,
      payMethod: "pix",
      payAmount: "",
      payDate: new Date().toISOString().slice(0, 10),
      payInstallments: "1",
      payCardLabel: "",
      payDescription: "",

      showAsaasForm: false,
      asaasAmount: "",
      asaasDesc: "",
      asaasDate: "",

      // ── Actions: Seleção ────────────────────────────────────────────────
      setClienteId: (id) => {
        set({ clienteId: id, expandedProtocolId: null });
        try {
          if (id == null) localStorage.removeItem(LS_CLIENTE);
          else localStorage.setItem(LS_CLIENTE, String(id));
          const url = new URL(window.location.href);
          if (id == null) url.searchParams.delete("cliente");
          else url.searchParams.set("cliente", String(id));
          window.history.replaceState({}, "", url.toString());
        } catch { /* ignore */ }
      },

      setAba: (aba) => {
        set({ aba });
        try {
          localStorage.setItem(LS_ABA, aba);
          const url = new URL(window.location.href);
          url.searchParams.set("aba", aba);
          window.history.replaceState({}, "", url.toString());
        } catch { /* ignore */ }
      },

      // ── Actions: Protocolo accordion ────────────────────────────────────
      setExpandedProtocol: (id) => set({ expandedProtocolId: id }),
      toggleExpandedProtocol: (id) => {
        const current = get().expandedProtocolId;
        set({ expandedProtocolId: current === id ? null : id });
      },

      // ── Actions: Pagamento manual ───────────────────────────────────────
      openPaymentForm: () => set({ showPaymentForm: true, showAsaasForm: false }),
      closePaymentForm: () => set({ showPaymentForm: false }),
      setPayMethod: (m) => set({ payMethod: m }),
      setPayAmount: (v) => set({ payAmount: v }),
      setPayDate: (v) => set({ payDate: v }),
      setPayInstallments: (v) => set({ payInstallments: v }),
      setPayCardLabel: (v) => set({ payCardLabel: v }),
      setPayDescription: (v) => set({ payDescription: v }),
      resetPaymentForm: () => set({
        showPaymentForm: false,
        payMethod: "pix",
        payAmount: "",
        payDate: new Date().toISOString().slice(0, 10),
        payInstallments: "1",
        payCardLabel: "",
        payDescription: "",
      }),

      // ── Actions: Asaas ──────────────────────────────────────────────────
      openAsaasForm: () => set({ showAsaasForm: true, showPaymentForm: false }),
      closeAsaasForm: () => set({ showAsaasForm: false }),
      setAsaasAmount: (v) => set({ asaasAmount: v }),
      setAsaasDesc: (v) => set({ asaasDesc: v }),
      setAsaasDate: (v) => set({ asaasDate: v }),
      resetAsaasForm: () => set({
        showAsaasForm: false,
        asaasAmount: "",
        asaasDesc: "",
        asaasDate: "",
      }),

      // ── Actions: Reset total ────────────────────────────────────────────
      resetAll: () => set({
        clienteId: null,
        aba: "prescricao",
        expandedProtocolId: null,
        showPaymentForm: false,
        showAsaasForm: false,
        payAmount: "",
        payDescription: "",
        payCardLabel: "",
        payInstallments: "1",
        asaasAmount: "",
        asaasDesc: "",
        asaasDate: "",
      }),
    }),
    {
      name: "cockpit-v2-storage",
      partialize: (state) => ({
        // Persistimos apenas o essencial (cliente e aba).
        // Formulários NÃO persistem — usuário começa limpo em cada sessão.
        clienteId: state.clienteId,
        aba: state.aba,
      }),
      version: 2, // bump quando a estrutura mudar
    },
  ),
);

// ─── Selectors (memoizados) ──────────────────────────────────────────────────

export const useClienteId = () => useCockpitStore((s) => s.clienteId);
export const useAba = () => useCockpitStore((s) => s.aba);
