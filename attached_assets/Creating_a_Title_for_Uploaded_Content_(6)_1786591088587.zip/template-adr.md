---
title: "<verbo + substantivo em uma linha>"
date: YYYY-MM-DD
status: accepted | superseded
tags: [domínio, padrão-de-erro]
systems: [PADCOM]
validado_em: []
---

## O que decidimos

<1-2 frases. Não citar código, só o princípio.>

## Por quê

| Opção | Prós aparentes | Por que descartamos |
|---|---|---|
| <opção A> | | |
| <opção B> | | |
| **Escolhida** | | ✓ |

**Armadilha que gerou o problema:** <1 parágrafo — o raciocínio errado que levou ao bug>

## O que vigora

<Regra operacional. Como você leria em voz alta para um agente novo.>

## O que vai apodrecer

<Quando esta decisão deve ser revisitada. Se nunca, dizer por quê.>
