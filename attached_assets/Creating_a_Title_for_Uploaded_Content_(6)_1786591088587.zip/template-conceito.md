---
title: "<conceito em uma linha>"
tipo: conceito
tags: [área]
---

## Regra

<O que é, em 1-2 frases. Sem jargão desnecessário.>

## Por quê

<Por que isso existe e por que importa no sistema médico.>

## Armadilha inversa

<O raciocínio que levaria à conclusão oposta e por que esse raciocínio é errado.>

## Ver também

[[nota-relacionada]]
