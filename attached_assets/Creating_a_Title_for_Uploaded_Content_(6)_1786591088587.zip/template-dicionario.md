---
title: "<termo técnico>"
tipo: dicionario
tags: [área]
---

## Definição

<1 frase simples, como explicaria para um colega médico.>

## Quando aparece

<Em que contexto os agentes falam isso.>

## Pergunta que você pode fazer

<"Me explica como você implementou [termo] neste sistema?" — modelo de pergunta para se comunicar com agentes.>

## Exemplo real no PADAXOR

<Onde isso apareceu no sistema (sem citar código, só o que aconteceu).>
