---
title: "<O que quebrou — sem culpado>"
date: YYYY-MM-DD
classe: [classe-do-erro]
---

## Sintoma

<O que o CEO viu. Sem código.>

## Causa raiz

<Uma frase. O princípio, não o nome da variável.>

## Como foi detectado

<Quem percebeu, quando, por qual sinal. Não como foi corrigido.>

## Regra nova

<O que muda na conduta a partir de agora.>

## Onde vai aparecer de novo

<Em que outro domínio ou sistema este padrão de erro pode ressurgir.>
