# Revisão — Carta de Tratamento Clássica

- [x] Auditar o briefing do Dr. Replit, os anexos PDF e a skill do ecossistema.
- [x] Localizar no repositório as fontes e os tokens tipográficos oficiais do PADAXOR.
- [x] Confirmar campo a campo a fiação que pode alimentar a matriz de barras verticais.
- [x] Definir a matriz de leitura rápida (substâncias × sistemas/benefícios) sem simular eficácia individual.
- [x] Refazer o mockup com estilo toscano clássico, alinhamentos modulares e uso mínimo de cor.
- [x] Implementar folha de estilos de impressão A4 com contraste, margens e legibilidade adequados.
- [x] Validar a leitura em desktop, celular e pré-visualização de impressão.
- [x] Atualizar a especificação e comunicar o novo handoff à equipe.

# Expansão — Dossiê Clínico por Substância

- [x] Auditar todos os campos clínicos, logísticos e narrativos já cadastrados para cada substância.
- [x] Comparar a fiação disponível com o dossiê atual e listar o que ainda não aparece.
- [x] Projetar o bloco de meia página por substância, escalável para seis ou mais itens.
- [x] Construir o gráfico de radar exclusivamente a partir das dimensões de impacto existentes.
- [x] Implementar o dossiê multípágina no mockup, preservando a carta clássica e a impressão A4.
- [x] Validar protocolo longo, layout responsivo e páginas impressas.
- [x] Atualizar o item #88 e encaminhar o escopo ampliado ao Dr. Replit.

# Evolução — Documento Multiclínica

- [x] Localizar os logotipos e as referências oficiais de marca PADCON/PADAXOR no repositório.
- [x] Definir a hierarquia: clínica emissora variável, PADAXOR como sistema e PADCON como grupo mantenedor.
- [x] Implementar espaço reservado à marca da clínica e assinatura de plataforma no documento e na impressão.
- [x] Validar contraste, hierarquia e conversão correta para uma clínica diferente.

# Elevação — Dossiê de Assinatura PADAXOR

- [x] Localizar o símbolo oficial PADAXOR/Paxter com efeito luminoso e registrar sua procedência.
- [x] Auditar quais blocos estão compactos demais e definir a ampliação de tipografia e altura.
- [x] Projetar uma capa própria do PADAXOR Clinical Intelligent System e a carta de abertura.
- [x] Reorganizar cada ficha em dois campos estáveis: mapa de sistemas à esquerda e leitura vertical à direita.
- [x] Reorganizar composição, benefícios, segurança e ciência em dois grandes blocos de leitura.
- [x] Implementar a capa, a carta e as fichas ampliadas no mockup e no A4.
- [x] Validar desktop, celular, impressão e variação de conteúdo nas fichas.
- [x] Escrever o documento de handoff com layout e data bindings exatos para o Dr. Replit.

# Manual de Clonagem e Kaizen — Item #88

- [x] Produzir o manual visual executável com medidas A4, zonas, grelha e regras de paginação.
- [x] Especificar cada componente PDF por ordem de desenho, conteúdo, tipografia, espaçamento e fallback.
- [x] Definir regras determinísticas para conteúdo variável, ausência de dados e protocolos longos.
- [x] Elaborar o backlog Kaizen sob a ótica do paciente, com valor, risco clínico e dependência de dados.
- [x] Versionar o complemento, registrar a atualização na planilha e pedir veredito técnico ao Dr. Code.

# Correção do Handoff — Execução Operacional do Item #88

- [x] Auditar a resposta e os artefatos efetivamente entregues pelo Dr. Replit para identificar a lacuna de execução.
- [x] Escrever a carta operacional por arquivo, biblioteca existente, ativo de marca e sequência de comandos.
- [x] Fixar as evidências obrigatórias por etapa: diff, teste, PDF A4, inspeção visual e assinatura.
- [x] Versionar a carta operacional e enviar ordem direta de execução ao Dr. Replit e pedido de veredito ao Dr. Code.
