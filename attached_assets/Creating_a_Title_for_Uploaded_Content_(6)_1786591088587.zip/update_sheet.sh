#!/bin/bash
set +H

# Ler as linhas atuais para confirmar a estrutura
echo "=== Lendo linhas 60-65 ==="
gws sheets +read --spreadsheet '1SW6K2JNUEP4i1I16v_ZYhtwxTpUkT_dx3ERHkj9HQcw' --range 'PLANILHA PRODUCAO!A60:H65' 2>&1

echo ""
echo "=== Atualizando coluna F (Status) dos itens 60-63 para AGUARDANDO ==="

# Coluna F é a 6ª coluna = status
# Linha 60 no sheet = item 60 (header na linha 1)
# Precisamos atualizar F60, F61, F62, F63

# Atualizar F60
gws sheets spreadsheets values update \
  --params '{"spreadsheetId": "1SW6K2JNUEP4i1I16v_ZYhtwxTpUkT_dx3ERHkj9HQcw", "range": "PLANILHA PRODUCAO!F60", "valueInputOption": "USER_ENTERED"}' \
  --json '{"values": [["AGUARDANDO"]]}' 2>&1

# Atualizar F61
gws sheets spreadsheets values update \
  --params '{"spreadsheetId": "1SW6K2JNUEP4i1I16v_ZYhtwxTpUkT_dx3ERHkj9HQcw", "range": "PLANILHA PRODUCAO!F61", "valueInputOption": "USER_ENTERED"}' \
  --json '{"values": [["AGUARDANDO"]]}' 2>&1

# Atualizar F62
gws sheets spreadsheets values update \
  --params '{"spreadsheetId": "1SW6K2JNUEP4i1I16v_ZYhtwxTpUkT_dx3ERHkj9HQcw", "range": "PLANILHA PRODUCAO!F62", "valueInputOption": "USER_ENTERED"}' \
  --json '{"values": [["AGUARDANDO"]]}' 2>&1

# Atualizar F63
gws sheets spreadsheets values update \
  --params '{"spreadsheetId": "1SW6K2JNUEP4i1I16v_ZYhtwxTpUkT_dx3ERHkj9HQcw", "range": "PLANILHA PRODUCAO!F63", "valueInputOption": "USER_ENTERED"}' \
  --json '{"values": [["AGUARDANDO"]]}' 2>&1

echo ""
echo "=== Verificando atualização ==="
gws sheets +read --spreadsheet '1SW6K2JNUEP4i1I16v_ZYhtwxTpUkT_dx3ERHkj9HQcw' --range 'PLANILHA PRODUCAO!A60:F63' 2>&1
