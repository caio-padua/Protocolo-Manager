# Validação Visual — Dossiê Clínico Ampliado

**Data:** 12/08/2026  
**Build:** `pnpm check` e `pnpm build` concluídos sem erro de tipagem ou compilação.

| Cenário | Resultado observado | Critério validado |
|---|---|---|
| Desktop, página integral | A carta manteve capa, mapa vertical, ficha A/B na mesma folha e ficha C na folha seguinte; a página vazia reserva posição para o próximo componente | Duas fichas de substância por folha, sem retorno ao padrão de cartões SaaS |
| Desktop, ficha individual | Cada ficha exibe cabeçalho, seis dados de administração, três blocos narrativos, radar, colunas verticais, medidores, composição, benefícios e segurança | A fiação clínica agora é densa e organizada por blocos, não resumida em poucas linhas |
| Celular, página integral | A ficha se reorganiza em uma coluna: administração 3×2, gráficos empilhados e blocos textuais completos | O conteúdo não desaparece nem depende de hover; a leitura pode ser feita por varredura vertical |
| Dados de impacto | Radar e barras usam somente valores 0–5 presentes em `bodySystemEffects` e `categoryMeters` | Nenhuma métrica de resultado individual foi calculada ou inventada |
| Escalabilidade | A renderização divide a coleção de substâncias em pares (`chunk(substances, 2)`); cada novo item cria outro módulo, sem limite de três | Protocolos com 4, 5, 6 ou mais substâncias preservam a mesma cadência de duas fichas por folha |

## Observação de impressão

O CSS já reserva A4, margens de 10 mm, paleta de baixa cobertura e quebra por `paper-sheet`. A próxima validação operacional deve gerar o PDF do navegador para conferir paginação física em A4, sobretudo em fichas com textos de benefício longos.
