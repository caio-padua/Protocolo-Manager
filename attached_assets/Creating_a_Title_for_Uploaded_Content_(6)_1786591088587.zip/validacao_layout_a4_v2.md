# Validação visual e de impressão — Carta de Tratamento PADAXOR v2

**Data:** 12/08/2026  
**Escopo:** capa, mapa de ênfases, três fichas de substância e roteiro final.  
**Finalidade:** confirmar legibilidade, estabilidade de leitura e uma substância por folha antes do handoff de implementação.

| Frente de validação | Método | Resultado | Evidência |
|---|---|---|---|
| Desktop | Captura integral em 1280 × 720 | **Aprovado** | Capa, mapa, três dossiês e roteiro apresentam grelha estável, tipografia ampliada e marca PADAXOR no canto superior direito das páginas internas. |
| Celular | Captura integral em 390 × 844 | **Aprovado** | A grelha migra para uma coluna sem ocultar campos; tabelas extensas preservam a leitura horizontal. |
| Impressão | Chromium headless / A4 | **Aprovado** | PDF com 6 páginas A4, tamanho físico 594,96 × 841,92 pt. |
| Paginação | Inspeção da prévia gerada | **Aprovado** | 01 capa; 02 mapa; 03 Coenzima Q10; 04 NADH Pellet; 05 Blend Mitocondrial; 06 roteiro. |

> **Regra comprovada:** cada objeto de `protocol_items`/substância é renderizado como uma `dossier-sheet` com `break-after: page`. Assim, não divide duas substâncias na mesma folha.

## Verificações específicas do pedido executivo

| Pedido | Implementação validada |
|---|---|
| Capa PADAXOR sofisticada | Símbolo oficial de vidro/brilho em foco central, wordmark PADAXOR de grande escala, navy profundo e informação da clínica em posição subordinada. |
| Leitura grandiosa | Títulos serifados ampliados; dados operacionais agrupados em seis campos consistentes; não há coluna de três blocos na área final. |
| Radar e barras legíveis | Radar aumentado e mapa de sistemas em barras verticais, ambos em áreas próprias de alta legibilidade. |
| Dois campos estáveis | Mapa de sistemas à esquerda e medidores à direita; composição/benefícios e segurança/ciência organizados em duas colunas. |
| PADAXOR interno | Assinatura PADAXOR Clinical Intelligent System no canto superior direito de todas as páginas internas. |
| PADCON secundária | Apenas na faixa de proveniência tecnológica do rodapé. |

## Observação de integração

O mockup demonstra os dados com valores de exemplo. A aplicação real deve operar somente com os bindings já disponíveis na rota de protocolo e nos schemas auditados; campos ausentes devem ser omitidos com um estado neutro, sem inventar métricas, efeitos, composição ou evidência.
