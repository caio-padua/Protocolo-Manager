# Validação — prévia física A4 corrigida

**Fonte:** `/home/ubuntu/webdev-static-assets/dossie-clinico-a4-previsualizacao-v2.pdf`  
**Geração:** Chromium headless, 12/08/2026.

## Resultado objetivo

| Item | Evidência |
|---|---|
| Total de páginas | **6 páginas A4** |
| Dimensão física | **594.96 × 841.92 pts (A4)** |
| Capa | Agora cabe em **1 página** |
| Mapa de ênfases | Agora cabe em **1 página** |
| Dossiês por substância | Cada substância ocupa **1 página inteira** nesta versão física exportada |
| Roteiro final | Cabe em **1 página** |

## Leitura visual por página

1. **Página 1 — capa:** composição estável; sem quebra indevida; selo, grade de identificação e bloco "leitura em uma olhada" preservados.
2. **Página 2 — mapa de ênfases:** gráfico vertical e síntese da matriz cabem numa única folha.
3. **Páginas 3–4 — dossiês clínicos:** fichas densas, com dados administrativos, narrativa, radar, barras verticais, medidores e composição.
4. **Página 5 — roteiro final:** cronograma e bloco lateral de orientação preservados.

## Diagnóstico atualizado

- A correção de impressão resolveu o problema crítico de a capa e o mapa se partirem em duas páginas.
- A estrutura visual impressa ficou coerente com a direção clássica/toscana.
- A densidade clínica agora está muito superior à versão resumida anterior.

## Ponto ainda aberto

- A meta conceitual de **"meia folha por substância"** ainda não se materializou na exportação física: nesta prévia, cada substância está ocupando uma página inteira. Isso pode ser aceitável para protocolos densos, mas precisa ser confirmado com o Dr. Caio porque ele pediu meia página por substância quando possível.
