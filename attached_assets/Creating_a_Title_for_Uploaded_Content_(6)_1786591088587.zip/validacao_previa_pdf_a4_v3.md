# Validação — prévia física A4, duas fichas por folha

**Fonte:** `/home/ubuntu/webdev-static-assets/dossie-clinico-a4-previsualizacao-v3.pdf`  
**Resultado técnico:** 5 páginas A4, sem página final vazia.

## Achados confirmados

| Achado | Evidência |
|---|---|
| Página 3 | Duas fichas de substância são iniciadas na mesma folha: Coenzima Q10 e NADH Pellet. |
| Página 4 | A terceira substância ocupa a primeira meia página; a segunda metade mostra uma reserva automática para protocolos com 4, 6 ou mais substâncias. |
| Leitura | A combinação de radar, barras verticais, dados administrativos, narrativa, medidores, composição, benefícios e segurança preserva a hierarquia visual clássica. |
| Falha residual | A segunda ficha da página 3 é cortada antes de expor todas as faixas inferiores; a folha usa `overflow:hidden` e a densidade ainda excede a meia página. |

## Próxima correção obrigatória

Compactar as áreas internas de impressão e preservar o conteúdo integral das duas fichas, sem reduzir a leitura abaixo do limiar físico aceitável.
