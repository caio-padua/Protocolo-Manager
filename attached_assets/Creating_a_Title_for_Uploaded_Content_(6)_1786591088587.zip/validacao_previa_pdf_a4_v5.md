# Validação final — dossiê de duas fichas por folha A4

**Fonte:** `/home/ubuntu/webdev-static-assets/dossie-clinico-a4-previsualizacao-v5.pdf`  
**Método:** prévia física Chromium + inspeção visual da página 3.

## Resultado confirmado

| Critério | Resultado |
|---|---|
| Páginas | 5 páginas A4 para capa, matriz, 3 substâncias e roteiro. |
| Duas substâncias por folha | Confirmado na página 3: **Coenzima Q10** e **NADH Pellet** completas. |
| Última ficha sem par | A página 4 traz a ficha da substância restante e uma área de reserva para a próxima substância. |
| Dados por ficha | Administração, três narrativas clínicas, radar, barras verticais, medidores, composição/posologia, benefícios, cuidados e base científica. |
| Recorte | Não observado na ficha superior nem na inferior da página 3. |
| Estilo | Marfim, navy e ouro permanecem contidos; a impressão continua utilizável em escala de cinza. |

## Observação de legibilidade

O arranjo usa a área útil máxima da A4, com margens de 5 mm e tipografia compacta de relatório clínico. Ele prioriza preservar toda a fiação e duas fichas por folha. Para textos excepcionalmente longos no cadastro, o modelo já prevê continuidade em nova página em vez de ocultar conteúdo.
