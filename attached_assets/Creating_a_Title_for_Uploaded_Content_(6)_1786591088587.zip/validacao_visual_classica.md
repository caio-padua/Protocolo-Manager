# Validação Visual — Carta de Tratamento Clássica

## Desktop (1280 × 960)

- As quatro lâminas mantêm margens, linhas de base e colunas com cadência editorial consistente.
- O **Instituto Pádua** é a assinatura dominante no cabeçalho e nos rodapés; PADAXOR não compete como marca do documento.
- O selo radial concentra o estado do roteiro sem adicionar um indicador clínico novo.
- A matriz possui eixo vertical, categorias no eixo horizontal e padrão monocromático para diferenciar componentes de forma imprimível.
- Os componentes são lidos como linhas de dossier, com narrativa central e dados técnicos alinhados na margem direita.

## Celular (390 × 844)

- A sequência é preservada como leitura por lâminas: carta, mapa, componentes e roteiro.
- O cabeçalho institucional e o botão de impressão continuam visíveis sem disputa com o conteúdo.
- As informações do dossier permanecem em colunas e não sofrem sobreposição; a ordem visual reduz a necessidade de leitura linear extensa.

## Impressão

- A folha de estilo A4 remove a navegação, define página A4 e utiliza marfim, navy, cinzas e padrões monocromáticos de alto contraste.
- A implementação preserva o sentido das barras e das chaves de componente sem depender de cor saturada.
