---
title: "Webhook"
tipo: dicionario
tags: [integração, backend]
---

## Definição

Quando um sistema externo (Asaas, Twilio, Slack) avisa seu sistema automaticamente quando algo acontece — sem você precisar ficar perguntando.

## Quando aparece

Pagamento confirmado, cobrança expirada, mensagem entregue.

## Pergunta que você pode fazer

"O webhook é idempotente? Se o Asaas reenviar o mesmo evento, o que acontece?"

## Exemplo real no PADAXOR

O Asaas envia webhook quando cobrança expira. O PADAXOR recebe, identifica o pedido, e registra penalidade. Sem idempotência, reenvio do Asaas = penalidade duplicada.
